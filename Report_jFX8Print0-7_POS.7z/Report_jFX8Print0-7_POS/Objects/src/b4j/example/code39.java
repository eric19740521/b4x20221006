package b4j.example;


import anywheresoftware.b4a.BA;

public class code39 extends Object{
public static code39 mostCurrent = new code39();

public static BA ba;
static {
		ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.code39", null);
		ba.loadHtSubs(code39.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.code39", ba);
		}
	}
    public static Class<?> getObject() {
		return code39.class;
	}

 public static anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4j.objects.JFX _fx = null;
public static String _start = "";
public static String _fin = "";
public static b4j.example.stringutilities _su = null;
public static String _bs = "";
public static String _bs1 = "";
public static int _bcolor = 0;
public static int _fcolor = 0;
public static b4j.example.dateutils _dateutils = null;
public static b4j.example.cssutils _cssutils = null;
public static b4j.example.main _main = null;
public static b4j.example.printerjob_static _printerjob_static = null;
public static b4j.example.pageorientation_static _pageorientation_static = null;
public static b4j.example.printer_static _printer_static = null;
public static b4j.example.paper_static _paper_static = null;
public static b4j.example.utils _utils = null;
public static b4j.example.adhocwrappers _adhocwrappers = null;
public static b4j.example.xuiviewsutils _xuiviewsutils = null;
public static String  _build_string(String _mes1) throws Exception{
String _karak = "";
int _i = 0;
int _siz1 = 0;
int _qr_size = 0;
 //BA.debugLineNum = 102;BA.debugLine="Private Sub build_string(mes1 As String) As String";
 //BA.debugLineNum = 104;BA.debugLine="Dim karak As String";
_karak = "";
 //BA.debugLineNum = 105;BA.debugLine="bs = \"\"";
_bs = "";
 //BA.debugLineNum = 106;BA.debugLine="start = \"NWNNWNWNN\"";
_start = "NWNNWNWNN";
 //BA.debugLineNum = 107;BA.debugLine="bs = bs & start";
_bs = _bs+_start;
 //BA.debugLineNum = 108;BA.debugLine="bs = bs & \"N\"";
_bs = _bs+"N";
 //BA.debugLineNum = 110;BA.debugLine="For i = 0 To su.stringLength(mes1) - 1";
{
final int step6 = 1;
final int limit6 = (int) (_su._stringlength /*int*/ (_mes1)-1);
_i = (int) (0) ;
for (;_i <= limit6 ;_i = _i + step6 ) {
 //BA.debugLineNum = 111;BA.debugLine="karak = su.Mid(mes1,i,1)";
_karak = _su._mid /*String*/ (_mes1,_i,(int) (1));
 //BA.debugLineNum = 114;BA.debugLine="If karak = \"0\" Then bs = bs & \"NNNWWNWNN\"";
if ((_karak).equals("0")) { 
_bs = _bs+"NNNWWNWNN";};
 //BA.debugLineNum = 115;BA.debugLine="If karak = \"1\" Then bs = bs & \"WNNWNNNNW\"";
if ((_karak).equals("1")) { 
_bs = _bs+"WNNWNNNNW";};
 //BA.debugLineNum = 116;BA.debugLine="If karak = \"2\" Then bs = bs & \"NNWWNNNNW\"";
if ((_karak).equals("2")) { 
_bs = _bs+"NNWWNNNNW";};
 //BA.debugLineNum = 117;BA.debugLine="If karak = \"3\" Then bs = bs & \"WNWWNNNNN\"";
if ((_karak).equals("3")) { 
_bs = _bs+"WNWWNNNNN";};
 //BA.debugLineNum = 118;BA.debugLine="If karak = \"4\" Then bs = bs & \"NNNWWNNNW\"";
if ((_karak).equals("4")) { 
_bs = _bs+"NNNWWNNNW";};
 //BA.debugLineNum = 119;BA.debugLine="If karak = \"5\" Then bs = bs & \"WNNWWNNNN\"";
if ((_karak).equals("5")) { 
_bs = _bs+"WNNWWNNNN";};
 //BA.debugLineNum = 120;BA.debugLine="If karak = \"6\" Then bs = bs & \"NNWWWNNNN\"";
if ((_karak).equals("6")) { 
_bs = _bs+"NNWWWNNNN";};
 //BA.debugLineNum = 121;BA.debugLine="If karak = \"7\" Then bs = bs & \"NNNWNNWNW\"";
if ((_karak).equals("7")) { 
_bs = _bs+"NNNWNNWNW";};
 //BA.debugLineNum = 122;BA.debugLine="If karak = \"8\" Then bs = bs & \"WNNWNNWNN\"";
if ((_karak).equals("8")) { 
_bs = _bs+"WNNWNNWNN";};
 //BA.debugLineNum = 123;BA.debugLine="If karak = \"9\" Then bs = bs & \"NNWWNNWNN\"";
if ((_karak).equals("9")) { 
_bs = _bs+"NNWWNNWNN";};
 //BA.debugLineNum = 124;BA.debugLine="If karak = \"A\" Then bs = bs & \"WNNNNWNNW\"";
if ((_karak).equals("A")) { 
_bs = _bs+"WNNNNWNNW";};
 //BA.debugLineNum = 125;BA.debugLine="If karak = \"B\" Then bs = bs & \"NNWNNWNNW\"";
if ((_karak).equals("B")) { 
_bs = _bs+"NNWNNWNNW";};
 //BA.debugLineNum = 126;BA.debugLine="If karak = \"C\" Then bs = bs & \"WNWNNWNNN\"";
if ((_karak).equals("C")) { 
_bs = _bs+"WNWNNWNNN";};
 //BA.debugLineNum = 127;BA.debugLine="If karak = \"D\" Then bs = bs & \"NNNNWWNNW\"";
if ((_karak).equals("D")) { 
_bs = _bs+"NNNNWWNNW";};
 //BA.debugLineNum = 128;BA.debugLine="If karak = \"E\" Then bs = bs & \"WNNNWWNNN\"";
if ((_karak).equals("E")) { 
_bs = _bs+"WNNNWWNNN";};
 //BA.debugLineNum = 129;BA.debugLine="If karak = \"F\" Then bs = bs & \"NNWNWWNNN\"";
if ((_karak).equals("F")) { 
_bs = _bs+"NNWNWWNNN";};
 //BA.debugLineNum = 130;BA.debugLine="If karak = \"G\" Then bs = bs & \"NNNNNWWNW\"";
if ((_karak).equals("G")) { 
_bs = _bs+"NNNNNWWNW";};
 //BA.debugLineNum = 131;BA.debugLine="If karak = \"H\" Then bs = bs & \"WNNNNWWNN\"";
if ((_karak).equals("H")) { 
_bs = _bs+"WNNNNWWNN";};
 //BA.debugLineNum = 132;BA.debugLine="If karak = \"I\" Then bs = bs & \"NNWNNWWNN\"";
if ((_karak).equals("I")) { 
_bs = _bs+"NNWNNWWNN";};
 //BA.debugLineNum = 133;BA.debugLine="If karak = \"J\" Then bs = bs & \"NNNNWWWNN\"";
if ((_karak).equals("J")) { 
_bs = _bs+"NNNNWWWNN";};
 //BA.debugLineNum = 134;BA.debugLine="If karak = \"K\" Then bs = bs & \"WNNNNNNWW\"";
if ((_karak).equals("K")) { 
_bs = _bs+"WNNNNNNWW";};
 //BA.debugLineNum = 135;BA.debugLine="If karak = \"L\" Then bs = bs & \"NNWNNNNWW\"";
if ((_karak).equals("L")) { 
_bs = _bs+"NNWNNNNWW";};
 //BA.debugLineNum = 136;BA.debugLine="If karak = \"M\" Then bs = bs & \"WNWNNNNWN\"";
if ((_karak).equals("M")) { 
_bs = _bs+"WNWNNNNWN";};
 //BA.debugLineNum = 137;BA.debugLine="If karak = \"N\" Then bs = bs & \"NNNNWNNWW\"";
if ((_karak).equals("N")) { 
_bs = _bs+"NNNNWNNWW";};
 //BA.debugLineNum = 138;BA.debugLine="If karak = \"O\" Then bs = bs & \"WNNNWNNWN\"";
if ((_karak).equals("O")) { 
_bs = _bs+"WNNNWNNWN";};
 //BA.debugLineNum = 139;BA.debugLine="If karak = \"P\" Then bs = bs & \"NNWNWNNWN\"";
if ((_karak).equals("P")) { 
_bs = _bs+"NNWNWNNWN";};
 //BA.debugLineNum = 140;BA.debugLine="If karak = \"Q\" Then bs = bs & \"NNNNNNWWW\"";
if ((_karak).equals("Q")) { 
_bs = _bs+"NNNNNNWWW";};
 //BA.debugLineNum = 141;BA.debugLine="If karak = \"R\" Then bs = bs & \"WNNNNNWWN\"";
if ((_karak).equals("R")) { 
_bs = _bs+"WNNNNNWWN";};
 //BA.debugLineNum = 142;BA.debugLine="If karak = \"S\" Then bs = bs & \"NNWNNNWWN\"";
if ((_karak).equals("S")) { 
_bs = _bs+"NNWNNNWWN";};
 //BA.debugLineNum = 143;BA.debugLine="If karak = \"T\" Then bs = bs & \"NNNNWNWWN\"";
if ((_karak).equals("T")) { 
_bs = _bs+"NNNNWNWWN";};
 //BA.debugLineNum = 144;BA.debugLine="If karak = \"U\" Then bs = bs & \"WWNNNNNNW\"";
if ((_karak).equals("U")) { 
_bs = _bs+"WWNNNNNNW";};
 //BA.debugLineNum = 145;BA.debugLine="If karak = \"V\" Then bs = bs & \"NWWNNNNNW\"";
if ((_karak).equals("V")) { 
_bs = _bs+"NWWNNNNNW";};
 //BA.debugLineNum = 146;BA.debugLine="If karak = \"W\" Then bs = bs & \"WWWNNNNNN\"";
if ((_karak).equals("W")) { 
_bs = _bs+"WWWNNNNNN";};
 //BA.debugLineNum = 147;BA.debugLine="If karak = \"X\" Then bs = bs & \"NWNNWNNNW\"";
if ((_karak).equals("X")) { 
_bs = _bs+"NWNNWNNNW";};
 //BA.debugLineNum = 148;BA.debugLine="If karak = \"Y\" Then bs = bs & \"WWNNWNNNN\"";
if ((_karak).equals("Y")) { 
_bs = _bs+"WWNNWNNNN";};
 //BA.debugLineNum = 149;BA.debugLine="If karak = \"Z\" Then bs = bs & \"NWWNWNNNN\"";
if ((_karak).equals("Z")) { 
_bs = _bs+"NWWNWNNNN";};
 //BA.debugLineNum = 150;BA.debugLine="If karak = \"-\" Then bs = bs & \"NWNNNNWNW\"";
if ((_karak).equals("-")) { 
_bs = _bs+"NWNNNNWNW";};
 //BA.debugLineNum = 151;BA.debugLine="If karak = \".\" Then bs = bs & \"WWNNNNWNN\"";
if ((_karak).equals(".")) { 
_bs = _bs+"WWNNNNWNN";};
 //BA.debugLineNum = 152;BA.debugLine="If karak = \" \" Then bs = bs & \"NWWNNNWNN\"";
if ((_karak).equals(" ")) { 
_bs = _bs+"NWWNNNWNN";};
 //BA.debugLineNum = 153;BA.debugLine="If karak = \"$\" Then bs = bs & \"NWNWNWNNN\"";
if ((_karak).equals("$")) { 
_bs = _bs+"NWNWNWNNN";};
 //BA.debugLineNum = 154;BA.debugLine="If karak = \"/\" Then bs = bs & \"NWNWNNNWN\"";
if ((_karak).equals("/")) { 
_bs = _bs+"NWNWNNNWN";};
 //BA.debugLineNum = 155;BA.debugLine="If karak = \"+\" Then bs = bs & \"NWNNNWNWN\"";
if ((_karak).equals("+")) { 
_bs = _bs+"NWNNNWNWN";};
 //BA.debugLineNum = 156;BA.debugLine="If karak = \"%\" Then bs = bs & \"NNNWNWNWN\"";
if ((_karak).equals("%")) { 
_bs = _bs+"NNNWNWNWN";};
 //BA.debugLineNum = 157;BA.debugLine="bs = bs & \"N\"";
_bs = _bs+"N";
 }
};
 //BA.debugLineNum = 160;BA.debugLine="fin = \"NWNNWNWNN\"";
_fin = "NWNNWNWNN";
 //BA.debugLineNum = 161;BA.debugLine="bs = bs & fin";
_bs = _bs+_fin;
 //BA.debugLineNum = 166;BA.debugLine="bs1 = \"\"";
_bs1 = "";
 //BA.debugLineNum = 171;BA.debugLine="Dim siz1 As Int";
_siz1 = 0;
 //BA.debugLineNum = 172;BA.debugLine="Dim qr_size As Int";
_qr_size = 0;
 //BA.debugLineNum = 173;BA.debugLine="siz1 = 4dip";
_siz1 = anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (4));
 //BA.debugLineNum = 175;BA.debugLine="qr_size = 0";
_qr_size = (int) (0);
 //BA.debugLineNum = 176;BA.debugLine="For i = 0 To su.stringLength(bs) - 1";
{
final int step60 = 1;
final int limit60 = (int) (_su._stringlength /*int*/ (_bs)-1);
_i = (int) (0) ;
for (;_i <= limit60 ;_i = _i + step60 ) {
 //BA.debugLineNum = 177;BA.debugLine="If su.Mid(bs,i,1) = \"N\" Then qr_size = qr_size +";
if ((_su._mid /*String*/ (_bs,_i,(int) (1))).equals("N")) { 
_qr_size = (int) (_qr_size+_siz1);};
 //BA.debugLineNum = 178;BA.debugLine="If su.Mid(bs,i,1) = \"W\" Then qr_size = qr_size +";
if ((_su._mid /*String*/ (_bs,_i,(int) (1))).equals("W")) { 
_qr_size = (int) (_qr_size+(2*_siz1));};
 }
};
 //BA.debugLineNum = 183;BA.debugLine="For i = 0 To su.stringLength(bs) - 1";
{
final int step64 = 1;
final int limit64 = (int) (_su._stringlength /*int*/ (_bs)-1);
_i = (int) (0) ;
for (;_i <= limit64 ;_i = _i + step64 ) {
 //BA.debugLineNum = 185;BA.debugLine="If (i+1) Mod 2 = 1  And su.Mid(bs,i,1) = \"N\" The";
if ((_i+1)%2==1 && (_su._mid /*String*/ (_bs,_i,(int) (1))).equals("N")) { 
 //BA.debugLineNum = 193;BA.debugLine="bs1 = bs1 & \"1\"";
_bs1 = _bs1+"1";
 }else if((_i+1)%2==1 && (_su._mid /*String*/ (_bs,_i,(int) (1))).equals("W")) { 
 //BA.debugLineNum = 202;BA.debugLine="bs1 = bs1 & \"11\"";
_bs1 = _bs1+"11";
 }else if((_i+1)%2==0 && (_su._mid /*String*/ (_bs,_i,(int) (1))).equals("N")) { 
 //BA.debugLineNum = 211;BA.debugLine="bs1 = bs1 & \"0\"";
_bs1 = _bs1+"0";
 }else if((_i+1)%2==0 && (_su._mid /*String*/ (_bs,_i,(int) (1))).equals("W")) { 
 //BA.debugLineNum = 220;BA.debugLine="bs1 = bs1 & \"00\"";
_bs1 = _bs1+"00";
 };
 }
};
 //BA.debugLineNum = 226;BA.debugLine="Return bs1";
if (true) return _bs1;
 //BA.debugLineNum = 245;BA.debugLine="End Sub";
return "";
}
public static String  _draw_code39(String _message) throws Exception{
int _flag = 0;
String _karak = "";
String _new_mes = "";
int _i = 0;
 //BA.debugLineNum = 28;BA.debugLine="Public Sub Draw_Code39 (message As String) As Stri";
 //BA.debugLineNum = 30;BA.debugLine="Dim flag As Int";
_flag = 0;
 //BA.debugLineNum = 31;BA.debugLine="su.Initialize()";
_su._initialize /*String*/ (ba);
 //BA.debugLineNum = 33;BA.debugLine="Dim karak, new_mes As String";
_karak = "";
_new_mes = "";
 //BA.debugLineNum = 35;BA.debugLine="new_mes = \"\"";
_new_mes = "";
 //BA.debugLineNum = 36;BA.debugLine="flag = 0";
_flag = (int) (0);
 //BA.debugLineNum = 37;BA.debugLine="For i = 0 To su.stringLength(message) -1";
{
final int step6 = 1;
final int limit6 = (int) (_su._stringlength /*int*/ (_message)-1);
_i = (int) (0) ;
for (;_i <= limit6 ;_i = _i + step6 ) {
 //BA.debugLineNum = 38;BA.debugLine="karak = su.Mid(message,i,1)";
_karak = _su._mid /*String*/ (_message,_i,(int) (1));
 //BA.debugLineNum = 39;BA.debugLine="If karak = \"a\" Then karak = \"A\"";
if ((_karak).equals("a")) { 
_karak = "A";};
 //BA.debugLineNum = 40;BA.debugLine="If karak = \"b\" Then karak = \"B\"";
if ((_karak).equals("b")) { 
_karak = "B";};
 //BA.debugLineNum = 41;BA.debugLine="If karak = \"c\" Then karak = \"C\"";
if ((_karak).equals("c")) { 
_karak = "C";};
 //BA.debugLineNum = 42;BA.debugLine="If karak = \"d\" Then karak = \"D\"";
if ((_karak).equals("d")) { 
_karak = "D";};
 //BA.debugLineNum = 43;BA.debugLine="If karak = \"e\" Then karak = \"E\"";
if ((_karak).equals("e")) { 
_karak = "E";};
 //BA.debugLineNum = 44;BA.debugLine="If karak = \"f\" Then karak = \"F\"";
if ((_karak).equals("f")) { 
_karak = "F";};
 //BA.debugLineNum = 45;BA.debugLine="If karak = \"g\" Then karak = \"G\"";
if ((_karak).equals("g")) { 
_karak = "G";};
 //BA.debugLineNum = 46;BA.debugLine="If karak = \"h\" Then karak = \"H\"";
if ((_karak).equals("h")) { 
_karak = "H";};
 //BA.debugLineNum = 47;BA.debugLine="If karak = \"i\" Then karak = \"I\"";
if ((_karak).equals("i")) { 
_karak = "I";};
 //BA.debugLineNum = 48;BA.debugLine="If karak = \"j\" Then karak = \"J\"";
if ((_karak).equals("j")) { 
_karak = "J";};
 //BA.debugLineNum = 49;BA.debugLine="If karak = \"k\" Then karak = \"K\"";
if ((_karak).equals("k")) { 
_karak = "K";};
 //BA.debugLineNum = 50;BA.debugLine="If karak = \"l\" Then karak = \"L\"";
if ((_karak).equals("l")) { 
_karak = "L";};
 //BA.debugLineNum = 51;BA.debugLine="If karak = \"m\" Then karak = \"M\"";
if ((_karak).equals("m")) { 
_karak = "M";};
 //BA.debugLineNum = 52;BA.debugLine="If karak = \"n\" Then karak = \"N\"";
if ((_karak).equals("n")) { 
_karak = "N";};
 //BA.debugLineNum = 53;BA.debugLine="If karak = \"o\" Then karak = \"O\"";
if ((_karak).equals("o")) { 
_karak = "O";};
 //BA.debugLineNum = 54;BA.debugLine="If karak = \"p\" Then karak = \"P\"";
if ((_karak).equals("p")) { 
_karak = "P";};
 //BA.debugLineNum = 55;BA.debugLine="If karak = \"q\" Then karak = \"Q\"";
if ((_karak).equals("q")) { 
_karak = "Q";};
 //BA.debugLineNum = 56;BA.debugLine="If karak = \"r\" Then karak = \"R\"";
if ((_karak).equals("r")) { 
_karak = "R";};
 //BA.debugLineNum = 57;BA.debugLine="If karak = \"s\" Then karak = \"S\"";
if ((_karak).equals("s")) { 
_karak = "S";};
 //BA.debugLineNum = 58;BA.debugLine="If karak = \"t\" Then karak = \"T\"";
if ((_karak).equals("t")) { 
_karak = "T";};
 //BA.debugLineNum = 59;BA.debugLine="If karak = \"u\" Then karak = \"U\"";
if ((_karak).equals("u")) { 
_karak = "U";};
 //BA.debugLineNum = 60;BA.debugLine="If karak = \"v\" Then karak = \"V\"";
if ((_karak).equals("v")) { 
_karak = "V";};
 //BA.debugLineNum = 61;BA.debugLine="If karak = \"w\" Then karak = \"W\"";
if ((_karak).equals("w")) { 
_karak = "W";};
 //BA.debugLineNum = 62;BA.debugLine="If karak = \"x\" Then karak = \"X\"";
if ((_karak).equals("x")) { 
_karak = "X";};
 //BA.debugLineNum = 63;BA.debugLine="If karak = \"y\" Then karak = \"Y\"";
if ((_karak).equals("y")) { 
_karak = "Y";};
 //BA.debugLineNum = 64;BA.debugLine="If karak = \"z\" Then karak = \"Z\"";
if ((_karak).equals("z")) { 
_karak = "Z";};
 //BA.debugLineNum = 65;BA.debugLine="If karak <> \"0\" And karak <> \"1\" And karak <> \"2\"";
if ((_karak).equals("0") == false && (_karak).equals("1") == false && (_karak).equals("2") == false && (_karak).equals("3") == false && (_karak).equals("4") == false && (_karak).equals("5") == false && (_karak).equals("6") == false && (_karak).equals("7") == false && (_karak).equals("8") == false && (_karak).equals("9") == false && (_karak).equals("A") == false && (_karak).equals("B") == false && (_karak).equals("C") == false && (_karak).equals("D") == false && (_karak).equals("E") == false && (_karak).equals("F") == false && (_karak).equals("G") == false && (_karak).equals("H") == false && (_karak).equals("I") == false && (_karak).equals("J") == false && (_karak).equals("K") == false && (_karak).equals("L") == false && (_karak).equals("M") == false && (_karak).equals("N") == false && (_karak).equals("O") == false && (_karak).equals("P") == false && (_karak).equals("Q") == false && (_karak).equals("R") == false && (_karak).equals("S") == false && (_karak).equals("T") == false && (_karak).equals("U") == false && (_karak).equals("V") == false && (_karak).equals("W") == false && (_karak).equals("X") == false && (_karak).equals("Y") == false && (_karak).equals("Z") == false && (_karak).equals("-") == false && (_karak).equals(".") == false && (_karak).equals(" ") == false && (_karak).equals("$") == false && (_karak).equals("/") == false && (_karak).equals("+") == false && (_karak).equals("%") == false) { 
 //BA.debugLineNum = 80;BA.debugLine="flag = 1";
_flag = (int) (1);
 //BA.debugLineNum = 81;BA.debugLine="Exit";
if (true) break;
 };
 //BA.debugLineNum = 83;BA.debugLine="new_mes = new_mes & karak";
_new_mes = _new_mes+_karak;
 }
};
 //BA.debugLineNum = 86;BA.debugLine="message = new_mes";
_message = _new_mes;
 //BA.debugLineNum = 89;BA.debugLine="If flag = 0 Then";
if (_flag==0) { 
 //BA.debugLineNum = 90;BA.debugLine="message = build_string(message)";
_message = _build_string(_message);
 };
 //BA.debugLineNum = 93;BA.debugLine="If flag = 1 Then";
if (_flag==1) { 
 };
 //BA.debugLineNum = 97;BA.debugLine="Return message";
if (true) return _message;
 //BA.debugLineNum = 99;BA.debugLine="End Sub";
return "";
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 2;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 3;BA.debugLine="Private fx As JFX";
_fx = new anywheresoftware.b4j.objects.JFX();
 //BA.debugLineNum = 4;BA.debugLine="Private start As String";
_start = "";
 //BA.debugLineNum = 5;BA.debugLine="Private fin As String";
_fin = "";
 //BA.debugLineNum = 6;BA.debugLine="Private su As StringUtilities";
_su = new b4j.example.stringutilities();
 //BA.debugLineNum = 8;BA.debugLine="Private bs, bs1 As String";
_bs = "";
_bs1 = "";
 //BA.debugLineNum = 9;BA.debugLine="Private bcolor As Int 'Ignore";
_bcolor = 0;
 //BA.debugLineNum = 10;BA.debugLine="Private fcolor As Int	'Ignore";
_fcolor = 0;
 //BA.debugLineNum = 11;BA.debugLine="End Sub";
return "";
}
}
