package b4j.example;


import anywheresoftware.b4a.BA;

public class printerjob_static extends Object{
public static printerjob_static mostCurrent = new printerjob_static();

public static BA ba;
static {
		ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.printerjob_static", null);
		ba.loadHtSubs(printerjob_static.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.printerjob_static", ba);
		}
	}
    public static Class<?> getObject() {
		return printerjob_static.class;
	}

 public static anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4j.objects.JFX _fx = null;
public static b4j.example.dateutils _dateutils = null;
public static b4j.example.cssutils _cssutils = null;
public static b4j.example.main _main = null;
public static b4j.example.pageorientation_static _pageorientation_static = null;
public static b4j.example.printer_static _printer_static = null;
public static b4j.example.paper_static _paper_static = null;
public static b4j.example.utils _utils = null;
public static b4j.example.adhocwrappers _adhocwrappers = null;
public static b4j.example.code39 _code39 = null;
public static b4j.example.xuiviewsutils _xuiviewsutils = null;
public static class _pagerange{
public boolean IsInitialized;
public int StartPage;
public int EndPage;
public void Initialize() {
IsInitialized = true;
StartPage = 0;
EndPage = 0;
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public static class _printresolution{
public boolean IsInitialized;
public int CrossFeedResolution;
public int FeedResolution;
public void Initialize() {
IsInitialized = true;
CrossFeedResolution = 0;
FeedResolution = 0;
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public static b4j.example.printerjob  _createprinterjob() throws Exception{
anywheresoftware.b4j.object.JavaObject _pjo = null;
b4j.example.printerjob _pj = null;
 //BA.debugLineNum = 9;BA.debugLine="Public Sub CreatePrinterJob As PrinterJob";
 //BA.debugLineNum = 10;BA.debugLine="Dim PJO As JavaObject";
_pjo = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 11;BA.debugLine="PJO.InitializeStatic(\"javafx.print.PrinterJob\")";
_pjo.InitializeStatic("javafx.print.PrinterJob");
 //BA.debugLineNum = 12;BA.debugLine="Dim PJ As PrinterJob";
_pj = new b4j.example.printerjob();
 //BA.debugLineNum = 13;BA.debugLine="PJ.Initialize";
_pj._initialize /*String*/ (ba);
 //BA.debugLineNum = 14;BA.debugLine="PJ.SetObject(PJO.RunMethod(\"createPrinterJob\",Nul";
_pj._setobject /*String*/ (_pjo.RunMethod("createPrinterJob",(Object[])(anywheresoftware.b4a.keywords.Common.Null)));
 //BA.debugLineNum = 15;BA.debugLine="Return PJ";
if (true) return _pj;
 //BA.debugLineNum = 16;BA.debugLine="End Sub";
return null;
}
public static b4j.example.printerjob  _createprinterjob2(b4j.example.printer _tprinter) throws Exception{
anywheresoftware.b4j.object.JavaObject _pjo = null;
b4j.example.printerjob _pj = null;
 //BA.debugLineNum = 18;BA.debugLine="Public Sub CreatePrinterJob2(TPrinter As Printer)";
 //BA.debugLineNum = 19;BA.debugLine="Dim PJO As JavaObject";
_pjo = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 20;BA.debugLine="PJO.InitializeStatic(\"javafx.print.PrinterJob\")";
_pjo.InitializeStatic("javafx.print.PrinterJob");
 //BA.debugLineNum = 21;BA.debugLine="Dim PJ As PrinterJob";
_pj = new b4j.example.printerjob();
 //BA.debugLineNum = 22;BA.debugLine="PJ.Initialize";
_pj._initialize /*String*/ (ba);
 //BA.debugLineNum = 23;BA.debugLine="PJ.SetObject(PJO.RunMethod(\"createPrinterJob\",Arr";
_pj._setobject /*String*/ (_pjo.RunMethod("createPrinterJob",new Object[]{_tprinter._getobject /*Object*/ ()}));
 //BA.debugLineNum = 24;BA.debugLine="Return PJ";
if (true) return _pj;
 //BA.debugLineNum = 25;BA.debugLine="End Sub";
return null;
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 2;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 3;BA.debugLine="Private fx As JFX";
_fx = new anywheresoftware.b4j.objects.JFX();
 //BA.debugLineNum = 4;BA.debugLine="Type PageRange(StartPage As Int,EndPage As Int)";
;
 //BA.debugLineNum = 5;BA.debugLine="Type PrintResolution(CrossFeedResolution As Int,F";
;
 //BA.debugLineNum = 7;BA.debugLine="End Sub";
return "";
}
}
