package b4j.example;


import anywheresoftware.b4a.BA;

public class paper_static extends Object{
public static paper_static mostCurrent = new paper_static();

public static BA ba;
static {
		ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.paper_static", null);
		ba.loadHtSubs(paper_static.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.paper_static", ba);
		}
	}
    public static Class<?> getObject() {
		return paper_static.class;
	}

 public static anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4j.object.JavaObject _paperjo = null;
public static b4j.example.paper _a0 = null;
public static b4j.example.paper _a1 = null;
public static b4j.example.paper _a2 = null;
public static b4j.example.paper _a3 = null;
public static b4j.example.paper _a4 = null;
public static b4j.example.paper _a5 = null;
public static b4j.example.paper _a6 = null;
public static b4j.example.paper _c = null;
public static b4j.example.paper _designated_long = null;
public static b4j.example.paper _executive = null;
public static b4j.example.paper _japanese_postcard = null;
public static b4j.example.paper _jis_b4 = null;
public static b4j.example.paper _jis_b5 = null;
public static b4j.example.paper _jis_b6 = null;
public static b4j.example.paper _legal = null;
public static b4j.example.paper _monarch_envelope = null;
public static b4j.example.paper _na_8x10 = null;
public static b4j.example.paper _na_letter = null;
public static b4j.example.paper _na_number_10_envelope = null;
public static b4j.example.paper _tabloid = null;
public static boolean _misinitialized = false;
public static b4j.example.dateutils _dateutils = null;
public static b4j.example.cssutils _cssutils = null;
public static b4j.example.main _main = null;
public static b4j.example.printerjob_static _printerjob_static = null;
public static b4j.example.pageorientation_static _pageorientation_static = null;
public static b4j.example.printer_static _printer_static = null;
public static b4j.example.utils _utils = null;
public static b4j.example.adhocwrappers _adhocwrappers = null;
public static b4j.example.code39 _code39 = null;
public static b4j.example.xuiviewsutils _xuiviewsutils = null;
public static anywheresoftware.b4j.object.JavaObject  _getobject() throws Exception{
 //BA.debugLineNum = 127;BA.debugLine="Public Sub getObject As JavaObject";
 //BA.debugLineNum = 128;BA.debugLine="Return PaperJO";
if (true) return _paperjo;
 //BA.debugLineNum = 129;BA.debugLine="End Sub";
return null;
}
public static String  _initialize() throws Exception{
 //BA.debugLineNum = 58;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 59;BA.debugLine="PaperJO.InitializeStatic(\"javafx.print.Paper\")";
_paperjo.InitializeStatic("javafx.print.Paper");
 //BA.debugLineNum = 60;BA.debugLine="If Not(PageOrientation_Static.IsInitialized) Then";
if (anywheresoftware.b4a.keywords.Common.Not(_pageorientation_static._isinitialized /*boolean*/ ())) { 
_pageorientation_static._initialize /*String*/ ();};
 //BA.debugLineNum = 61;BA.debugLine="UpdateConstants";
_updateconstants();
 //BA.debugLineNum = 62;BA.debugLine="mIsInitialized = True";
_misinitialized = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 63;BA.debugLine="End Sub";
return "";
}
public static boolean  _isinitialized() throws Exception{
 //BA.debugLineNum = 130;BA.debugLine="Public Sub IsInitialized As Boolean";
 //BA.debugLineNum = 131;BA.debugLine="Return mIsInitialized";
if (true) return _misinitialized;
 //BA.debugLineNum = 132;BA.debugLine="End Sub";
return false;
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 2;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 9;BA.debugLine="Private PaperJO As JavaObject";
_paperjo = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 13;BA.debugLine="Public Const A0 As Paper";
_a0 = new b4j.example.paper();
 //BA.debugLineNum = 15;BA.debugLine="Public Const A1 As Paper";
_a1 = new b4j.example.paper();
 //BA.debugLineNum = 17;BA.debugLine="Public Const A2 As Paper";
_a2 = new b4j.example.paper();
 //BA.debugLineNum = 19;BA.debugLine="Public Const A3 As Paper";
_a3 = new b4j.example.paper();
 //BA.debugLineNum = 21;BA.debugLine="Public Const A4 As Paper";
_a4 = new b4j.example.paper();
 //BA.debugLineNum = 23;BA.debugLine="Public Const A5 As Paper";
_a5 = new b4j.example.paper();
 //BA.debugLineNum = 25;BA.debugLine="Public Const A6 As Paper";
_a6 = new b4j.example.paper();
 //BA.debugLineNum = 27;BA.debugLine="Public Const C As Paper";
_c = new b4j.example.paper();
 //BA.debugLineNum = 29;BA.debugLine="Public Const DESIGNATED_LONG As Paper";
_designated_long = new b4j.example.paper();
 //BA.debugLineNum = 31;BA.debugLine="Public Const EXECUTIVE As Paper";
_executive = new b4j.example.paper();
 //BA.debugLineNum = 33;BA.debugLine="Public Const JAPANESE_POSTCARD As Paper";
_japanese_postcard = new b4j.example.paper();
 //BA.debugLineNum = 35;BA.debugLine="Public Const JIS_B4 As Paper";
_jis_b4 = new b4j.example.paper();
 //BA.debugLineNum = 37;BA.debugLine="Public Const JIS_B5 As Paper";
_jis_b5 = new b4j.example.paper();
 //BA.debugLineNum = 39;BA.debugLine="Public Const JIS_B6 As Paper";
_jis_b6 = new b4j.example.paper();
 //BA.debugLineNum = 41;BA.debugLine="Public Const LEGAL As Paper";
_legal = new b4j.example.paper();
 //BA.debugLineNum = 43;BA.debugLine="Public Const MONARCH_ENVELOPE As Paper";
_monarch_envelope = new b4j.example.paper();
 //BA.debugLineNum = 45;BA.debugLine="Public Const NA_8X10 As Paper";
_na_8x10 = new b4j.example.paper();
 //BA.debugLineNum = 47;BA.debugLine="Public Const NA_LETTER As Paper";
_na_letter = new b4j.example.paper();
 //BA.debugLineNum = 49;BA.debugLine="Public Const NA_NUMBER_10_ENVELOPE As Paper";
_na_number_10_envelope = new b4j.example.paper();
 //BA.debugLineNum = 51;BA.debugLine="Public Const TABLOID As Paper";
_tabloid = new b4j.example.paper();
 //BA.debugLineNum = 53;BA.debugLine="Private mIsInitialized As Boolean";
_misinitialized = false;
 //BA.debugLineNum = 55;BA.debugLine="End Sub";
return "";
}
public static String  _updateconstants() throws Exception{
 //BA.debugLineNum = 65;BA.debugLine="Private Sub UpdateConstants";
 //BA.debugLineNum = 67;BA.debugLine="A0.Initialize";
_a0._initialize /*String*/ (ba);
 //BA.debugLineNum = 68;BA.debugLine="A0.SetObject(PaperJO.GetField(\"A0\"))";
_a0._setobject /*String*/ ((anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_paperjo.GetField("A0"))));
 //BA.debugLineNum = 70;BA.debugLine="A1.Initialize";
_a1._initialize /*String*/ (ba);
 //BA.debugLineNum = 71;BA.debugLine="A1.SetObject(PaperJO.GetField(\"A1\"))";
_a1._setobject /*String*/ ((anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_paperjo.GetField("A1"))));
 //BA.debugLineNum = 73;BA.debugLine="A2.Initialize";
_a2._initialize /*String*/ (ba);
 //BA.debugLineNum = 74;BA.debugLine="A2.SetObject(PaperJO.GetField(\"A2\"))";
_a2._setobject /*String*/ ((anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_paperjo.GetField("A2"))));
 //BA.debugLineNum = 76;BA.debugLine="A3.Initialize";
_a3._initialize /*String*/ (ba);
 //BA.debugLineNum = 77;BA.debugLine="A3.SetObject(PaperJO.GetField(\"A3\"))";
_a3._setobject /*String*/ ((anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_paperjo.GetField("A3"))));
 //BA.debugLineNum = 79;BA.debugLine="A4.Initialize";
_a4._initialize /*String*/ (ba);
 //BA.debugLineNum = 80;BA.debugLine="A4.SetObject(PaperJO.GetField(\"A4\"))";
_a4._setobject /*String*/ ((anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_paperjo.GetField("A4"))));
 //BA.debugLineNum = 82;BA.debugLine="A5.Initialize";
_a5._initialize /*String*/ (ba);
 //BA.debugLineNum = 83;BA.debugLine="A5.SetObject(PaperJO.GetField(\"A5\"))";
_a5._setobject /*String*/ ((anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_paperjo.GetField("A5"))));
 //BA.debugLineNum = 85;BA.debugLine="A6.Initialize";
_a6._initialize /*String*/ (ba);
 //BA.debugLineNum = 86;BA.debugLine="A6.SetObject(PaperJO.GetField(\"A6\"))";
_a6._setobject /*String*/ ((anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_paperjo.GetField("A6"))));
 //BA.debugLineNum = 88;BA.debugLine="C.Initialize";
_c._initialize /*String*/ (ba);
 //BA.debugLineNum = 89;BA.debugLine="C.SetObject(PaperJO.GetField(\"C\"))";
_c._setobject /*String*/ ((anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_paperjo.GetField("C"))));
 //BA.debugLineNum = 91;BA.debugLine="DESIGNATED_LONG.Initialize";
_designated_long._initialize /*String*/ (ba);
 //BA.debugLineNum = 92;BA.debugLine="DESIGNATED_LONG.SetObject(PaperJO.GetField(\"DESIG";
_designated_long._setobject /*String*/ ((anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_paperjo.GetField("DESIGNATED_LONG"))));
 //BA.debugLineNum = 94;BA.debugLine="EXECUTIVE.Initialize";
_executive._initialize /*String*/ (ba);
 //BA.debugLineNum = 95;BA.debugLine="EXECUTIVE.SetObject(PaperJO.GetField(\"EXECUTIVE\")";
_executive._setobject /*String*/ ((anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_paperjo.GetField("EXECUTIVE"))));
 //BA.debugLineNum = 97;BA.debugLine="JAPANESE_POSTCARD.Initialize";
_japanese_postcard._initialize /*String*/ (ba);
 //BA.debugLineNum = 98;BA.debugLine="JAPANESE_POSTCARD.SetObject(PaperJO.GetField(\"JAP";
_japanese_postcard._setobject /*String*/ ((anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_paperjo.GetField("JAPANESE_POSTCARD"))));
 //BA.debugLineNum = 100;BA.debugLine="JIS_B4.Initialize";
_jis_b4._initialize /*String*/ (ba);
 //BA.debugLineNum = 101;BA.debugLine="JIS_B4.SetObject(PaperJO.GetField(\"JIS_B4\"))";
_jis_b4._setobject /*String*/ ((anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_paperjo.GetField("JIS_B4"))));
 //BA.debugLineNum = 103;BA.debugLine="JIS_B5.Initialize";
_jis_b5._initialize /*String*/ (ba);
 //BA.debugLineNum = 104;BA.debugLine="JIS_B5.SetObject(PaperJO.GetField(\"JIS_B5\"))";
_jis_b5._setobject /*String*/ ((anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_paperjo.GetField("JIS_B5"))));
 //BA.debugLineNum = 106;BA.debugLine="JIS_B6.Initialize";
_jis_b6._initialize /*String*/ (ba);
 //BA.debugLineNum = 107;BA.debugLine="JIS_B6.SetObject(PaperJO.GetField(\"JIS_B6\"))";
_jis_b6._setobject /*String*/ ((anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_paperjo.GetField("JIS_B6"))));
 //BA.debugLineNum = 109;BA.debugLine="LEGAL.Initialize";
_legal._initialize /*String*/ (ba);
 //BA.debugLineNum = 110;BA.debugLine="LEGAL.SetObject(PaperJO.GetField(\"LEGAL\"))";
_legal._setobject /*String*/ ((anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_paperjo.GetField("LEGAL"))));
 //BA.debugLineNum = 112;BA.debugLine="MONARCH_ENVELOPE.Initialize";
_monarch_envelope._initialize /*String*/ (ba);
 //BA.debugLineNum = 113;BA.debugLine="MONARCH_ENVELOPE.SetObject(PaperJO.GetField(\"MONA";
_monarch_envelope._setobject /*String*/ ((anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_paperjo.GetField("MONARCH_ENVELOPE"))));
 //BA.debugLineNum = 115;BA.debugLine="NA_8X10.Initialize";
_na_8x10._initialize /*String*/ (ba);
 //BA.debugLineNum = 116;BA.debugLine="NA_8X10.SetObject(PaperJO.GetField(\"NA_8X10\"))";
_na_8x10._setobject /*String*/ ((anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_paperjo.GetField("NA_8X10"))));
 //BA.debugLineNum = 118;BA.debugLine="NA_LETTER.Initialize";
_na_letter._initialize /*String*/ (ba);
 //BA.debugLineNum = 119;BA.debugLine="NA_LETTER.SetObject(PaperJO.GetField(\"NA_LETTER\")";
_na_letter._setobject /*String*/ ((anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_paperjo.GetField("NA_LETTER"))));
 //BA.debugLineNum = 121;BA.debugLine="NA_NUMBER_10_ENVELOPE.Initialize";
_na_number_10_envelope._initialize /*String*/ (ba);
 //BA.debugLineNum = 122;BA.debugLine="NA_NUMBER_10_ENVELOPE.SetObject(PaperJO.GetField(";
_na_number_10_envelope._setobject /*String*/ ((anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_paperjo.GetField("NA_NUMBER_10_ENVELOPE"))));
 //BA.debugLineNum = 124;BA.debugLine="TABLOID.Initialize";
_tabloid._initialize /*String*/ (ba);
 //BA.debugLineNum = 125;BA.debugLine="TABLOID.SetObject(PaperJO.GetField(\"TABLOID\"))";
_tabloid._setobject /*String*/ ((anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_paperjo.GetField("TABLOID"))));
 //BA.debugLineNum = 126;BA.debugLine="End Sub";
return "";
}
}
