package b4j.example;


import anywheresoftware.b4a.BA;

public class printer_static extends Object{
public static printer_static mostCurrent = new printer_static();

public static BA ba;
static {
		ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.printer_static", null);
		ba.loadHtSubs(printer_static.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.printer_static", ba);
		}
	}
    public static Class<?> getObject() {
		return printer_static.class;
	}

 public static anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4j.objects.JFX _fx = null;
public static anywheresoftware.b4a.objects.collections.Map _mprintermap = null;
public static b4j.example.dateutils _dateutils = null;
public static b4j.example.cssutils _cssutils = null;
public static b4j.example.main _main = null;
public static b4j.example.printerjob_static _printerjob_static = null;
public static b4j.example.pageorientation_static _pageorientation_static = null;
public static b4j.example.paper_static _paper_static = null;
public static b4j.example.utils _utils = null;
public static b4j.example.adhocwrappers _adhocwrappers = null;
public static b4j.example.code39 _code39 = null;
public static b4j.example.xuiviewsutils _xuiviewsutils = null;
public static anywheresoftware.b4a.objects.collections.List  _getallprinters() throws Exception{
anywheresoftware.b4a.objects.collections.List _l = null;
anywheresoftware.b4j.object.JavaObject _jo = null;
anywheresoftware.b4j.object.JavaObject _os = null;
anywheresoftware.b4j.object.JavaObject _iterator = null;
b4j.example.printer _p = null;
 //BA.debugLineNum = 25;BA.debugLine="Public Sub GetAllPrinters As List";
 //BA.debugLineNum = 26;BA.debugLine="If Not(mPrinterMap.IsInitialized) Then mPrinterMa";
if (anywheresoftware.b4a.keywords.Common.Not(_mprintermap.IsInitialized())) { 
_mprintermap.Initialize();};
 //BA.debugLineNum = 27;BA.debugLine="mPrinterMap.Clear";
_mprintermap.Clear();
 //BA.debugLineNum = 29;BA.debugLine="Dim L As List";
_l = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 30;BA.debugLine="L.Initialize";
_l.Initialize();
 //BA.debugLineNum = 31;BA.debugLine="Dim JO As JavaObject";
_jo = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 32;BA.debugLine="JO.InitializeStatic(\"javafx.print.Printer\")";
_jo.InitializeStatic("javafx.print.Printer");
 //BA.debugLineNum = 33;BA.debugLine="Dim OS As JavaObject = JO.RunMethod(\"getAllPrinte";
_os = new anywheresoftware.b4j.object.JavaObject();
_os = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_jo.RunMethod("getAllPrinters",(Object[])(anywheresoftware.b4a.keywords.Common.Null))));
 //BA.debugLineNum = 35;BA.debugLine="Dim Iterator As JavaObject = OS.RunMethod(\"ite";
_iterator = new anywheresoftware.b4j.object.JavaObject();
_iterator = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_os.RunMethod("iterator",(Object[])(anywheresoftware.b4a.keywords.Common.Null))));
 //BA.debugLineNum = 37;BA.debugLine="Do While Iterator.RunMethod(\"hasNext\",Null)";
while (BA.ObjectToBoolean(_iterator.RunMethod("hasNext",(Object[])(anywheresoftware.b4a.keywords.Common.Null)))) {
 //BA.debugLineNum = 38;BA.debugLine="Dim P As Printer";
_p = new b4j.example.printer();
 //BA.debugLineNum = 39;BA.debugLine="P.Initialize";
_p._initialize /*String*/ (ba);
 //BA.debugLineNum = 40;BA.debugLine="P.SetObject(Iterator.RunMethod(\"next\",Null))";
_p._setobject /*String*/ (_iterator.RunMethod("next",(Object[])(anywheresoftware.b4a.keywords.Common.Null)));
 //BA.debugLineNum = 41;BA.debugLine="L.Add(P)";
_l.Add((Object)(_p));
 //BA.debugLineNum = 42;BA.debugLine="mPrinterMap.Put(P.GetObject,P)";
_mprintermap.Put(_p._getobject /*Object*/ (),(Object)(_p));
 }
;
 //BA.debugLineNum = 44;BA.debugLine="Return L";
if (true) return _l;
 //BA.debugLineNum = 45;BA.debugLine="End Sub";
return null;
}
public static b4j.example.printer  _getdefaultprinter() throws Exception{
anywheresoftware.b4j.object.JavaObject _printr = null;
b4j.example.printer _p = null;
 //BA.debugLineNum = 7;BA.debugLine="Public Sub GetDefaultPrinter As Printer";
 //BA.debugLineNum = 9;BA.debugLine="Dim Printr As JavaObject";
_printr = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 10;BA.debugLine="Printr.InitializeStatic(\"javafx.print.Printer\")";
_printr.InitializeStatic("javafx.print.Printer");
 //BA.debugLineNum = 11;BA.debugLine="Dim P As Printer";
_p = new b4j.example.printer();
 //BA.debugLineNum = 12;BA.debugLine="P.Initialize";
_p._initialize /*String*/ (ba);
 //BA.debugLineNum = 13;BA.debugLine="P.SetObject(Printr.RunMethod(\"getDefaultPrinter\",";
_p._setobject /*String*/ (_printr.RunMethod("getDefaultPrinter",(Object[])(anywheresoftware.b4a.keywords.Common.Null)));
 //BA.debugLineNum = 14;BA.debugLine="If Not(mPrinterMap.IsInitialized) Then";
if (anywheresoftware.b4a.keywords.Common.Not(_mprintermap.IsInitialized())) { 
 //BA.debugLineNum = 15;BA.debugLine="mPrinterMap.Initialize";
_mprintermap.Initialize();
 //BA.debugLineNum = 16;BA.debugLine="mPrinterMap.Put(P.GetObject,P)";
_mprintermap.Put(_p._getobject /*Object*/ (),(Object)(_p));
 }else {
 //BA.debugLineNum = 18;BA.debugLine="If Not(mPrinterMap.ContainsKey(P.GetObject)) The";
if (anywheresoftware.b4a.keywords.Common.Not(_mprintermap.ContainsKey(_p._getobject /*Object*/ ()))) { 
 //BA.debugLineNum = 19;BA.debugLine="mPrinterMap.Put(P.GetObject,P)";
_mprintermap.Put(_p._getobject /*Object*/ (),(Object)(_p));
 };
 };
 //BA.debugLineNum = 22;BA.debugLine="Return P";
if (true) return _p;
 //BA.debugLineNum = 23;BA.debugLine="End Sub";
return null;
}
public static b4j.example.printer  _mappedprinter(Object _source) throws Exception{
 //BA.debugLineNum = 46;BA.debugLine="Sub MappedPrinter(Source As Object) As Printer";
 //BA.debugLineNum = 47;BA.debugLine="If Not(mPrinterMap.IsInitialized) Then GetAllPrin";
if (anywheresoftware.b4a.keywords.Common.Not(_mprintermap.IsInitialized())) { 
_getallprinters();};
 //BA.debugLineNum = 48;BA.debugLine="Return mPrinterMap.Get(Source)";
if (true) return (b4j.example.printer)(_mprintermap.Get(_source));
 //BA.debugLineNum = 49;BA.debugLine="End Sub";
return null;
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 2;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 3;BA.debugLine="Private fx As JFX";
_fx = new anywheresoftware.b4j.objects.JFX();
 //BA.debugLineNum = 4;BA.debugLine="Dim mPrinterMap As Map";
_mprintermap = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 5;BA.debugLine="End Sub";
return "";
}
}
