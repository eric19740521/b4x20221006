package b4j.example;


import anywheresoftware.b4a.BA;

public class pageorientation_static extends Object{
public static pageorientation_static mostCurrent = new pageorientation_static();

public static BA ba;
static {
		ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.pageorientation_static", null);
		ba.loadHtSubs(pageorientation_static.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.pageorientation_static", ba);
		}
	}
    public static Class<?> getObject() {
		return pageorientation_static.class;
	}

 public static anywheresoftware.b4a.keywords.Common __c = null;
public static String _landscape = "";
public static String _portrait = "";
public static String _reverse_landscape = "";
public static String _reverse_portrait = "";
public static anywheresoftware.b4j.object.JavaObject _jopo = null;
public static boolean _minitialized = false;
public static b4j.example.dateutils _dateutils = null;
public static b4j.example.cssutils _cssutils = null;
public static b4j.example.main _main = null;
public static b4j.example.printerjob_static _printerjob_static = null;
public static b4j.example.printer_static _printer_static = null;
public static b4j.example.paper_static _paper_static = null;
public static b4j.example.utils _utils = null;
public static b4j.example.adhocwrappers _adhocwrappers = null;
public static b4j.example.code39 _code39 = null;
public static b4j.example.xuiviewsutils _xuiviewsutils = null;
public static Object  _getobject() throws Exception{
 //BA.debugLineNum = 39;BA.debugLine="Public Sub GetObject As Object";
 //BA.debugLineNum = 40;BA.debugLine="Return JOPO";
if (true) return (Object)(_jopo.getObject());
 //BA.debugLineNum = 41;BA.debugLine="End Sub";
return null;
}
public static String  _initialize() throws Exception{
 //BA.debugLineNum = 21;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 23;BA.debugLine="JOPO.InitializeStatic(\"javafx.print.PageOrientati";
_jopo.InitializeStatic("javafx.print.PageOrientation");
 //BA.debugLineNum = 24;BA.debugLine="UpdateConstants";
_updateconstants();
 //BA.debugLineNum = 25;BA.debugLine="mInitialized = True";
_minitialized = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 26;BA.debugLine="End Sub";
return "";
}
public static boolean  _isinitialized() throws Exception{
 //BA.debugLineNum = 50;BA.debugLine="Sub IsInitialized As Boolean";
 //BA.debugLineNum = 51;BA.debugLine="Return mInitialized";
if (true) return _minitialized;
 //BA.debugLineNum = 52;BA.debugLine="End Sub";
return false;
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 2;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Public LANDSCAPE As String";
_landscape = "";
 //BA.debugLineNum = 9;BA.debugLine="Public PORTRAIT As String";
_portrait = "";
 //BA.debugLineNum = 11;BA.debugLine="Public REVERSE_LANDSCAPE As String";
_reverse_landscape = "";
 //BA.debugLineNum = 13;BA.debugLine="Public REVERSE_PORTRAIT As String";
_reverse_portrait = "";
 //BA.debugLineNum = 15;BA.debugLine="Private JOPO As JavaObject";
_jopo = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 17;BA.debugLine="Private mInitialized As Boolean";
_minitialized = false;
 //BA.debugLineNum = 19;BA.debugLine="End Sub";
return "";
}
public static String  _updateconstants() throws Exception{
 //BA.debugLineNum = 44;BA.debugLine="Private Sub UpdateConstants";
 //BA.debugLineNum = 45;BA.debugLine="LANDSCAPE = JOPO.RunMethod(\"valueOf\",Array(\"LANDS";
_landscape = BA.ObjectToString(_jopo.RunMethod("valueOf",new Object[]{(Object)("LANDSCAPE")}));
 //BA.debugLineNum = 46;BA.debugLine="PORTRAIT = JOPO.RunMethod(\"valueOf\",Array(\"PORTRA";
_portrait = BA.ObjectToString(_jopo.RunMethod("valueOf",new Object[]{(Object)("PORTRAIT")}));
 //BA.debugLineNum = 47;BA.debugLine="REVERSE_LANDSCAPE = JOPO.RunMethod(\"valueOf\",Arra";
_reverse_landscape = BA.ObjectToString(_jopo.RunMethod("valueOf",new Object[]{(Object)("REVERSE_LANDSCAPE")}));
 //BA.debugLineNum = 48;BA.debugLine="REVERSE_PORTRAIT = JOPO.RunMethod(\"valueOf\",Array";
_reverse_portrait = BA.ObjectToString(_jopo.RunMethod("valueOf",new Object[]{(Object)("REVERSE_PORTRAIT")}));
 //BA.debugLineNum = 49;BA.debugLine="End Sub";
return "";
}
public static String  _valueof(String _name) throws Exception{
 //BA.debugLineNum = 29;BA.debugLine="Public Sub ValueOf(Name As String) As String";
 //BA.debugLineNum = 30;BA.debugLine="JOPO.InitializeStatic(\"javafx.print.PageOrientati";
_jopo.InitializeStatic("javafx.print.PageOrientation");
 //BA.debugLineNum = 31;BA.debugLine="Return 	JOPO.RunMethod(\"valueOf\",Array As Object(";
if (true) return BA.ObjectToString(_jopo.RunMethod("valueOf",new Object[]{(Object)(_name)}));
 //BA.debugLineNum = 32;BA.debugLine="End Sub";
return "";
}
public static String[]  _values() throws Exception{
anywheresoftware.b4j.object.JavaObject _jo = null;
 //BA.debugLineNum = 34;BA.debugLine="Public Sub Values As String()";
 //BA.debugLineNum = 35;BA.debugLine="Dim JO As JavaObject";
_jo = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 36;BA.debugLine="JO.InitializeStatic(\"javafx.print.PageOrientation";
_jo.InitializeStatic("javafx.print.PageOrientation");
 //BA.debugLineNum = 37;BA.debugLine="Return JO.RunMethod(\"values\",Null)";
if (true) return (String[])(_jo.RunMethod("values",(Object[])(anywheresoftware.b4a.keywords.Common.Null)));
 //BA.debugLineNum = 38;BA.debugLine="End Sub";
return null;
}
}
