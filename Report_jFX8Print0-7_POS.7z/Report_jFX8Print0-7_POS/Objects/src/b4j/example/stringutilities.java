package b4j.example;

import java.text.ParseException;
import java.lang.String;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class stringutilities extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.stringutilities", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.example.stringutilities.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4j.objects.JFX _fx = null;
public anywheresoftware.b4j.object.JavaObject _nativeme = null;
public b4j.example.dateutils _dateutils = null;
public b4j.example.cssutils _cssutils = null;
public b4j.example.main _main = null;
public b4j.example.printerjob_static _printerjob_static = null;
public b4j.example.pageorientation_static _pageorientation_static = null;
public b4j.example.printer_static _printer_static = null;
public b4j.example.paper_static _paper_static = null;
public b4j.example.utils _utils = null;
public b4j.example.adhocwrappers _adhocwrappers = null;
public b4j.example.code39 _code39 = null;
public b4j.example.xuiviewsutils _xuiviewsutils = null;
public String  _chararraytostring(char[] _chararray) throws Exception{
String _chartostring = "";
 //BA.debugLineNum = 397;BA.debugLine="Public Sub charArrayToString (charArray() As Char)";
 //BA.debugLineNum = 398;BA.debugLine="Dim charToString As String";
_chartostring = "";
 //BA.debugLineNum = 399;BA.debugLine="charToString = nativeMe.RunMethod(\"charArrayToStr";
_chartostring = BA.ObjectToString(_nativeme.RunMethod("charArrayToString",new Object[]{(Object)(_chararray)}));
 //BA.debugLineNum = 400;BA.debugLine="Return charToString";
if (true) return _chartostring;
 //BA.debugLineNum = 401;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 2;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 3;BA.debugLine="Private fx As JFX";
_fx = new anywheresoftware.b4j.objects.JFX();
 //BA.debugLineNum = 4;BA.debugLine="Private nativeMe As JavaObject";
_nativeme = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 6;BA.debugLine="End Sub";
return "";
}
public boolean  _containstring(String _inputstring,String _substring) throws Exception{
boolean _contain = false;
 //BA.debugLineNum = 107;BA.debugLine="Public Sub containString (inputString As String, s";
 //BA.debugLineNum = 108;BA.debugLine="Dim contain As Boolean";
_contain = false;
 //BA.debugLineNum = 109;BA.debugLine="contain = nativeMe.RunMethod(\"containString\", Arr";
_contain = BA.ObjectToBoolean(_nativeme.RunMethod("containString",new Object[]{(Object)(_inputstring),(Object)(_substring)}));
 //BA.debugLineNum = 110;BA.debugLine="Return contain";
if (true) return _contain;
 //BA.debugLineNum = 111;BA.debugLine="End Sub";
return false;
}
public int  _count(String _inputstring,String _substring) throws Exception{
int _answer = 0;
 //BA.debugLineNum = 319;BA.debugLine="Public Sub count (inputString As String, subString";
 //BA.debugLineNum = 320;BA.debugLine="Dim answer As Int";
_answer = 0;
 //BA.debugLineNum = 321;BA.debugLine="answer = nativeMe.RunMethod(\"count\", Array (input";
_answer = (int)(BA.ObjectToNumber(_nativeme.RunMethod("count",new Object[]{(Object)(_inputstring),(Object)(_substring)})));
 //BA.debugLineNum = 322;BA.debugLine="Return answer";
if (true) return _answer;
 //BA.debugLineNum = 323;BA.debugLine="End Sub";
return 0;
}
public String  _difference(String _str1,String _str2) throws Exception{
String _dif = "";
 //BA.debugLineNum = 336;BA.debugLine="Public Sub difference (str1 As String, str2 As Str";
 //BA.debugLineNum = 337;BA.debugLine="Dim dif As String";
_dif = "";
 //BA.debugLineNum = 338;BA.debugLine="dif = nativeMe.RunMethod(\"difference\", Array (str";
_dif = BA.ObjectToString(_nativeme.RunMethod("difference",new Object[]{(Object)(_str1),(Object)(_str2)}));
 //BA.debugLineNum = 339;BA.debugLine="Return dif";
if (true) return _dif;
 //BA.debugLineNum = 340;BA.debugLine="End Sub";
return "";
}
public String  _doubletostring(double _number) throws Exception{
String _numbertostring = "";
 //BA.debugLineNum = 410;BA.debugLine="Public Sub doubleToString (number As Double) As St";
 //BA.debugLineNum = 411;BA.debugLine="Dim numberToString As String";
_numbertostring = "";
 //BA.debugLineNum = 412;BA.debugLine="numberToString = nativeMe.RunMethod(\"doubleToStri";
_numbertostring = BA.ObjectToString(_nativeme.RunMethod("doubleToString",new Object[]{(Object)(_number)}));
 //BA.debugLineNum = 413;BA.debugLine="Return numberToString";
if (true) return _numbertostring;
 //BA.debugLineNum = 414;BA.debugLine="End Sub";
return "";
}
public int  _indexofdifference(String _str1,String _str2) throws Exception{
String _index = "";
 //BA.debugLineNum = 352;BA.debugLine="Public Sub indexOfDifference (str1 As String, str2";
 //BA.debugLineNum = 353;BA.debugLine="Dim index As String";
_index = "";
 //BA.debugLineNum = 354;BA.debugLine="index = nativeMe.RunMethod(\"indexOfDifference\", A";
_index = BA.ObjectToString(_nativeme.RunMethod("indexOfDifference",new Object[]{(Object)(_str1),(Object)(_str2)}));
 //BA.debugLineNum = 355;BA.debugLine="Return index";
if (true) return (int)(Double.parseDouble(_index));
 //BA.debugLineNum = 356;BA.debugLine="End Sub";
return 0;
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 9;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 11;BA.debugLine="nativeMe = Me";
_nativeme = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(this));
 //BA.debugLineNum = 13;BA.debugLine="End Sub";
return "";
}
public String  _inttobinarystring(int _number) throws Exception{
String _numbertostring = "";
 //BA.debugLineNum = 436;BA.debugLine="Public Sub intToBinaryString (number As Int) As St";
 //BA.debugLineNum = 437;BA.debugLine="Dim numberToString As String";
_numbertostring = "";
 //BA.debugLineNum = 438;BA.debugLine="numberToString = nativeMe.RunMethod(\"intToBinaryS";
_numbertostring = BA.ObjectToString(_nativeme.RunMethod("intToBinaryString",new Object[]{(Object)(_number)}));
 //BA.debugLineNum = 439;BA.debugLine="Return numberToString";
if (true) return _numbertostring;
 //BA.debugLineNum = 440;BA.debugLine="End Sub";
return "";
}
public String  _inttohexstring(int _number) throws Exception{
String _numbertostring = "";
 //BA.debugLineNum = 475;BA.debugLine="Public Sub intToHexString (number As Int) As Strin";
 //BA.debugLineNum = 476;BA.debugLine="Dim numberToString As String";
_numbertostring = "";
 //BA.debugLineNum = 477;BA.debugLine="numberToString = nativeMe.RunMethod(\"intToHexStri";
_numbertostring = BA.ObjectToString(_nativeme.RunMethod("intToHexString",new Object[]{(Object)(_number)}));
 //BA.debugLineNum = 478;BA.debugLine="Return numberToString";
if (true) return _numbertostring;
 //BA.debugLineNum = 479;BA.debugLine="End Sub";
return "";
}
public String  _inttooctalstring(int _number) throws Exception{
String _numbertostring = "";
 //BA.debugLineNum = 462;BA.debugLine="Public Sub intToOctalString (number As Int) As Str";
 //BA.debugLineNum = 463;BA.debugLine="Dim numberToString As String";
_numbertostring = "";
 //BA.debugLineNum = 464;BA.debugLine="numberToString = nativeMe.RunMethod(\"intToOctalSt";
_numbertostring = BA.ObjectToString(_nativeme.RunMethod("intToOctalString",new Object[]{(Object)(_number)}));
 //BA.debugLineNum = 465;BA.debugLine="Return numberToString";
if (true) return _numbertostring;
 //BA.debugLineNum = 466;BA.debugLine="End Sub";
return "";
}
public String  _inttostring(int _number) throws Exception{
String _numbertostring = "";
 //BA.debugLineNum = 423;BA.debugLine="Public Sub intToString (number As Int) As String";
 //BA.debugLineNum = 424;BA.debugLine="Dim numberToString As String";
_numbertostring = "";
 //BA.debugLineNum = 425;BA.debugLine="numberToString = nativeMe.RunMethod(\"intToString\"";
_numbertostring = BA.ObjectToString(_nativeme.RunMethod("intToString",new Object[]{(Object)(_number)}));
 //BA.debugLineNum = 426;BA.debugLine="Return numberToString";
if (true) return _numbertostring;
 //BA.debugLineNum = 427;BA.debugLine="End Sub";
return "";
}
public boolean  _isempty(String _inputstring) throws Exception{
boolean _answer = false;
 //BA.debugLineNum = 302;BA.debugLine="Public Sub isEmpty (inputString As String) As Bool";
 //BA.debugLineNum = 303;BA.debugLine="Dim answer As Boolean";
_answer = false;
 //BA.debugLineNum = 304;BA.debugLine="answer = nativeMe.RunMethod(\"isEmpty\", Array (inp";
_answer = BA.ObjectToBoolean(_nativeme.RunMethod("isEmpty",new Object[]{(Object)(_inputstring)}));
 //BA.debugLineNum = 305;BA.debugLine="Return answer";
if (true) return _answer;
 //BA.debugLineNum = 306;BA.debugLine="End Sub";
return false;
}
public String  _left(String _inputstring,int _returnlength) throws Exception{
 //BA.debugLineNum = 249;BA.debugLine="Public Sub Left (inputString As String, returnLeng";
 //BA.debugLineNum = 250;BA.debugLine="inputString = nativeMe.RunMethod(\"Left\", Array (i";
_inputstring = BA.ObjectToString(_nativeme.RunMethod("Left",new Object[]{(Object)(_inputstring),(Object)(_returnlength)}));
 //BA.debugLineNum = 251;BA.debugLine="Return inputString";
if (true) return _inputstring;
 //BA.debugLineNum = 252;BA.debugLine="End Sub";
return "";
}
public String  _mid(String _inputstring,int _startindex,int _returnlength) throws Exception{
 //BA.debugLineNum = 264;BA.debugLine="Public Sub Mid (inputString As String, startIndex";
 //BA.debugLineNum = 265;BA.debugLine="inputString = nativeMe.RunMethod(\"Mid\", Array (in";
_inputstring = BA.ObjectToString(_nativeme.RunMethod("Mid",new Object[]{(Object)(_inputstring),(Object)(_startindex),(Object)(_returnlength)}));
 //BA.debugLineNum = 266;BA.debugLine="Return inputString";
if (true) return _inputstring;
 //BA.debugLineNum = 267;BA.debugLine="End Sub";
return "";
}
public String  _removecharatposition(String _inputstring,int _position) throws Exception{
String _returnstring = "";
 //BA.debugLineNum = 505;BA.debugLine="Public Sub removeCharAtPosition (inputString As St";
 //BA.debugLineNum = 506;BA.debugLine="Dim returnString As String";
_returnstring = "";
 //BA.debugLineNum = 507;BA.debugLine="returnString = nativeMe.RunMethod(\"removeCharAtPo";
_returnstring = BA.ObjectToString(_nativeme.RunMethod("removeCharAtPosition",new Object[]{(Object)(_inputstring),(Object)(_position)}));
 //BA.debugLineNum = 508;BA.debugLine="Return returnString";
if (true) return _returnstring;
 //BA.debugLineNum = 509;BA.debugLine="End Sub";
return "";
}
public String  _removecharfromstring(String _inputstring,char _removechar) throws Exception{
String _returnstring = "";
 //BA.debugLineNum = 489;BA.debugLine="Public Sub removeCharFromString (inputString As St";
 //BA.debugLineNum = 490;BA.debugLine="Dim returnString As String";
_returnstring = "";
 //BA.debugLineNum = 491;BA.debugLine="returnString = nativeMe.RunMethod(\"removeCharFrom";
_returnstring = BA.ObjectToString(_nativeme.RunMethod("removeCharFromString",new Object[]{(Object)(_inputstring),(Object)(_removechar)}));
 //BA.debugLineNum = 492;BA.debugLine="Return returnString";
if (true) return _returnstring;
 //BA.debugLineNum = 493;BA.debugLine="End Sub";
return "";
}
public String  _replacealloccur(String _inputstring,String _oldstring,String _newstring) throws Exception{
 //BA.debugLineNum = 95;BA.debugLine="Public Sub replaceAllOccur (inputString As String,";
 //BA.debugLineNum = 96;BA.debugLine="inputString = nativeMe.RunMethod(\"replaceAllOccur";
_inputstring = BA.ObjectToString(_nativeme.RunMethod("replaceAllOccur",new Object[]{(Object)(_inputstring),(Object)(_oldstring),(Object)(_newstring)}));
 //BA.debugLineNum = 97;BA.debugLine="Return inputString";
if (true) return _inputstring;
 //BA.debugLineNum = 98;BA.debugLine="End Sub";
return "";
}
public String  _replacechar(String _inputstring,char _oldchar,char _newchar) throws Exception{
 //BA.debugLineNum = 71;BA.debugLine="Public Sub replaceChar (inputString As String, old";
 //BA.debugLineNum = 72;BA.debugLine="inputString = nativeMe.RunMethod(\"replaceChar\", A";
_inputstring = BA.ObjectToString(_nativeme.RunMethod("replaceChar",new Object[]{(Object)(_inputstring),(Object)(_oldchar),(Object)(_newchar)}));
 //BA.debugLineNum = 73;BA.debugLine="Return inputString";
if (true) return _inputstring;
 //BA.debugLineNum = 74;BA.debugLine="End Sub";
return "";
}
public String  _replacefirstoccur(String _inputstring,String _oldstring,String _newstring) throws Exception{
 //BA.debugLineNum = 83;BA.debugLine="Public Sub replaceFirstOccur (inputString As Strin";
 //BA.debugLineNum = 84;BA.debugLine="inputString = nativeMe.RunMethod(\"replaceFirstOcc";
_inputstring = BA.ObjectToString(_nativeme.RunMethod("replaceFirstOccur",new Object[]{(Object)(_inputstring),(Object)(_oldstring),(Object)(_newstring)}));
 //BA.debugLineNum = 85;BA.debugLine="Return inputString";
if (true) return _inputstring;
 //BA.debugLineNum = 86;BA.debugLine="End Sub";
return "";
}
public String  _reversestring(String _origstring) throws Exception{
 //BA.debugLineNum = 21;BA.debugLine="Public Sub reverseString (origString As String) As";
 //BA.debugLineNum = 22;BA.debugLine="origString = nativeMe.RunMethod(\"reverseString\",";
_origstring = BA.ObjectToString(_nativeme.RunMethod("reverseString",new Object[]{(Object)(_origstring)}));
 //BA.debugLineNum = 23;BA.debugLine="Return origString";
if (true) return _origstring;
 //BA.debugLineNum = 24;BA.debugLine="End Sub";
return "";
}
public String  _right(String _inputstring,int _returnlength) throws Exception{
 //BA.debugLineNum = 237;BA.debugLine="Public Sub Right (inputString As String, returnLen";
 //BA.debugLineNum = 238;BA.debugLine="inputString = nativeMe.RunMethod(\"Right\", Array (";
_inputstring = BA.ObjectToString(_nativeme.RunMethod("Right",new Object[]{(Object)(_inputstring),(Object)(_returnlength)}));
 //BA.debugLineNum = 239;BA.debugLine="Return inputString";
if (true) return _inputstring;
 //BA.debugLineNum = 240;BA.debugLine="End Sub";
return "";
}
public String[]  _sortstringarraydecendingcaseinsensitive(String[] _strnames) throws Exception{
 //BA.debugLineNum = 193;BA.debugLine="Public Sub sortStringArrayDecendingCaseInSensitive";
 //BA.debugLineNum = 194;BA.debugLine="strNames = nativeMe.RunMethod(\"sortStringArrayDec";
_strnames = (String[])(_nativeme.RunMethod("sortStringArrayDecendingCaseInSensitive",new Object[]{(Object)(_strnames)}));
 //BA.debugLineNum = 195;BA.debugLine="Return strNames";
if (true) return _strnames;
 //BA.debugLineNum = 196;BA.debugLine="End Sub";
return null;
}
public String[]  _sortstringarraydecendingcasesensitive(String[] _strnames) throws Exception{
 //BA.debugLineNum = 178;BA.debugLine="Public Sub sortStringArrayDecendingCaseSensitive (";
 //BA.debugLineNum = 179;BA.debugLine="strNames = nativeMe.RunMethod(\"sortStringArrayDec";
_strnames = (String[])(_nativeme.RunMethod("sortStringArrayDecendingCaseSensitive",new Object[]{(Object)(_strnames)}));
 //BA.debugLineNum = 180;BA.debugLine="Return strNames";
if (true) return _strnames;
 //BA.debugLineNum = 181;BA.debugLine="End Sub";
return null;
}
public String[]  _sortstringcaseinsensitive(String[] _strnames) throws Exception{
 //BA.debugLineNum = 163;BA.debugLine="Public Sub sortStringCaseInSensitive (strNames() A";
 //BA.debugLineNum = 164;BA.debugLine="strNames = nativeMe.RunMethod(\"sortStringCaseInSe";
_strnames = (String[])(_nativeme.RunMethod("sortStringCaseInSensitive",new Object[]{(Object)(_strnames)}));
 //BA.debugLineNum = 165;BA.debugLine="Return strNames";
if (true) return _strnames;
 //BA.debugLineNum = 166;BA.debugLine="End Sub";
return null;
}
public String[]  _sortstringcasesensitive(String[] _strnames) throws Exception{
 //BA.debugLineNum = 148;BA.debugLine="Public Sub sortStringCaseSensitive (strNames() As";
 //BA.debugLineNum = 149;BA.debugLine="strNames = nativeMe.RunMethod(\"sortStringCaseSens";
_strnames = (String[])(_nativeme.RunMethod("sortStringCaseSensitive",new Object[]{(Object)(_strnames)}));
 //BA.debugLineNum = 150;BA.debugLine="Return strNames";
if (true) return _strnames;
 //BA.debugLineNum = 151;BA.debugLine="End Sub";
return null;
}
public int  _stringlength(String _origstring) throws Exception{
int _strlen = 0;
 //BA.debugLineNum = 57;BA.debugLine="Public Sub stringLength (origString As String) As";
 //BA.debugLineNum = 59;BA.debugLine="Dim strlen As Int = 0";
_strlen = (int) (0);
 //BA.debugLineNum = 60;BA.debugLine="strlen = nativeMe.RunMethod(\"stringLength\", Array";
_strlen = (int)(BA.ObjectToNumber(_nativeme.RunMethod("stringLength",new Object[]{(Object)(_origstring)})));
 //BA.debugLineNum = 61;BA.debugLine="Return strlen";
if (true) return _strlen;
 //BA.debugLineNum = 62;BA.debugLine="End Sub";
return 0;
}
public boolean  _stringstartswith(String _inputstring,String _substring) throws Exception{
boolean _startwith = false;
 //BA.debugLineNum = 132;BA.debugLine="Public Sub stringStartsWith (inputString As String";
 //BA.debugLineNum = 133;BA.debugLine="Dim startWith As Boolean";
_startwith = false;
 //BA.debugLineNum = 134;BA.debugLine="startWith = nativeMe.RunMethod(\"stringStartsWith\"";
_startwith = BA.ObjectToBoolean(_nativeme.RunMethod("stringStartsWith",new Object[]{(Object)(_inputstring),(Object)(_substring)}));
 //BA.debugLineNum = 135;BA.debugLine="Return startWith";
if (true) return _startwith;
 //BA.debugLineNum = 136;BA.debugLine="End Sub";
return false;
}
public char[]  _stringtochararray(String _inputstring) throws Exception{
char[] _chararray = null;
 //BA.debugLineNum = 379;BA.debugLine="Public Sub stringToCharArray (inputString As Strin";
 //BA.debugLineNum = 380;BA.debugLine="Dim charArray() As Char";
_chararray = new char[(int) (0)];
;
 //BA.debugLineNum = 381;BA.debugLine="charArray = nativeMe.RunMethod(\"stringToCharArray";
_chararray = (char[])(_nativeme.RunMethod("stringToCharArray",new Object[]{(Object)(_inputstring)}));
 //BA.debugLineNum = 382;BA.debugLine="Return charArray";
if (true) return _chararray;
 //BA.debugLineNum = 383;BA.debugLine="End Sub";
return null;
}
public int  _stringtohashcode(String _inputstring) throws Exception{
int _hashvalue = 0;
 //BA.debugLineNum = 519;BA.debugLine="Public Sub stringToHashCode (inputString As String";
 //BA.debugLineNum = 520;BA.debugLine="Dim hashValue As Int";
_hashvalue = 0;
 //BA.debugLineNum = 521;BA.debugLine="hashValue = nativeMe.RunMethod(\"stringToHashCode\"";
_hashvalue = (int)(BA.ObjectToNumber(_nativeme.RunMethod("stringToHashCode",new Object[]{(Object)(_inputstring)})));
 //BA.debugLineNum = 522;BA.debugLine="Return hashValue";
if (true) return _hashvalue;
 //BA.debugLineNum = 523;BA.debugLine="End Sub";
return 0;
}
public int  _stringtoint(String _inputstring) throws Exception{
int _stringtointeger = 0;
 //BA.debugLineNum = 449;BA.debugLine="Public Sub stringToInt (inputString As String) As";
 //BA.debugLineNum = 450;BA.debugLine="Dim stringToInteger As Int";
_stringtointeger = 0;
 //BA.debugLineNum = 451;BA.debugLine="stringToInteger = nativeMe.RunMethod(\"stringToInt";
_stringtointeger = (int)(BA.ObjectToNumber(_nativeme.RunMethod("stringToInt",new Object[]{(Object)(_inputstring)})));
 //BA.debugLineNum = 452;BA.debugLine="Return stringToInteger";
if (true) return _stringtointeger;
 //BA.debugLineNum = 453;BA.debugLine="End Sub";
return 0;
}
public String  _stringtolowercase(String _origstring) throws Exception{
 //BA.debugLineNum = 45;BA.debugLine="Public Sub StringToLowerCase (origString As String";
 //BA.debugLineNum = 46;BA.debugLine="origString = nativeMe.RunMethod(\"StringToLowerCas";
_origstring = BA.ObjectToString(_nativeme.RunMethod("StringToLowerCase",new Object[]{(Object)(_origstring)}));
 //BA.debugLineNum = 47;BA.debugLine="Return origString";
if (true) return _origstring;
 //BA.debugLineNum = 48;BA.debugLine="End Sub";
return "";
}
public String  _stringtouppercase(String _origstring) throws Exception{
 //BA.debugLineNum = 33;BA.debugLine="Public Sub StringToUpperCase (origString As String";
 //BA.debugLineNum = 34;BA.debugLine="origString = nativeMe.RunMethod(\"StringToUpperCas";
_origstring = BA.ObjectToString(_nativeme.RunMethod("StringToUpperCase",new Object[]{(Object)(_origstring)}));
 //BA.debugLineNum = 35;BA.debugLine="Return origString";
if (true) return _origstring;
 //BA.debugLineNum = 36;BA.debugLine="End Sub";
return "";
}
public String  _substring1(String _inputstring,int _startindex) throws Exception{
 //BA.debugLineNum = 209;BA.debugLine="Public Sub subString1 (inputString As String, star";
 //BA.debugLineNum = 210;BA.debugLine="inputString = nativeMe.RunMethod(\"subString1\", Ar";
_inputstring = BA.ObjectToString(_nativeme.RunMethod("subString1",new Object[]{(Object)(_inputstring),(Object)(_startindex)}));
 //BA.debugLineNum = 211;BA.debugLine="Return inputString";
if (true) return _inputstring;
 //BA.debugLineNum = 212;BA.debugLine="End Sub";
return "";
}
public String  _substring2(String _inputstring,int _fromindex,int _toindex) throws Exception{
 //BA.debugLineNum = 225;BA.debugLine="Public Sub subString2 (inputString As String, from";
 //BA.debugLineNum = 226;BA.debugLine="inputString = nativeMe.RunMethod(\"subString2\", Ar";
_inputstring = BA.ObjectToString(_nativeme.RunMethod("subString2",new Object[]{(Object)(_inputstring),(Object)(_fromindex),(Object)(_toindex)}));
 //BA.debugLineNum = 227;BA.debugLine="Return inputString";
if (true) return _inputstring;
 //BA.debugLineNum = 228;BA.debugLine="End Sub";
return "";
}
public String  _substringafter(String _str1,String _str2) throws Exception{
String _substr = "";
 //BA.debugLineNum = 367;BA.debugLine="Public Sub substringAfter (str1 As String, str2 As";
 //BA.debugLineNum = 368;BA.debugLine="Dim substr As String";
_substr = "";
 //BA.debugLineNum = 369;BA.debugLine="substr = nativeMe.RunMethod(\"substringAfter\", Arr";
_substr = BA.ObjectToString(_nativeme.RunMethod("substringAfter",new Object[]{(Object)(_str1),(Object)(_str2)}));
 //BA.debugLineNum = 370;BA.debugLine="Return substr";
if (true) return _substr;
 //BA.debugLineNum = 371;BA.debugLine="End Sub";
return "";
}
public String  _substringbetween1(String _inputstring,String _tagstring) throws Exception{
 //BA.debugLineNum = 276;BA.debugLine="Public Sub substringBetween1 (inputString As Strin";
 //BA.debugLineNum = 277;BA.debugLine="inputString = nativeMe.RunMethod(\"substringBetwee";
_inputstring = BA.ObjectToString(_nativeme.RunMethod("substringBetween1",new Object[]{(Object)(_inputstring),(Object)(_tagstring)}));
 //BA.debugLineNum = 278;BA.debugLine="Return inputString";
if (true) return _inputstring;
 //BA.debugLineNum = 279;BA.debugLine="End Sub";
return "";
}
public String  _substringbetween2(String _inputstring,String _openstring,String _closestring) throws Exception{
 //BA.debugLineNum = 289;BA.debugLine="Public Sub substringBetween2 (inputString As Strin";
 //BA.debugLineNum = 290;BA.debugLine="inputString = nativeMe.RunMethod(\"substringBetwee";
_inputstring = BA.ObjectToString(_nativeme.RunMethod("substringBetween2",new Object[]{(Object)(_inputstring),(Object)(_openstring),(Object)(_closestring)}));
 //BA.debugLineNum = 291;BA.debugLine="Return inputString";
if (true) return _inputstring;
 //BA.debugLineNum = 292;BA.debugLine="End Sub";
return "";
}
public String  _trim(String _inputstring) throws Exception{
 //BA.debugLineNum = 120;BA.debugLine="Public Sub Trim (inputString As String) As String";
 //BA.debugLineNum = 121;BA.debugLine="inputString = nativeMe.RunMethod(\"Trim\", Array (i";
_inputstring = BA.ObjectToString(_nativeme.RunMethod("Trim",new Object[]{(Object)(_inputstring)}));
 //BA.debugLineNum = 122;BA.debugLine="Return inputString";
if (true) return _inputstring;
 //BA.debugLineNum = 123;BA.debugLine="End Sub";
return "";
}
public int  _val(String _inputstring) throws Exception{
int _newval = 0;
 //BA.debugLineNum = 532;BA.debugLine="Public Sub Val (inputString As String) As Int";
 //BA.debugLineNum = 533;BA.debugLine="Dim newval As Int";
_newval = 0;
 //BA.debugLineNum = 534;BA.debugLine="newval = nativeMe.RunMethod(\"Val\", Array (inputSt";
_newval = (int)(BA.ObjectToNumber(_nativeme.RunMethod("Val",new Object[]{(Object)(_inputstring)})));
 //BA.debugLineNum = 535;BA.debugLine="Return newval";
if (true) return _newval;
 //BA.debugLineNum = 536;BA.debugLine="End Sub";
return 0;
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}




public String reverseString (String stringToReverse) {
  String strOriginal;
  strOriginal = stringToReverse;
  strOriginal = new StringBuffer(strOriginal).reverse().toString();
  return strOriginal;
}


public String StringToUpperCase(String inputString) {
  String outputString = inputString.toUpperCase();
  return outputString;
}


public String StringToLowerCase(String inputString) {
  String outputString = inputString.toLowerCase();
  return outputString;
}


public int stringLength(String inputString) {
  int stringlength = inputString.length();
  return stringlength;
}


/**
* Replace all occurances of a char in a string with a new char
*Example:<code>
*Dim msu As B4AstringUtils
*
*Dim mystring As String
*mystring = "Basic4Android is Great!"
*log(msu.replaceChar(mystring,"A","B")
*</code>
*/
public String replaceChar(String inputString, char oldChar, char newChar) {
  String outputString = inputString.replace(oldChar, newChar);
  return outputString; 

}


/**
*Replaces only the first occurances of a given String with a new one
*Example:<code>
*Dim msu As B4AstringUtils
*
*Dim mystring As String
*mystring = "Replace Region"
*log(msu.replaceFirstOccur(mystring,"Re","Ra")
*</code>
*/
public String replaceFirstOccur(String inputString, String oldString, String newString) {
  String outputString = inputString.replaceFirst(oldString, newString);
  return outputString; 

}


/**
*Replace all occurances of a given String with a new one
*Example:<code>
*Dim msu As B4AstringUtils
*
*Dim mystring As String
*mystring = "Replace Region"
*log(msu.replaceAllOccur(mystring,"Re","Ra")
*</code>
*/
public String replaceAllOccur(String inputString, String oldString, String newString) {
  String outputString = inputString.replaceAll(oldString, newString);
  return outputString; 

}


/**
*This method returns true/false if the input string contains a given substring.
*Example:<code>
*Dim msu As B4AstringUtils
*
*Dim mystring as String
*mystring = "Replace Region"
*log(msu.containString(mystring,"Re")
*</code>
*/
public boolean containString(String inputString, String substring) {
  boolean containstring = inputString.contains(substring);
  return containstring; 

}


/**
*Removes the leading and trailing spaces from a string
*Example:<code>
*Dim msu As B4AstringUtils
*
*Dim mystring as String
*mystring = "    Replace Region    "
*log(msu.Trim(mystring)
*</code>
*/
public String Trim(String inputString) {
  String strTrimmed = inputString.trim();
  return strTrimmed;

}


/**
*This method returns true/false when the input string starts with the substring
*Example:<code>
*Dim msu As B4AstringUtils
*
*Dim mystring as String
*mystring = "Replace Region"
*log(msu.StringStartsWith(mystring,"Replace")
*</code>
*/
public boolean stringStartsWith(String inputString, String substring) {
  boolean startWithString = inputString.startsWith(substring);
  return startWithString; 

}


/**
*Sorts an array of strings in decending order
*It is case SENSITIVE. Therefore A-Z takes preference over a-z
*Example:<code>
*Dim msu As B4AstringUtils
*
*Dim mywords() As String
*mywords = Array As String("My", "name", "is", "Johan", "Schoeman")
*mywords = msu.sortStringCaseSensitive(mywords)
*For i = 0 To mywords.Length-1
*  Log(mywords(i))
*Next
*</code>
*/
public String[] sortStringCaseSensitive(String[] strNames) {
  Arrays.sort(strNames);
  return strNames;

}


/**
*Sorts an array of strings in decending order
*It is case INSENSITIVE. Therefore b will for eg take preference over Z
*Example:<code>
*Dim msu As B4AstringUtils
*
*Dim mywords() As String
*mywords = Array As String("My", "name", "is", "Johan", "Schoeman")
*mywords = msu.sortStringCaseInSensitive(mywords)
*For i = 0 To mywords.Length-1
*  Log(mywords(i))
*Next
*</code>
*/
public String[] sortStringCaseInSensitive(String[] strNames) {
  Arrays.sort(strNames, String.CASE_INSENSITIVE_ORDER);
  return strNames;

}

//Sort String Array in Descending Order
//java.util.Arrays.sort(easyWords,Collections.reverseOrder());


//Sort in Ascending order
//java.util.Arrays.sort(arrayName);

/**
*Sorts an array of strings in decending order
*It is case SENSITIVE
*Example:<code>
*Dim msu As B4AstringUtils
*
*Dim mywords() As String
*mywords = Array As String("a", "B", "c", "D", "z")
*mywords = msu.sortStringArrayDecendingCaseSensitive(mywords)
*For i = 0 To mywords.Length-1
*  Log(mywords(i))
*Next
*</code>
*
*Return array will be (starting from index 0) z, c, a, D, B
*/
public String[] sortStringArrayDecendingCaseSensitive(String[] strNames) {
  Arrays.sort(strNames, Collections.reverseOrder());
  return strNames;

}



/**
*Sorts an array of strings in ascending order
*It is case SENSITIVE
*Example:<code>
*Dim msu As B4AstringUtils
*
*Dim mywords() As String
*mywords = Array As String("a", "B", "c", "D", "z")
*mywords = msu.sortStringArrayDecendingCaseInSensitive(mywords)
*For i = 0 To mywords.Length-1
*  Log(mywords(i))
*Next
*</code>
*
*Return array will be (starting from index 0) z, D, c, B, a
*/
public String[] sortStringArrayDecendingCaseInSensitive(String[] strNames) {
  Arrays.sort(strNames, String.CASE_INSENSITIVE_ORDER);
  String[] newStrNames = new String[strNames.length];
 
  for (int arrayIterator = 0; arrayIterator < strNames.length; arrayIterator++) { 
    newStrNames[arrayIterator] = strNames[strNames.length - 1 - arrayIterator];
  } 

  return newStrNames;

}


/**
*Returns a substring of the string starting from index
*
*Example:<code>
*Dim msu As B4AstringUtils
*
*Dim mystring As String
*Dim myindex as Int = 6
*mystring = "Hello World"
*Log(msu.subString1(mystring,myindex))
*</code>
*Returned substring = World
*/
public String subString1(String myString, int myIndex) {
  myString = myString.substring(myIndex);
  return myString;

}


/**
*Returns a substring of the string starting from fromIndex upto toIndex-1
*Here fromIndex is inclusive while toIndex is exclusive.
*Example:<code>
*Dim msu As B4AstringUtils
*
*Dim mystring As String
*Dim fromIndex as Int = 0
*Dim toIndex as Int = 5
*mystring = "Hello World"
*Log(msu.subString2(mystring, fromIndex, toIndex))
*</code>
*Returned substring = Hello
*/
public String subString2(String myString, int fromIndex, int toIndex) {
  myString = myString.substring(fromIndex,toIndex);
  return myString;

}

  public String Right(String str, int len) {
      if (str == null) {
          return null;
      }
      if (len < 0) {
          return "";
      }
      if (str.length() <= len) {
          return str;
      }
      return str.substring(str.length() - len);
  }
  
  public String Left(String str, int len) {
      if (str == null) {
          return null;
      }
      if (len < 0) {
          return "";
      }
      if (str.length() <= len) {
          return str;
      }
      return str.substring(0, len);
  }  
  
  public String Mid(String str, int pos, int len) {
      if (str == null) {
          return null;
      }
      if (len < 0 || pos > str.length()) {
          return "";
      }
      if (pos < 0) {
          pos = 0;
      }
      if (str.length() <= (pos + len)) {
          return str.substring(pos);
      }
      return str.substring(pos, pos + len);
  }  
  
  
  
  
  // Substring between
  //-----------------------------------------------------------------------
  /**
   * Gets the String that is nested in between two instances of the
   * same String.
   *
   * A <code>null</code> input String returns <code>null</code>.
   * A <code>null</code> tag returns <code>null</code>.
   *
   * <pre>
   * StringUtils.substringBetween(null, *)            = null
   * StringUtils.substringBetween("", "")             = ""
   * StringUtils.substringBetween("", "tag")          = null
   * StringUtils.substringBetween("tagabctag", null)  = null
   * StringUtils.substringBetween("tagabctag", "")    = ""
   * StringUtils.substringBetween("tagabctag", "tag") = "abc"
   * </pre>
   *
   * @param str  the String containing the substring, may be null
   * @param tag  the String before and after the substring, may be null
   * @return the substring, <code>null</code> if no match
   * @since 2.0
   */
  public String substringBetween1(String str, String tag) {
      return substringBetween2(str, tag, tag);
  }

  /**
   * Gets the String that is nested in between two Strings.
   * Only the first match is returned.
   *
   * A <code>null</code> input String returns <code>null</code>.
   * A <code>null</code> open/close returns <code>null</code> (no match).
   * An empty ("") open and close returns an empty string.
   *
   * <pre>
   * StringUtils.substringBetween("wx[b]yz", "[", "]") = "b"
   * StringUtils.substringBetween(null, *, *)          = null
   * StringUtils.substringBetween(*, null, *)          = null
   * StringUtils.substringBetween(*, *, null)          = null
   * StringUtils.substringBetween("", "", "")          = ""
   * StringUtils.substringBetween("", "", "]")         = null
   * StringUtils.substringBetween("", "[", "]")        = null
   * StringUtils.substringBetween("yabcz", "", "")     = ""
   * StringUtils.substringBetween("yabcz", "y", "z")   = "abc"
   * StringUtils.substringBetween("yabczyabcz", "y", "z")   = "abc"
   * </pre>
   *
   * @param str  the String containing the substring, may be null
   * @param open  the String before the substring, may be null
   * @param close  the String after the substring, may be null
   * @return the substring, <code>null</code> if no match
   * @since 2.0
   */
  public String substringBetween2(String str, String open, String close) {
      if (str == null || open == null || close == null) {
          return null;
      }
      int start = str.indexOf(open);
      if (start != -1) {
          int end = str.indexOf(close, start + open.length());
          if (end != -1) {
              return str.substring(start + open.length(), end);
          }
      }
      return null;
  }

  // Empty checks
  //-----------------------------------------------------------------------
  /**
   * Checks if a String is empty ("") or null.
   *
   * <pre>
   * StringUtils.isEmpty(null)      = true
   * StringUtils.isEmpty("")        = true
   * StringUtils.isEmpty(" ")       = false
   * StringUtils.isEmpty("bob")     = false
   * StringUtils.isEmpty("  bob  ") = false
   * </pre>
   *
   * NOTE: This method changed in Lang version 2.0.
   * It no longer trims the String.
   * That functionality is available in isBlank().
   *
   * @param str  the String to check, may be null
   * @return <code>true</code> if the String is empty or null
   */
  public boolean isEmpty(String str) {
	  if (str.equals("null")) { 
	    return true;
	  } else {
	      return str.length() == 0;
      }		
  }
  
  /**
   * Count the number of instances of substring within a string.
   *
   * @param string     String to look for substring in.
   * @param substring  Sub-string to look for.
   * @return           Count of substrings in string.
   */
  public int count(final String string, final String substring)
  {
     int count = 0;
     int idx = 0;

     while ((idx = string.indexOf(substring, idx)) != -1)
     {
        idx++;
        count++;
     }

     return count;
  }

  /**
   * Count the number of instances of character within a string.
   *
   * @param string     String to look for substring in.
   * @param c          Character to look for.
   * @return           Count of substrings in string.
   */
  public int count(final String string, final char c)
  {
     return count(string, String.valueOf(c));
  }
 
 
 
   // Difference
  //-----------------------------------------------------------------------
  /**
   * Compares two Strings, and returns the portion where they differ.
   * (More precisely, return the remainder of the second String,
   * starting from where it's different from the first.)
   *
   * For example,
   * <code>difference("i am a machine", "i am a robot") -> "robot"</code>.
   *
   * <pre>
   * StringUtils.difference(null, null) = null
   * StringUtils.difference("", "") = ""
   * StringUtils.difference("", "abc") = "abc"
   * StringUtils.difference("abc", "") = ""
   * StringUtils.difference("abc", "abc") = ""
   * StringUtils.difference("ab", "abxyz") = "xyz"
   * StringUtils.difference("abcde", "abxyz") = "xyz"
   * StringUtils.difference("abcde", "xyz") = "xyz"
   * </pre>
   *
   * @param str1  the first String, may be null
   * @param str2  the second String, may be null
   * @return the portion of str2 where it differs from str1; returns the
   * empty String if they are equal
   * @since 2.0
   */
  public String difference(String str1, String str2) {
      if (str1 == null) {
          return str2;
      }
      if (str2 == null) {
          return str1;
      }
      int at = indexOfDifference(str1, str2);
      if (at == -1) {
          return "";
      }
      return str2.substring(at);
  }
 

   /**
   * Compares two Strings, and returns the index at which the
   * Strings begin to differ.
   *
   * For example,
   * <code>indexOfDifference("i am a machine", "i am a robot") -> 7</code>
   *
   * <pre>
   * StringUtils.indexOfDifference(null, null) = -1
   * StringUtils.indexOfDifference("", "") = -1
   * StringUtils.indexOfDifference("", "abc") = 0
   * StringUtils.indexOfDifference("abc", "") = 0
   * StringUtils.indexOfDifference("abc", "abc") = -1
   * StringUtils.indexOfDifference("ab", "abxyz") = 2
   * StringUtils.indexOfDifference("abcde", "abxyz") = 2
   * StringUtils.indexOfDifference("abcde", "xyz") = 0
   * </pre>
   *
   * @param str1  the first String, may be null
   * @param str2  the second String, may be null
   * @return the index where str2 and str1 begin to differ; -1 if they are equal
   * @since 2.0
   */
  public int indexOfDifference(String str1, String str2) {
      if (str1 == str2) {
          return -1;
      }
      if (str1 == null || str2 == null) {
          return 0;
      }
      int i;
      for (i = 0; i < str1.length() && i < str2.length(); ++i) {
          if (str1.charAt(i) != str2.charAt(i)) {
              break;
          }
      }
      if (i < str2.length() || i < str1.length()) {
          return i;
      }
      return -1;
  }
 
 

 /**
   * Gets the substring after the first occurrence of a separator.
   * The separator is not returned.
   *
   * A <code>null</code> string input will return <code>null</code>.
   * An empty ("") string input will return the empty string.
   * A <code>null</code> separator will return the empty string if the
   * input string is not <code>null</code>.
   *
   * <pre>
   * StringUtils.substringAfter(null, *)      = null
   * StringUtils.substringAfter("", *)        = ""
   * StringUtils.substringAfter(*, null)      = ""
   * StringUtils.substringAfter("abc", "a")   = "bc"
   * StringUtils.substringAfter("abcba", "b") = "cba"
   * StringUtils.substringAfter("abc", "c")   = ""
   * StringUtils.substringAfter("abc", "d")   = ""
   * StringUtils.substringAfter("abc", "")    = "abc"
   * </pre>
   *
   * @param str  the String to get a substring from, may be null
   * @param separator  the String to search for, may be null
   * @return the substring after the first occurrence of the separator,
   *  <code>null</code> if null String input
   * @since 2.0
   */
  public String substringAfter(String str, String separator) {
      if (isEmpty(str)) {
          return str;
      }
      if (separator == null) {
          return "";
      }
      int pos = str.indexOf(separator);
      if (pos == -1) {
          return "";
      }
      return str.substring(pos + separator.length());
  }
  

  /**
   * Converts a String to an array of characters
   */ 
  public char[] stringToCharArray(String inputString) {
    int len = inputString.length();
    char[] tempCharArray = new char[len];
    char[] charArray = new char[len];

    // put original string in an array of chars
    for (int i = 0; i < len; i++) {
      tempCharArray[i] = inputString.charAt(i);
    }
      return tempCharArray;
  }
  
   /**
   * Converts an array of characters to a String
   */ 
  public String charArrayToString(char[] charArray) {

    String charToString = new String(charArray);
      return charToString;
  } 
  
  public String doubleToString(double number) {
    String returnString = "";
    return String.valueOf(number);   
  }
  
   public String intToString(int number) {
    String returnString = "";
    return String.valueOf(number);   
  } 
  
   public String intToBinaryString(int number) {
    String returnString = "";
    return Integer.toBinaryString(number);
  } 
  
    public int stringToInt (String inputString) {
      int i = Integer.parseInt(inputString);
      return i;
  }
  
   public String intToOctalString(int number) {
    String returnString = "";
    return Integer.toOctalString(number);
  }   
 
   public String intToHexString(int number) {
    String returnString = "";
    return Integer.toHexString(number);
  }     
  
  public String removeCharFromString(String s, char c) {
    String r = "";
    for (int i = 0; i < s.length(); i++) {
      if (s.charAt(i) != c)
        r += s.charAt(i);
    }
    return r;
  }  
  
  public String removeCharAtPosition(String s, int pos) {
    return s.substring(0, pos) + s.substring(pos + 1);
  } 
  
   public int stringToHashCode(String inputString) {
    return inputString.hashCode();
  } 
  
   public int Val(String inputString) {
    return Integer.parseInt(inputString);
  }   
  
 
  
  

}
