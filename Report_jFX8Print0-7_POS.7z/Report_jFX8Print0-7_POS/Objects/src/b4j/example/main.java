package b4j.example;


import anywheresoftware.b4a.BA;

public class main extends javafx.application.Application{
public static main mostCurrent = new main();

public static BA ba;
static {
		ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.main", null);
		ba.loadHtSubs(main.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.main", ba);
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}

 
    public static void main(String[] args) {
    	launch(args);
    }
    public void start (javafx.stage.Stage stage) {
        try {
            if (!false)
                System.setProperty("prism.lcdtext", "false");
            anywheresoftware.b4j.objects.FxBA.application = this;
		    anywheresoftware.b4a.keywords.Common.setDensity(javafx.stage.Screen.getPrimary().getDpi());
            anywheresoftware.b4a.keywords.Common.LogDebug("Program started.");
            initializeProcessGlobals();
            anywheresoftware.b4j.objects.Form frm = new anywheresoftware.b4j.objects.Form();
            frm.initWithStage(ba, stage, 600, 600);
            ba.raiseEvent(null, "appstart", frm, (String[])getParameters().getRaw().toArray(new String[0]));
        } catch (Throwable t) {
            BA.printException(t, true);
            System.exit(1);
        }
    }
public static anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4j.objects.JFX _fx = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public static b4j.example.stringutilities _su = null;
public static anywheresoftware.b4j.objects.Form _mainform = null;
public static anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper _pane1 = null;
public static anywheresoftware.b4j.objects.CanvasWrapper _canvas1 = null;
public static anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper _pane2 = null;
public static anywheresoftware.b4j.objects.WebViewWrapper _webview1 = null;
public static anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper _panerep = null;
public static anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper _paneclone = null;
public static anywheresoftware.b4j.objects.TabPaneWrapper _tabpane1 = null;
public static anywheresoftware.b4j.objects.ButtonWrapper _btnrep01 = null;
public static anywheresoftware.b4j.objects.ButtonWrapper _btnrep02 = null;
public static anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper _panewebview = null;
public static anywheresoftware.b4j.objects.WebViewWrapper _webviewclone = null;
public static String _strreportstyle = "";
public static anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper _paneclonew = null;
public static anywheresoftware.b4j.objects.ButtonWrapper _btnrepb01 = null;
public static anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper _panerepb = null;
public static anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper _paneb = null;
public static anywheresoftware.b4j.objects.LabelWrapper _lab01 = null;
public static anywheresoftware.b4j.objects.LabelWrapper _lab02 = null;
public static anywheresoftware.b4j.objects.LabelWrapper _lab03 = null;
public static anywheresoftware.b4j.objects.LabelWrapper _lab04 = null;
public static b4j.example.dateutils _dateutils = null;
public static b4j.example.cssutils _cssutils = null;
public static b4j.example.printerjob_static _printerjob_static = null;
public static b4j.example.pageorientation_static _pageorientation_static = null;
public static b4j.example.printer_static _printer_static = null;
public static b4j.example.paper_static _paper_static = null;
public static b4j.example.utils _utils = null;
public static b4j.example.adhocwrappers _adhocwrappers = null;
public static b4j.example.code39 _code39 = null;
public static b4j.example.xuiviewsutils _xuiviewsutils = null;
public static String  _appstart(anywheresoftware.b4j.objects.Form _form1,String[] _args) throws Exception{
String _binstring = "";
String _msg = "";
 //BA.debugLineNum = 48;BA.debugLine="Sub AppStart (Form1 As Form, Args() As String)";
 //BA.debugLineNum = 50;BA.debugLine="MainForm = Form1";
_mainform = _form1;
 //BA.debugLineNum = 51;BA.debugLine="MainForm.RootPane.LoadLayout(\"main\") 'Load the la";
_mainform.getRootPane().LoadLayout(ba,"main");
 //BA.debugLineNum = 53;BA.debugLine="TabPane1.LoadLayout(\"Layout01\", \"Receipt 票據機\")";
_tabpane1.LoadLayout(ba,"Layout01","Receipt 票據機");
 //BA.debugLineNum = 54;BA.debugLine="TabPane1.LoadLayout(\"Layout02\", \"Label 貼紙機\")";
_tabpane1.LoadLayout(ba,"Layout02","Label 貼紙機");
 //BA.debugLineNum = 56;BA.debugLine="MainForm.Show";
_mainform.Show();
 //BA.debugLineNum = 59;BA.debugLine="su.Initialize";
_su._initialize /*String*/ (ba);
 //BA.debugLineNum = 61;BA.debugLine="Dim binstring As String = \"\"";
_binstring = "";
 //BA.debugLineNum = 62;BA.debugLine="Dim msg  As String";
_msg = "";
 //BA.debugLineNum = 63;BA.debugLine="msg = \"12345\"";
_msg = "12345";
 //BA.debugLineNum = 65;BA.debugLine="binstring = Code39.Draw_Code39(msg)";
_binstring = _code39._draw_code39 /*String*/ (_msg);
 //BA.debugLineNum = 66;BA.debugLine="Log(\"binstring Code11 = \" & binstring)";
anywheresoftware.b4a.keywords.Common.LogImpl("665554","binstring Code11 = "+_binstring,0);
 //BA.debugLineNum = 67;BA.debugLine="draw_barcode_Code39(binstring)";
_draw_barcode_code39(_binstring);
 //BA.debugLineNum = 71;BA.debugLine="lab01.Text=\"#001  1/1  外帶\"";
_lab01.setText("#001  1/1  外帶");
 //BA.debugLineNum = 72;BA.debugLine="lab02.Text=\"芋頭牛奶\"";
_lab02.setText("芋頭牛奶");
 //BA.debugLineNum = 73;BA.debugLine="lab03.Text=\"少冰\"";
_lab03.setText("少冰");
 //BA.debugLineNum = 74;BA.debugLine="lab04.Text=\"2022/10/05 17:50 #65\"";
_lab04.setText("2022/10/05 17:50 #65");
 //BA.debugLineNum = 75;BA.debugLine="End Sub";
return "";
}
public static String  _btnrep_click() throws Exception{
anywheresoftware.b4j.objects.ButtonWrapper _b = null;
String _strhtml = "";
 //BA.debugLineNum = 205;BA.debugLine="Private Sub btnRep_Click";
 //BA.debugLineNum = 206;BA.debugLine="Dim b As Button = Sender";
_b = new anywheresoftware.b4j.objects.ButtonWrapper();
_b = (anywheresoftware.b4j.objects.ButtonWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.ButtonWrapper(), (javafx.scene.control.Button)(anywheresoftware.b4a.keywords.Common.Sender(ba)));
 //BA.debugLineNum = 208;BA.debugLine="Log(b.text)";
anywheresoftware.b4a.keywords.Common.LogImpl("6262147",_b.getText(),0);
 //BA.debugLineNum = 210;BA.debugLine="PaneClone.Visible=False";
_paneclone.setVisible(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 212;BA.debugLine="If b.text = \"Rep01\" Then";
if ((_b.getText()).equals("Rep01")) { 
 //BA.debugLineNum = 213;BA.debugLine="strReportStyle=\"Rep01\"";
_strreportstyle = "Rep01";
 //BA.debugLineNum = 215;BA.debugLine="PaneRep.Visible = True";
_panerep.setVisible(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 216;BA.debugLine="PaneRep.Left=0";
_panerep.setLeft(0);
 //BA.debugLineNum = 217;BA.debugLine="PaneWebView.Visible=False";
_panewebview.setVisible(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 218;BA.debugLine="PaneWebView.Left=610";
_panewebview.setLeft(610);
 }else {
 //BA.debugLineNum = 220;BA.debugLine="strReportStyle=\"Rep02\"";
_strreportstyle = "Rep02";
 //BA.debugLineNum = 222;BA.debugLine="PaneRep.Visible = False";
_panerep.setVisible(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 223;BA.debugLine="PaneRep.Left=610";
_panerep.setLeft(610);
 //BA.debugLineNum = 225;BA.debugLine="PaneClone.Visible=False";
_paneclone.setVisible(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 226;BA.debugLine="PaneClone.Left=610";
_paneclone.setLeft(610);
 //BA.debugLineNum = 228;BA.debugLine="PaneWebView.Visible=True";
_panewebview.setVisible(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 229;BA.debugLine="PaneWebView.Left=0";
_panewebview.setLeft(0);
 //BA.debugLineNum = 231;BA.debugLine="PaneWebView.Top=0";
_panewebview.setTop(0);
 //BA.debugLineNum = 232;BA.debugLine="PaneWebView.Left=0";
_panewebview.setLeft(0);
 //BA.debugLineNum = 234;BA.debugLine="Dim strHtml As String";
_strhtml = "";
 //BA.debugLineNum = 238;BA.debugLine="strHtml =$\"  <!DOCTYPE HTML Public \"-//W3C//DTD";
_strhtml = ("\n"+"\n"+"<!DOCTYPE HTML Public \"-//W3C//DTD HTML 4.01 Transitional//EN\">	\n"+"<html>\n"+"<head>\n"+"    <title>Test Page</title>\n"+"    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">	\n"+"	\n"+"<style>\n"+"@media print {\n"+"  * {\n"+"    -webkit-print-color-adjust: exact !important;\n"+"  }\n"+"}\n"+"\n"+"	@page {\n"+"	margin-top: 5mm;\n"+"	margin-bottom: 5mm;\n"+"	margin-left: 5mm;\n"+"	margin-right: 5mm;\n"+"	}\n"+"\n"+"table {\n"+"    border-collapse: collapse;\n"+"}\n"+"\n"+"table, th, td {\n"+"    border: 1px solid black;\n"+"} \n"+"\n"+"table.TB_COLLAPSE {\n"+"  width:100%;\n"+"  border-collapse:collapse;\n"+"}\n"+"table.TB_COLLAPSE caption {\n"+"  padding:10px;\n"+"  font-size:24px;\n"+"  background-color:#f3f6f9;\n"+"}\n"+"table.TB_COLLAPSE thead th {\n"+"  padding:5px 0px;\n"+"  color:#fff;\n"+"  background-color:#915957;\n"+"}\n"+"table.TB_COLLAPSE tbody td {\n"+"  padding:5px 0px;\n"+"  color:#555;\n"+"  text-align:center;\n"+"  background-color:#fff;\n"+"  border-bottom:1px solid #915957;\n"+"}\n"+"table.TB_COLLAPSE tfoot td {\n"+"  padding:5px 0px;\n"+"  text-align:center;\n"+"  background-color:#d6d6a5;\n"+"}\n"+" \n"+" \n"+"</style>\n"+" \n"+"</head>\n"+"  <body  \">\n"+" \n"+"<div>\n"+"\n"+"	\n"+"    <center>\n"+"		 \n"+"            <!--span><h1>商品明細表</h1></span-->\n"+"			<table width=\"100%\">\n"+"			  <caption><h1>商品明細表</h1></caption>\n"+"			  <tr>\n"+"				<td width=\"70%\"></td>\n"+"				<td width=\"30%\" style=\"text-align: left;\">製表人員:001</td>\n"+"			  </tr>\n"+"			  <tr>\n"+"				<td width=\"70%\"></td>\n"+"				<td width=\"30%\" style=\"text-align: left;\">製表日期:2022/09/10</td>\n"+"			  </tr>					  \n"+"			</table>\n"+"		 \n"+"	</center>	\n"+"	 \n"+"	<table   width=\"100%\" >\n"+" 		 \n"+"		  <tr>\n"+"			<tD width=\"20%\" style=\"text-align: left;\">商品編號</tD>\n"+"			<tD width=\"60%\" style=\"text-align: left;\">商品名稱</tD>\n"+"			<tD width=\"20%\" style=\"text-align: right;\">價格</tD>\n"+"			\n"+"		  </tr>\n"+"		 \n"+"<tr>\n"+"  <td style=\"text-align: left;\">A001</td>\n"+"  <td style=\"text-align: left;\">明月面系列AA001</td>\n"+"  <td style=\"text-align: right;\">1</td>\n"+"</tr>\n"+"<tr>\n"+"  <td style=\"text-align: left;\">A002</td>\n"+"  <td style=\"text-align: left;\">明月面系列AA002</td>\n"+"  <td style=\"text-align: right;\">2</td>\n"+"</tr>\n"+"<tr>\n"+"  <td style=\"text-align: left;\">A003</td>\n"+"  <td style=\"text-align: left;\">明月面系列AA003</td>\n"+"  <td style=\"text-align: right;\">3</td>\n"+"</tr>\n"+"<tr>\n"+"  <td style=\"text-align: left;\">A004</td>\n"+"  <td style=\"text-align: left;\">明月面系列AA004</td>\n"+"  <td style=\"text-align: right;\">4</td>\n"+"</tr>\n"+"<tr>\n"+"  <td style=\"text-align: left;\">A005</td>\n"+"  <td style=\"text-align: left;\">明月面系列AA005</td>\n"+"  <td style=\"text-align: right;\">5</td>\n"+"</tr>\n"+"<tr>\n"+"  <td style=\"text-align: left;\">A006</td>\n"+"  <td style=\"text-align: left;\">明月面系列AA006</td>\n"+"  <td style=\"text-align: right;\">6</td>\n"+"</tr>\n"+"<tr>\n"+"  <td style=\"text-align: left;\">A007</td>\n"+"  <td style=\"text-align: left;\">明月面系列AA007</td>\n"+"  <td style=\"text-align: right;\">7</td>\n"+"</tr>\n"+"<tr>\n"+"  <td style=\"text-align: left;\">A008</td>\n"+"  <td style=\"text-align: left;\">明月面系列AA008</td>\n"+"  <td style=\"text-align: right;\">8</td>\n"+"</tr>\n"+"<tr>\n"+"  <td style=\"text-align: left;\">A009</td>\n"+"  <td style=\"text-align: left;\">明月面系列AA009</td>\n"+"  <td style=\"text-align: right;\">9</td>\n"+"</tr>\n"+"<tr>\n"+"  <td style=\"text-align: left;\">A010</td>\n"+"  <td style=\"text-align: left;\">明月面系列AA010</td>\n"+"  <td style=\"text-align: right;\">10</td>\n"+"</tr>\n"+"\n"+"		 \n"+"	</table>		\n"+"	\n"+"</div>\n"+" 		\n"+"\n"+" \n"+"  </body>\n"+"</html>	\n"+"			\n"+"		\n"+"		\n"+"		");
 //BA.debugLineNum = 395;BA.debugLine="WebView1.LoadHtml(strHtml)";
_webview1.LoadHtml(_strhtml);
 //BA.debugLineNum = 396;BA.debugLine="WebViewClone.LoadHtml(strHtml)";
_webviewclone.LoadHtml(_strhtml);
 };
 //BA.debugLineNum = 400;BA.debugLine="End Sub";
return "";
}
public static String  _btnrepb01_click() throws Exception{
anywheresoftware.b4a.objects.collections.List _l = null;
b4j.example.printer _p = null;
b4j.example.printerjob _pj = null;
b4j.example.pagelayout _layout = null;
boolean _success = false;
double _zoomfactor = 0;
double _scalex = 0;
double _scaley = 0;
anywheresoftware.b4j.object.JavaObject _njo = null;
anywheresoftware.b4j.object.JavaObject _jo = null;
anywheresoftware.b4j.object.JavaObject _sjo = null;
 //BA.debugLineNum = 403;BA.debugLine="Private Sub btnRepB01_Click";
 //BA.debugLineNum = 406;BA.debugLine="lab01.Text=\"#001 1/1 外帶\"";
_lab01.setText("#001 1/1 外帶");
 //BA.debugLineNum = 407;BA.debugLine="lab02.Text=\"芋頭牛奶\"";
_lab02.setText("芋頭牛奶");
 //BA.debugLineNum = 408;BA.debugLine="lab03.Text=\"少冰\"";
_lab03.setText("少冰");
 //BA.debugLineNum = 409;BA.debugLine="lab04.Text=\"2022/10/05 17:50 #65 1234567890\"";
_lab04.setText("2022/10/05 17:50 #65 1234567890");
 //BA.debugLineNum = 412;BA.debugLine="Dim L As List = Printer_Static.GetAllPrinters";
_l = new anywheresoftware.b4a.objects.collections.List();
_l = _printer_static._getallprinters /*anywheresoftware.b4a.objects.collections.List*/ ();
 //BA.debugLineNum = 414;BA.debugLine="Log(\"---------------------Print列表----------------";
anywheresoftware.b4a.keywords.Common.LogImpl("6327691","---------------------Print列表------------------",0);
 //BA.debugLineNum = 415;BA.debugLine="For Each P As Printer In L";
{
final anywheresoftware.b4a.BA.IterableList group7 = _l;
final int groupLen7 = group7.getSize()
;int index7 = 0;
;
for (; index7 < groupLen7;index7++){
_p = (b4j.example.printer)(group7.Get(index7));
 //BA.debugLineNum = 416;BA.debugLine="Log(P.GetName)";
anywheresoftware.b4a.keywords.Common.LogImpl("6327693",_p._getname /*String*/ (),0);
 }
};
 //BA.debugLineNum = 418;BA.debugLine="Log(\"--------------------Print列表 End-------------";
anywheresoftware.b4a.keywords.Common.LogImpl("6327695","--------------------Print列表 End-------------------",0);
 //BA.debugLineNum = 421;BA.debugLine="Dim P As Printer = Utils.GetPrinter(\"EZ-2120\") 'C";
_p = _utils._getprinter /*b4j.example.printer*/ ("EZ-2120");
 //BA.debugLineNum = 422;BA.debugLine="Log(\"p= \"&p)";
anywheresoftware.b4a.keywords.Common.LogImpl("6327699","p= "+BA.ObjectToString(_p),0);
 //BA.debugLineNum = 423;BA.debugLine="If P <> Null And P.IsInitialized Then";
if (_p!= null && _p.IsInitialized /*boolean*/ ()) { 
 //BA.debugLineNum = 424;BA.debugLine="Dim PJ As PrinterJob = PrinterJob_Static.CreateP";
_pj = _printerjob_static._createprinterjob2 /*b4j.example.printerjob*/ (_p);
 //BA.debugLineNum = 427;BA.debugLine="Dim Layout As PageLayout = P.CreatePageLayout(Ut";
_layout = _p._createpagelayout /*b4j.example.pagelayout*/ (_utils._createpaper /*b4j.example.paper*/ ("40x25mm",40.0,25.0),_pageorientation_static._portrait /*String*/ ,0,0,0,0);
 //BA.debugLineNum = 431;BA.debugLine="PJ.GetJobSettings.SetPageLayout(Layout)";
_pj._getjobsettings /*b4j.example.jobsettings*/ ()._setpagelayout /*String*/ (_layout);
 //BA.debugLineNum = 434;BA.debugLine="Log(\"*******************************************";
anywheresoftware.b4a.keywords.Common.LogImpl("6327711","**********************************************************",0);
 //BA.debugLineNum = 437;BA.debugLine="Log(\"GetPrintableHeight: \"& ( PJ.GetJobSettings.";
anywheresoftware.b4a.keywords.Common.LogImpl("6327714","GetPrintableHeight: "+BA.NumberToString((_pj._getjobsettings /*b4j.example.jobsettings*/ ()._getpagelayout /*b4j.example.pagelayout*/ ()._getprintableheight /*double*/ ())),0);
 //BA.debugLineNum = 438;BA.debugLine="Log(\"紙張寬英吋:\"& ( PJ.GetJobSettings.GetPageLayout.";
anywheresoftware.b4a.keywords.Common.LogImpl("6327715","紙張寬英吋:"+BA.NumberToString((_pj._getjobsettings /*b4j.example.jobsettings*/ ()._getpagelayout /*b4j.example.pagelayout*/ ()._getprintablewidth /*double*/ ()/(double)72)),0);
 //BA.debugLineNum = 439;BA.debugLine="Log(\"紙張寬:\"&   PJ.GetJobSettings.GetPageLayout.Ge";
anywheresoftware.b4a.keywords.Common.LogImpl("6327716","紙張寬:"+BA.NumberToString(_pj._getjobsettings /*b4j.example.jobsettings*/ ()._getpagelayout /*b4j.example.pagelayout*/ ()._getprintablewidth /*double*/ ()),0);
 //BA.debugLineNum = 440;BA.debugLine="Log(\"紙張高:\"&   PJ.GetJobSettings.GetPageLayout.Ge";
anywheresoftware.b4a.keywords.Common.LogImpl("6327717","紙張高:"+BA.NumberToString(_pj._getjobsettings /*b4j.example.jobsettings*/ ()._getpagelayout /*b4j.example.pagelayout*/ ()._getprintableheight /*double*/ ()),0);
 //BA.debugLineNum = 442;BA.debugLine="Log(\"上邊界:\"& (NumberFormat( (PJ.GetJobSettings.Ge";
anywheresoftware.b4a.keywords.Common.LogImpl("6327719","上邊界:"+(anywheresoftware.b4a.keywords.Common.NumberFormat((_pj._getjobsettings /*b4j.example.jobsettings*/ ()._getpagelayout /*b4j.example.pagelayout*/ ()._gettopmargin /*double*/ ()/(double)72)*25.4,(int) (0),(int) (2))),0);
 //BA.debugLineNum = 446;BA.debugLine="Dim success As Boolean";
_success = false;
 //BA.debugLineNum = 454;BA.debugLine="Dim ZoomFactor As Double = 1";
_zoomfactor = 1;
 //BA.debugLineNum = 455;BA.debugLine="Dim ScaleX,ScaleY As Double";
_scalex = 0;
_scaley = 0;
 //BA.debugLineNum = 456;BA.debugLine="Dim NJO As JavaObject = PaneRepB";
_njo = new anywheresoftware.b4j.object.JavaObject();
_njo = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_panerepb.getObject()));
 //BA.debugLineNum = 457;BA.debugLine="Dim JO As JavaObject = PaneRepB";
_jo = new anywheresoftware.b4j.object.JavaObject();
_jo = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_panerepb.getObject()));
 //BA.debugLineNum = 458;BA.debugLine="ScaleX = ZoomFactor * Layout.GetPrintableWidth /";
_scalex = _zoomfactor*_layout._getprintablewidth /*double*/ ()/(double)(double)(BA.ObjectToNumber(_jo.RunMethodJO("getBoundsInParent",(Object[])(anywheresoftware.b4a.keywords.Common.Null)).RunMethod("getWidth",(Object[])(anywheresoftware.b4a.keywords.Common.Null))));
 //BA.debugLineNum = 459;BA.debugLine="ScaleY = ZoomFactor * Layout.GetPrintableHeight";
_scaley = _zoomfactor*_layout._getprintableheight /*double*/ ()/(double)(double)(BA.ObjectToNumber(_jo.RunMethodJO("getBoundsInParent",(Object[])(anywheresoftware.b4a.keywords.Common.Null)).RunMethod("getHeight",(Object[])(anywheresoftware.b4a.keywords.Common.Null))));
 //BA.debugLineNum = 464;BA.debugLine="Dim SJO As JavaObject";
_sjo = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 465;BA.debugLine="SJO.InitializeNewInstance(\"javafx.scene.transfor";
_sjo.InitializeNewInstance("javafx.scene.transform.Scale",new Object[]{(Object)(_scalex),(Object)(_scaley)});
 //BA.debugLineNum = 466;BA.debugLine="NJO.RunMethodJO(\"getTransforms\",Null).RunMethod(";
_njo.RunMethodJO("getTransforms",(Object[])(anywheresoftware.b4a.keywords.Common.Null)).RunMethod("add",new Object[]{(Object)(_sjo.getObject())});
 //BA.debugLineNum = 468;BA.debugLine="Log(\"ScaleX: \"&ScaleX)";
anywheresoftware.b4a.keywords.Common.LogImpl("6327745","ScaleX: "+BA.NumberToString(_scalex),0);
 //BA.debugLineNum = 469;BA.debugLine="Log(\"ScaleY: \"&ScaleY)";
anywheresoftware.b4a.keywords.Common.LogImpl("6327746","ScaleY: "+BA.NumberToString(_scaley),0);
 //BA.debugLineNum = 472;BA.debugLine="success = PJ.PrintPage(PaneRepB)";
_success = _pj._printpage /*boolean*/ ((anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper(), (javafx.scene.Node)(_panerepb.getObject())));
 //BA.debugLineNum = 474;BA.debugLine="ScaleX =  (1/ScaleX)";
_scalex = (1/(double)_scalex);
 //BA.debugLineNum = 475;BA.debugLine="ScaleY =  (1/ScaleY)";
_scaley = (1/(double)_scaley);
 //BA.debugLineNum = 477;BA.debugLine="Dim SJO As JavaObject";
_sjo = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 478;BA.debugLine="SJO.InitializeNewInstance(\"javafx.scene.transfor";
_sjo.InitializeNewInstance("javafx.scene.transform.Scale",new Object[]{(Object)(_scalex),(Object)(_scaley)});
 //BA.debugLineNum = 479;BA.debugLine="NJO.RunMethodJO(\"getTransforms\",Null).RunMethod(";
_njo.RunMethodJO("getTransforms",(Object[])(anywheresoftware.b4a.keywords.Common.Null)).RunMethod("add",new Object[]{(Object)(_sjo.getObject())});
 //BA.debugLineNum = 481;BA.debugLine="Log(\"ScaleX: \"&ScaleX)";
anywheresoftware.b4a.keywords.Common.LogImpl("6327758","ScaleX: "+BA.NumberToString(_scalex),0);
 //BA.debugLineNum = 482;BA.debugLine="Log(\"ScaleY: \"&ScaleY)";
anywheresoftware.b4a.keywords.Common.LogImpl("6327759","ScaleY: "+BA.NumberToString(_scaley),0);
 //BA.debugLineNum = 486;BA.debugLine="If success Then";
if (_success) { 
 //BA.debugLineNum = 487;BA.debugLine="PJ.EndJob";
_pj._endjob /*boolean*/ ();
 //BA.debugLineNum = 488;BA.debugLine="Log(\"print OK\")";
anywheresoftware.b4a.keywords.Common.LogImpl("6327765","print OK",0);
 }else {
 //BA.debugLineNum = 491;BA.debugLine="Log(\"PJ-> PrintPage false\")";
anywheresoftware.b4a.keywords.Common.LogImpl("6327768","PJ-> PrintPage false",0);
 };
 }else {
 //BA.debugLineNum = 500;BA.debugLine="Log(\"Printer not found\")";
anywheresoftware.b4a.keywords.Common.LogImpl("6327777","Printer not found",0);
 };
 //BA.debugLineNum = 504;BA.debugLine="xui.MsgboxAsync(\"finish~~~\",\"B4X\")";
_xui.MsgboxAsync(ba,"finish~~~","B4X");
 //BA.debugLineNum = 507;BA.debugLine="End Sub";
return "";
}
public static String  _btntest01_click() throws Exception{
 //BA.debugLineNum = 511;BA.debugLine="Private Sub btnTest01_Click";
 //BA.debugLineNum = 512;BA.debugLine="Utils.ScaleN(Pane1,1.2)";
_utils._scalen /*String*/ ((anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper(), (javafx.scene.Node)(_pane1.getObject())),1.2);
 //BA.debugLineNum = 513;BA.debugLine="End Sub";
return "";
}
public static String  _btntest02_click() throws Exception{
 //BA.debugLineNum = 515;BA.debugLine="Private Sub btnTest02_Click";
 //BA.debugLineNum = 516;BA.debugLine="Utils.ScaleN(Pane1,0.8)";
_utils._scalen /*String*/ ((anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper(), (javafx.scene.Node)(_pane1.getObject())),0.8);
 //BA.debugLineNum = 517;BA.debugLine="End Sub";
return "";
}
public static String  _button1_click() throws Exception{
anywheresoftware.b4a.objects.collections.List _l = null;
b4j.example.printer _p = null;
b4j.example.printerjob _pj = null;
b4j.example.pagelayout _layout = null;
boolean _success = false;
 //BA.debugLineNum = 103;BA.debugLine="Private Sub Button1_Click";
 //BA.debugLineNum = 105;BA.debugLine="Dim L As List = Printer_Static.GetAllPrinters";
_l = new anywheresoftware.b4a.objects.collections.List();
_l = _printer_static._getallprinters /*anywheresoftware.b4a.objects.collections.List*/ ();
 //BA.debugLineNum = 107;BA.debugLine="Log(\"---------------------Print列表----------------";
anywheresoftware.b4a.keywords.Common.LogImpl("6196612","---------------------Print列表------------------",0);
 //BA.debugLineNum = 108;BA.debugLine="For Each P As Printer In L";
{
final anywheresoftware.b4a.BA.IterableList group3 = _l;
final int groupLen3 = group3.getSize()
;int index3 = 0;
;
for (; index3 < groupLen3;index3++){
_p = (b4j.example.printer)(group3.Get(index3));
 //BA.debugLineNum = 109;BA.debugLine="Log(P.GetName)";
anywheresoftware.b4a.keywords.Common.LogImpl("6196614",_p._getname /*String*/ (),0);
 }
};
 //BA.debugLineNum = 111;BA.debugLine="Log(\"--------------------Print列表 End-------------";
anywheresoftware.b4a.keywords.Common.LogImpl("6196616","--------------------Print列表 End-------------------",0);
 //BA.debugLineNum = 114;BA.debugLine="Dim P As Printer = Utils.GetPrinter(\"TP805\") 'Cha";
_p = _utils._getprinter /*b4j.example.printer*/ ("TP805");
 //BA.debugLineNum = 115;BA.debugLine="Log(\"p= \"&p)";
anywheresoftware.b4a.keywords.Common.LogImpl("6196620","p= "+BA.ObjectToString(_p),0);
 //BA.debugLineNum = 116;BA.debugLine="If P <> Null And P.IsInitialized Then";
if (_p!= null && _p.IsInitialized /*boolean*/ ()) { 
 //BA.debugLineNum = 117;BA.debugLine="Dim PJ As PrinterJob = PrinterJob_Static.CreateP";
_pj = _printerjob_static._createprinterjob2 /*b4j.example.printerjob*/ (_p);
 //BA.debugLineNum = 120;BA.debugLine="Dim Layout As PageLayout = P.CreatePageLayout(Ut";
_layout = _p._createpagelayout /*b4j.example.pagelayout*/ (_utils._createpaper /*b4j.example.paper*/ ("80mm x 100mm",80.0,100.0),_pageorientation_static._portrait /*String*/ ,1,1,1,1);
 //BA.debugLineNum = 124;BA.debugLine="PJ.GetJobSettings.SetPageLayout(Layout)";
_pj._getjobsettings /*b4j.example.jobsettings*/ ()._setpagelayout /*String*/ (_layout);
 //BA.debugLineNum = 127;BA.debugLine="Log(\"*******************************************";
anywheresoftware.b4a.keywords.Common.LogImpl("6196632","**********************************************************",0);
 //BA.debugLineNum = 130;BA.debugLine="Log(\"GetPrintableHeight: \"& ( PJ.GetJobSettings.";
anywheresoftware.b4a.keywords.Common.LogImpl("6196635","GetPrintableHeight: "+BA.NumberToString((_pj._getjobsettings /*b4j.example.jobsettings*/ ()._getpagelayout /*b4j.example.pagelayout*/ ()._getprintableheight /*double*/ ())),0);
 //BA.debugLineNum = 131;BA.debugLine="Log(\"紙張寬英吋:\"& ( PJ.GetJobSettings.GetPageLayout.";
anywheresoftware.b4a.keywords.Common.LogImpl("6196636","紙張寬英吋:"+BA.NumberToString((_pj._getjobsettings /*b4j.example.jobsettings*/ ()._getpagelayout /*b4j.example.pagelayout*/ ()._getprintablewidth /*double*/ ()/(double)72)),0);
 //BA.debugLineNum = 132;BA.debugLine="Log(\"紙張寬:\"& (NumberFormat2( (PJ.GetJobSettings.G";
anywheresoftware.b4a.keywords.Common.LogImpl("6196637","紙張寬:"+(anywheresoftware.b4a.keywords.Common.NumberFormat2((_pj._getjobsettings /*b4j.example.jobsettings*/ ()._getpagelayout /*b4j.example.pagelayout*/ ()._getprintablewidth /*double*/ ()/(double)72)*25.4,(int) (0),(int) (0),(int) (0),anywheresoftware.b4a.keywords.Common.True)),0);
 //BA.debugLineNum = 133;BA.debugLine="Log(\"紙張高:\"& (NumberFormat( (PJ.GetJobSettings.Ge";
anywheresoftware.b4a.keywords.Common.LogImpl("6196638","紙張高:"+(anywheresoftware.b4a.keywords.Common.NumberFormat((_pj._getjobsettings /*b4j.example.jobsettings*/ ()._getpagelayout /*b4j.example.pagelayout*/ ()._getprintableheight /*double*/ ()/(double)72)*25.4,(int) (0),(int) (0))),0);
 //BA.debugLineNum = 135;BA.debugLine="Log(\"上邊界:\"& (NumberFormat( (PJ.GetJobSettings.Ge";
anywheresoftware.b4a.keywords.Common.LogImpl("6196640","上邊界:"+(anywheresoftware.b4a.keywords.Common.NumberFormat((_pj._getjobsettings /*b4j.example.jobsettings*/ ()._getpagelayout /*b4j.example.pagelayout*/ ()._gettopmargin /*double*/ ()/(double)72)*25.4,(int) (0),(int) (2))),0);
 //BA.debugLineNum = 138;BA.debugLine="Dim success As Boolean";
_success = false;
 //BA.debugLineNum = 140;BA.debugLine="Log(strReportStyle)";
anywheresoftware.b4a.keywords.Common.LogImpl("6196645",_strreportstyle,0);
 //BA.debugLineNum = 141;BA.debugLine="If strReportStyle=\"Rep01\" Then";
if ((_strreportstyle).equals("Rep01")) { 
 //BA.debugLineNum = 142;BA.debugLine="PaneRep.Visible=False";
_panerep.setVisible(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 143;BA.debugLine="PaneClone.Visible=True";
_paneclone.setVisible(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 145;BA.debugLine="PaneClone.AddNode(Utils.ClonePane(Pane1),0,0,45";
_paneclone.AddNode((javafx.scene.Node)(_utils._clonepane /*anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper*/ (_pane1).getObject()),0,0,450,562);
 //BA.debugLineNum = 146;BA.debugLine="PaneClone.Top=0";
_paneclone.setTop(0);
 //BA.debugLineNum = 147;BA.debugLine="PaneClone.Left=0";
_paneclone.setLeft(0);
 //BA.debugLineNum = 150;BA.debugLine="success = PJ.PrintPage(Utils.ScaleOutput3(Layou";
_success = _pj._printpage /*boolean*/ (_utils._scaleoutput3 /*anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper*/ (_layout,(anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper(), (javafx.scene.Node)(_paneclone.getObject())),1));
 }else {
 //BA.debugLineNum = 153;BA.debugLine="PaneRep.Visible=False";
_panerep.setVisible(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 154;BA.debugLine="PaneClone.Visible=False";
_paneclone.setVisible(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 156;BA.debugLine="PaneWebView.Visible=False";
_panewebview.setVisible(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 158;BA.debugLine="PaneCloneW.Visible=True";
_paneclonew.setVisible(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 160;BA.debugLine="PaneCloneW.Left=0";
_paneclonew.setLeft(0);
 //BA.debugLineNum = 161;BA.debugLine="PaneCloneW.Top=0";
_paneclonew.setTop(0);
 //BA.debugLineNum = 164;BA.debugLine="success = PJ.PrintPage(Utils.ScaleOutput3(Layou";
_success = _pj._printpage /*boolean*/ (_utils._scaleoutput3 /*anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper*/ (_layout,(anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper(), (javafx.scene.Node)(_webviewclone.getObject())),1));
 };
 //BA.debugLineNum = 169;BA.debugLine="If success Then";
if (_success) { 
 //BA.debugLineNum = 170;BA.debugLine="PJ.EndJob";
_pj._endjob /*boolean*/ ();
 //BA.debugLineNum = 171;BA.debugLine="Log(\"print OK\")";
anywheresoftware.b4a.keywords.Common.LogImpl("6196676","print OK",0);
 }else {
 //BA.debugLineNum = 174;BA.debugLine="Log(\"PJ-> PrintPage false\")";
anywheresoftware.b4a.keywords.Common.LogImpl("6196679","PJ-> PrintPage false",0);
 };
 //BA.debugLineNum = 177;BA.debugLine="If strReportStyle=\"Rep01\" Then";
if ((_strreportstyle).equals("Rep01")) { 
 //BA.debugLineNum = 179;BA.debugLine="PaneClone.Visible=False";
_paneclone.setVisible(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 180;BA.debugLine="PaneRep.Visible=True";
_panerep.setVisible(anywheresoftware.b4a.keywords.Common.True);
 }else {
 //BA.debugLineNum = 182;BA.debugLine="PaneWebView.Visible=True";
_panewebview.setVisible(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 184;BA.debugLine="PaneRep.Visible=False";
_panerep.setVisible(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 185;BA.debugLine="PaneClone.Visible=False";
_paneclone.setVisible(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 186;BA.debugLine="PaneCloneW.Visible=False";
_paneclonew.setVisible(anywheresoftware.b4a.keywords.Common.False);
 };
 }else {
 //BA.debugLineNum = 194;BA.debugLine="Log(\"Printer not found\")";
anywheresoftware.b4a.keywords.Common.LogImpl("6196699","Printer not found",0);
 };
 //BA.debugLineNum = 198;BA.debugLine="xui.MsgboxAsync(\"finish~~~\",\"B4X\")";
_xui.MsgboxAsync(ba,"finish~~~","B4X");
 //BA.debugLineNum = 201;BA.debugLine="End Sub";
return "";
}
public static String  _draw_barcode_code39(String _mes) throws Exception{
int _mywidth = 0;
int _myheight = 0;
int _silent = 0;
int _cnt = 0;
int _i = 0;
 //BA.debugLineNum = 78;BA.debugLine="Sub draw_barcode_Code39 (mes As String)";
 //BA.debugLineNum = 80;BA.debugLine="Dim mywidth As Int = Canvas1.Width";
_mywidth = (int) (_canvas1.getWidth());
 //BA.debugLineNum = 81;BA.debugLine="Dim myheight As Int = Canvas1.Height	'Ignore";
_myheight = (int) (_canvas1.getHeight());
 //BA.debugLineNum = 82;BA.debugLine="Dim silent As Int = (mywidth - 4*su.stringLength(";
_silent = (int) ((_mywidth-4*_su._stringlength /*int*/ (_mes))/(double)2);
 //BA.debugLineNum = 88;BA.debugLine="Dim cnt As Int = silent + 1";
_cnt = (int) (_silent+1);
 //BA.debugLineNum = 89;BA.debugLine="For i = 0 To su.stringLength(mes) - 1";
{
final int step5 = 1;
final int limit5 = (int) (_su._stringlength /*int*/ (_mes)-1);
_i = (int) (0) ;
for (;_i <= limit5 ;_i = _i + step5 ) {
 //BA.debugLineNum = 90;BA.debugLine="If su.Mid(mes,i,1) = \"1\" Then";
if ((_su._mid /*String*/ (_mes,_i,(int) (1))).equals("1")) { 
 //BA.debugLineNum = 91;BA.debugLine="Canvas1.DrawRect(cnt,10,4,80,fx.Colors.Black,Tr";
_canvas1.DrawRect(_cnt,10,4,80,_fx.Colors.Black,anywheresoftware.b4a.keywords.Common.True,2);
 }else {
 //BA.debugLineNum = 93;BA.debugLine="Canvas1.DrawRect(cnt,10,4,80,fx.Colors.White,Tr";
_canvas1.DrawRect(_cnt,10,4,80,_fx.Colors.White,anywheresoftware.b4a.keywords.Common.True,2);
 };
 //BA.debugLineNum = 95;BA.debugLine="cnt = cnt + 4";
_cnt = (int) (_cnt+4);
 }
};
 //BA.debugLineNum = 98;BA.debugLine="End Sub";
return "";
}

private static boolean processGlobalsRun;
public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        b4j.example.dateutils._process_globals();
b4j.example.cssutils._process_globals();
main._process_globals();
printerjob_static._process_globals();
pageorientation_static._process_globals();
printer_static._process_globals();
paper_static._process_globals();
utils._process_globals();
adhocwrappers._process_globals();
code39._process_globals();
xuiviewsutils._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 16;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 17;BA.debugLine="Private fx As JFX";
_fx = new anywheresoftware.b4j.objects.JFX();
 //BA.debugLineNum = 18;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 20;BA.debugLine="Private su As StringUtilities";
_su = new b4j.example.stringutilities();
 //BA.debugLineNum = 21;BA.debugLine="Private MainForm As Form";
_mainform = new anywheresoftware.b4j.objects.Form();
 //BA.debugLineNum = 22;BA.debugLine="Private Pane1 As Pane";
_pane1 = new anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper();
 //BA.debugLineNum = 23;BA.debugLine="Private Canvas1 As Canvas";
_canvas1 = new anywheresoftware.b4j.objects.CanvasWrapper();
 //BA.debugLineNum = 25;BA.debugLine="Private Pane2 As Pane";
_pane2 = new anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper();
 //BA.debugLineNum = 26;BA.debugLine="Private WebView1 As WebView";
_webview1 = new anywheresoftware.b4j.objects.WebViewWrapper();
 //BA.debugLineNum = 27;BA.debugLine="Private PaneRep As Pane";
_panerep = new anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper();
 //BA.debugLineNum = 28;BA.debugLine="Private PaneClone As Pane";
_paneclone = new anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper();
 //BA.debugLineNum = 29;BA.debugLine="Private TabPane1 As TabPane";
_tabpane1 = new anywheresoftware.b4j.objects.TabPaneWrapper();
 //BA.debugLineNum = 30;BA.debugLine="Private btnRep01 As Button";
_btnrep01 = new anywheresoftware.b4j.objects.ButtonWrapper();
 //BA.debugLineNum = 31;BA.debugLine="Private btnRep02 As Button";
_btnrep02 = new anywheresoftware.b4j.objects.ButtonWrapper();
 //BA.debugLineNum = 32;BA.debugLine="Private PaneWebView As Pane";
_panewebview = new anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper();
 //BA.debugLineNum = 34;BA.debugLine="Private WebViewClone As WebView";
_webviewclone = new anywheresoftware.b4j.objects.WebViewWrapper();
 //BA.debugLineNum = 37;BA.debugLine="Dim strReportStyle As String = \"Rep01\"";
_strreportstyle = "Rep01";
 //BA.debugLineNum = 38;BA.debugLine="Private PaneCloneW As Pane";
_paneclonew = new anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper();
 //BA.debugLineNum = 39;BA.debugLine="Private btnRepB01 As Button";
_btnrepb01 = new anywheresoftware.b4j.objects.ButtonWrapper();
 //BA.debugLineNum = 40;BA.debugLine="Private PaneRepB As Pane";
_panerepb = new anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper();
 //BA.debugLineNum = 41;BA.debugLine="Private PaneB As Pane";
_paneb = new anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper();
 //BA.debugLineNum = 42;BA.debugLine="Private lab01 As Label";
_lab01 = new anywheresoftware.b4j.objects.LabelWrapper();
 //BA.debugLineNum = 43;BA.debugLine="Private lab02 As Label";
_lab02 = new anywheresoftware.b4j.objects.LabelWrapper();
 //BA.debugLineNum = 44;BA.debugLine="Private lab03 As Label";
_lab03 = new anywheresoftware.b4j.objects.LabelWrapper();
 //BA.debugLineNum = 45;BA.debugLine="Private lab04 As Label";
_lab04 = new anywheresoftware.b4j.objects.LabelWrapper();
 //BA.debugLineNum = 46;BA.debugLine="End Sub";
return "";
}
}
