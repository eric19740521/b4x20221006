package b4j.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class jobsettings extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.jobsettings", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.example.jobsettings.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4j.object.JavaObject _js = null;
public b4j.example.dateutils _dateutils = null;
public b4j.example.cssutils _cssutils = null;
public b4j.example.main _main = null;
public b4j.example.printerjob_static _printerjob_static = null;
public b4j.example.pageorientation_static _pageorientation_static = null;
public b4j.example.printer_static _printer_static = null;
public b4j.example.paper_static _paper_static = null;
public b4j.example.utils _utils = null;
public b4j.example.adhocwrappers _adhocwrappers = null;
public b4j.example.code39 _code39 = null;
public b4j.example.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 2;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Private JS As JavaObject";
_js = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 6;BA.debugLine="End Sub";
return "";
}
public String  _getcollation() throws Exception{
 //BA.debugLineNum = 15;BA.debugLine="Public Sub GetCollation As String";
 //BA.debugLineNum = 16;BA.debugLine="Return JS.RunMethod(\"getCollation\",Null)";
if (true) return BA.ObjectToString(_js.RunMethod("getCollation",(Object[])(__c.Null)));
 //BA.debugLineNum = 17;BA.debugLine="End Sub";
return "";
}
public int  _getcopies() throws Exception{
 //BA.debugLineNum = 19;BA.debugLine="Public Sub GetCopies As Int";
 //BA.debugLineNum = 20;BA.debugLine="Return JS.RunMethod(\"getCopies\",Null)";
if (true) return (int)(BA.ObjectToNumber(_js.RunMethod("getCopies",(Object[])(__c.Null))));
 //BA.debugLineNum = 21;BA.debugLine="End Sub";
return 0;
}
public String  _getjobname() throws Exception{
 //BA.debugLineNum = 23;BA.debugLine="Public Sub GetJobName As String";
 //BA.debugLineNum = 24;BA.debugLine="Return JS.RunMethod(\"getJobName\",Null)";
if (true) return BA.ObjectToString(_js.RunMethod("getJobName",(Object[])(__c.Null)));
 //BA.debugLineNum = 25;BA.debugLine="End Sub";
return "";
}
public Object  _getobject() throws Exception{
 //BA.debugLineNum = 129;BA.debugLine="Public Sub GetObject As Object";
 //BA.debugLineNum = 130;BA.debugLine="Return JS";
if (true) return (Object)(_js.getObject());
 //BA.debugLineNum = 131;BA.debugLine="End Sub";
return null;
}
public b4j.example.pagelayout  _getpagelayout() throws Exception{
b4j.example.pagelayout _pl = null;
 //BA.debugLineNum = 27;BA.debugLine="Public Sub GetPageLayout As PageLayout";
 //BA.debugLineNum = 28;BA.debugLine="Dim PL As PageLayout";
_pl = new b4j.example.pagelayout();
 //BA.debugLineNum = 29;BA.debugLine="PL.Initialize";
_pl._initialize /*String*/ (ba);
 //BA.debugLineNum = 30;BA.debugLine="PL.SetObject(JS.RunMethod(\"getPageLayout\",Null))";
_pl._setobject /*String*/ ((anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_js.RunMethod("getPageLayout",(Object[])(__c.Null)))));
 //BA.debugLineNum = 31;BA.debugLine="Return PL";
if (true) return _pl;
 //BA.debugLineNum = 32;BA.debugLine="End Sub";
return null;
}
public b4j.example.printerjob_static._pagerange  _getpageranges() throws Exception{
anywheresoftware.b4j.object.JavaObject _pr = null;
b4j.example.printerjob_static._pagerange _rv = null;
 //BA.debugLineNum = 34;BA.debugLine="Public Sub GetPageRanges As PageRange";
 //BA.debugLineNum = 35;BA.debugLine="Dim PR As JavaObject =  JS.RunMethod(\"getPageRang";
_pr = new anywheresoftware.b4j.object.JavaObject();
_pr = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_js.RunMethod("getPageRanges",(Object[])(__c.Null))));
 //BA.debugLineNum = 36;BA.debugLine="Dim RV As PageRange";
_rv = new b4j.example.printerjob_static._pagerange();
 //BA.debugLineNum = 37;BA.debugLine="RV.Initialize";
_rv.Initialize();
 //BA.debugLineNum = 38;BA.debugLine="RV.StartPage = PR.RunMethod(\"getStartPage\",Null)";
_rv.StartPage /*int*/  = (int)(BA.ObjectToNumber(_pr.RunMethod("getStartPage",(Object[])(__c.Null))));
 //BA.debugLineNum = 39;BA.debugLine="RV.EndPage = PR.RunMethod(\"getEndPage\",Null)";
_rv.EndPage /*int*/  = (int)(BA.ObjectToNumber(_pr.RunMethod("getEndPage",(Object[])(__c.Null))));
 //BA.debugLineNum = 40;BA.debugLine="Return RV";
if (true) return _rv;
 //BA.debugLineNum = 41;BA.debugLine="End Sub";
return null;
}
public String  _getpapersource() throws Exception{
 //BA.debugLineNum = 44;BA.debugLine="Public Sub GetPaperSource As String";
 //BA.debugLineNum = 45;BA.debugLine="Return JS.RunMethod(\"getPaperSource\",Null)";
if (true) return BA.ObjectToString(_js.RunMethod("getPaperSource",(Object[])(__c.Null)));
 //BA.debugLineNum = 46;BA.debugLine="End Sub";
return "";
}
public String  _getprintcolor() throws Exception{
 //BA.debugLineNum = 49;BA.debugLine="Public Sub GetPrintColor As String";
 //BA.debugLineNum = 50;BA.debugLine="Return JS.RunMethod(\"getPrintColor\",Null)";
if (true) return BA.ObjectToString(_js.RunMethod("getPrintColor",(Object[])(__c.Null)));
 //BA.debugLineNum = 51;BA.debugLine="End Sub";
return "";
}
public String  _getprintquality() throws Exception{
 //BA.debugLineNum = 54;BA.debugLine="Public Sub GetPrintQuality As String";
 //BA.debugLineNum = 55;BA.debugLine="Return JS.RunMethod(\"getPrintQuality\",Null)";
if (true) return BA.ObjectToString(_js.RunMethod("getPrintQuality",(Object[])(__c.Null)));
 //BA.debugLineNum = 56;BA.debugLine="End Sub";
return "";
}
public b4j.example.printerjob_static._printresolution  _getprintresolution() throws Exception{
b4j.example.printerjob_static._printresolution _pr = null;
anywheresoftware.b4j.object.JavaObject _jo = null;
 //BA.debugLineNum = 58;BA.debugLine="Public Sub GetPrintResolution As PrintResolution";
 //BA.debugLineNum = 59;BA.debugLine="Dim PR As PrintResolution";
_pr = new b4j.example.printerjob_static._printresolution();
 //BA.debugLineNum = 60;BA.debugLine="PR.Initialize";
_pr.Initialize();
 //BA.debugLineNum = 61;BA.debugLine="Dim JO As JavaObject = JS.RunMethod(\"getPrintReso";
_jo = new anywheresoftware.b4j.object.JavaObject();
_jo = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_js.RunMethod("getPrintResolution",(Object[])(__c.Null))));
 //BA.debugLineNum = 62;BA.debugLine="PR.CrossFeedResolution = JO.RunMethod(\"getCrossFe";
_pr.CrossFeedResolution /*int*/  = (int)(BA.ObjectToNumber(_jo.RunMethod("getCrossFeedResolution",(Object[])(__c.Null))));
 //BA.debugLineNum = 63;BA.debugLine="PR.FeedResolution = JO.RunMethod(\"getFeedResoluti";
_pr.FeedResolution /*int*/  = (int)(BA.ObjectToNumber(_jo.RunMethod("getFeedResolution",(Object[])(__c.Null))));
 //BA.debugLineNum = 64;BA.debugLine="Return PR";
if (true) return _pr;
 //BA.debugLineNum = 65;BA.debugLine="End Sub";
return null;
}
public String  _getprintsides() throws Exception{
 //BA.debugLineNum = 68;BA.debugLine="Public Sub GetPrintSides As String";
 //BA.debugLineNum = 69;BA.debugLine="Return JS.RunMethod(\"getPrintSides\",Null)";
if (true) return BA.ObjectToString(_js.RunMethod("getPrintSides",(Object[])(__c.Null)));
 //BA.debugLineNum = 70;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 8;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 10;BA.debugLine="JS.InitializeStatic(\"javafx.print.JobSettings\")";
_js.InitializeStatic("javafx.print.JobSettings");
 //BA.debugLineNum = 11;BA.debugLine="End Sub";
return "";
}
public String  _setcollation(String _collation) throws Exception{
 //BA.debugLineNum = 73;BA.debugLine="Public Sub SetCollation(Collation As String)";
 //BA.debugLineNum = 74;BA.debugLine="JS.RunMethod(\"setCollation\",Array As Object(Colla";
_js.RunMethod("setCollation",new Object[]{(Object)(_collation.toUpperCase())});
 //BA.debugLineNum = 75;BA.debugLine="End Sub";
return "";
}
public String  _setcopies(int _ncopies) throws Exception{
 //BA.debugLineNum = 77;BA.debugLine="Public Sub SetCopies(NCopies As Int)";
 //BA.debugLineNum = 78;BA.debugLine="JS.RunMethod(\"setCopies\",Array As Object(NCopies)";
_js.RunMethod("setCopies",new Object[]{(Object)(_ncopies)});
 //BA.debugLineNum = 79;BA.debugLine="End Sub";
return "";
}
public String  _setjobname(String _jobname) throws Exception{
 //BA.debugLineNum = 81;BA.debugLine="Public Sub SetJobName(JobName As String)";
 //BA.debugLineNum = 82;BA.debugLine="JS.RunMethod(\"setJobName\",Array As Object(JobName";
_js.RunMethod("setJobName",new Object[]{(Object)(_jobname)});
 //BA.debugLineNum = 83;BA.debugLine="End Sub";
return "";
}
public String  _setobject(Object _obj) throws Exception{
 //BA.debugLineNum = 132;BA.debugLine="Public Sub SetObject (Obj As Object)";
 //BA.debugLineNum = 133;BA.debugLine="JS = Obj";
_js = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_obj));
 //BA.debugLineNum = 134;BA.debugLine="End Sub";
return "";
}
public String  _setpagelayout(b4j.example.pagelayout _playout) throws Exception{
 //BA.debugLineNum = 85;BA.debugLine="Public Sub SetPageLayout(PLayout As PageLayout)";
 //BA.debugLineNum = 86;BA.debugLine="JS.RunMethod(\"setPageLayout\",Array As Object(PLay";
_js.RunMethod("setPageLayout",new Object[]{_playout._getobject /*Object*/ ()});
 //BA.debugLineNum = 87;BA.debugLine="End Sub";
return "";
}
public String  _setpageranges(b4j.example.printerjob_static._pagerange _pages) throws Exception{
anywheresoftware.b4j.object.JavaObject _pr = null;
 //BA.debugLineNum = 89;BA.debugLine="Public Sub SetPageRanges(Pages As PageRange)";
 //BA.debugLineNum = 90;BA.debugLine="Dim PR As JavaObject";
_pr = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 91;BA.debugLine="PR.InitializeNewInstance(\"javafx.print.PageRange\"";
_pr.InitializeNewInstance("javafx.print.PageRange",new Object[]{(Object)(_pages.StartPage /*int*/ ),(Object)(_pages.EndPage /*int*/ )});
 //BA.debugLineNum = 92;BA.debugLine="JS.RunMethod(\"setPageRanges\",Array As Object(PR))";
_js.RunMethod("setPageRanges",new Object[]{(Object)(_pr.getObject())});
 //BA.debugLineNum = 93;BA.debugLine="End Sub";
return "";
}
public String  _setpapersource(Object _value) throws Exception{
 //BA.debugLineNum = 99;BA.debugLine="Public Sub SetPaperSource(Value As Object)";
 //BA.debugLineNum = 100;BA.debugLine="JS.RunMethod(\"setPaperSource\",Array As Object(Val";
_js.RunMethod("setPaperSource",new Object[]{_value});
 //BA.debugLineNum = 101;BA.debugLine="End Sub";
return "";
}
public String  _setprintcolor(String _color) throws Exception{
 //BA.debugLineNum = 104;BA.debugLine="Public Sub SetPrintColor(Color As String)";
 //BA.debugLineNum = 105;BA.debugLine="JS.RunMethod(\"setPrintColor\",Array As Object(Colo";
_js.RunMethod("setPrintColor",new Object[]{(Object)(_color.toUpperCase())});
 //BA.debugLineNum = 106;BA.debugLine="End Sub";
return "";
}
public String  _setprintquality(String _quality) throws Exception{
 //BA.debugLineNum = 109;BA.debugLine="Public Sub SetPrintQuality(Quality As String)";
 //BA.debugLineNum = 110;BA.debugLine="JS.RunMethod(\"setPrintQuality\",Array As Object(Qu";
_js.RunMethod("setPrintQuality",new Object[]{(Object)(_quality.toUpperCase())});
 //BA.debugLineNum = 111;BA.debugLine="End Sub";
return "";
}
public String  _setprintresolution(Object _resolution) throws Exception{
 //BA.debugLineNum = 117;BA.debugLine="Public Sub SetPrintResolution(Resolution As Object";
 //BA.debugLineNum = 118;BA.debugLine="JS.RunMethod(\"setPrintResolution\",Array As Object";
_js.RunMethod("setPrintResolution",new Object[]{_resolution});
 //BA.debugLineNum = 119;BA.debugLine="End Sub";
return "";
}
public String  _setprintsides(String _sides) throws Exception{
 //BA.debugLineNum = 122;BA.debugLine="Public Sub SetPrintSides(Sides As String)";
 //BA.debugLineNum = 123;BA.debugLine="JS.RunMethod(\"setPrintSides\",Array As Object(Side";
_js.RunMethod("setPrintSides",new Object[]{(Object)(_sides.toUpperCase())});
 //BA.debugLineNum = 124;BA.debugLine="End Sub";
return "";
}
public String  _tostring() throws Exception{
 //BA.debugLineNum = 126;BA.debugLine="Public Sub ToString As String";
 //BA.debugLineNum = 127;BA.debugLine="Return JS.RunMethod(\"toString\",Null)";
if (true) return BA.ObjectToString(_js.RunMethod("toString",(Object[])(__c.Null)));
 //BA.debugLineNum = 128;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
