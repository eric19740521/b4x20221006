package b4j.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class pagelayout extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.pagelayout", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.example.pagelayout.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4j.object.JavaObject _playout = null;
public b4j.example.paper _mpaper = null;
public b4j.example.dateutils _dateutils = null;
public b4j.example.cssutils _cssutils = null;
public b4j.example.main _main = null;
public b4j.example.printerjob_static _printerjob_static = null;
public b4j.example.pageorientation_static _pageorientation_static = null;
public b4j.example.printer_static _printer_static = null;
public b4j.example.paper_static _paper_static = null;
public b4j.example.utils _utils = null;
public b4j.example.adhocwrappers _adhocwrappers = null;
public b4j.example.code39 _code39 = null;
public b4j.example.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 2;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Private PLayout As JavaObject";
_playout = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 5;BA.debugLine="Private mPaper As Paper";
_mpaper = new b4j.example.paper();
 //BA.debugLineNum = 7;BA.debugLine="End Sub";
return "";
}
public boolean  _equals(Object _o) throws Exception{
 //BA.debugLineNum = 15;BA.debugLine="Public Sub Equals(O As Object) As Boolean";
 //BA.debugLineNum = 16;BA.debugLine="Return PLayout.RunMethod(\"equals\",Array As Object";
if (true) return BA.ObjectToBoolean(_playout.RunMethod("equals",new Object[]{_o}));
 //BA.debugLineNum = 17;BA.debugLine="End Sub";
return false;
}
public double  _getbottommargin() throws Exception{
 //BA.debugLineNum = 19;BA.debugLine="Public Sub GetBottomMargin As Double";
 //BA.debugLineNum = 20;BA.debugLine="Return PLayout.RunMethod(\"getBottomMargin\",Null)";
if (true) return (double)(BA.ObjectToNumber(_playout.RunMethod("getBottomMargin",(Object[])(__c.Null))));
 //BA.debugLineNum = 21;BA.debugLine="End Sub";
return 0;
}
public double  _getleftmargin() throws Exception{
 //BA.debugLineNum = 23;BA.debugLine="Public Sub GetLeftMargin As Double";
 //BA.debugLineNum = 24;BA.debugLine="Return PLayout.RunMethod(\"getLeftMargin\",Null)";
if (true) return (double)(BA.ObjectToNumber(_playout.RunMethod("getLeftMargin",(Object[])(__c.Null))));
 //BA.debugLineNum = 25;BA.debugLine="End Sub";
return 0;
}
public Object  _getobject() throws Exception{
 //BA.debugLineNum = 58;BA.debugLine="Public Sub GetObject As Object";
 //BA.debugLineNum = 59;BA.debugLine="Return PLayout";
if (true) return (Object)(_playout.getObject());
 //BA.debugLineNum = 60;BA.debugLine="End Sub";
return null;
}
public anywheresoftware.b4j.object.JavaObject  _getpageorientation() throws Exception{
 //BA.debugLineNum = 27;BA.debugLine="Public Sub GetPageOrientation As JavaObject";
 //BA.debugLineNum = 28;BA.debugLine="Return PLayout.RunMethod(\"getPageOrientation\",Nul";
if (true) return (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_playout.RunMethod("getPageOrientation",(Object[])(__c.Null))));
 //BA.debugLineNum = 29;BA.debugLine="End Sub";
return null;
}
public b4j.example.paper  _getpaper() throws Exception{
 //BA.debugLineNum = 31;BA.debugLine="Public Sub GetPaper As Paper";
 //BA.debugLineNum = 32;BA.debugLine="If Not(mPaper.IsInitialized) Then";
if (__c.Not(_mpaper.IsInitialized /*boolean*/ ())) { 
 //BA.debugLineNum = 33;BA.debugLine="mPaper.Initialize";
_mpaper._initialize /*String*/ (ba);
 //BA.debugLineNum = 34;BA.debugLine="mPaper.SetObject(PLayout.RunMethod(\"getPaper\",Nu";
_mpaper._setobject /*String*/ ((anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_playout.RunMethod("getPaper",(Object[])(__c.Null)))));
 };
 //BA.debugLineNum = 36;BA.debugLine="Return mPaper";
if (true) return _mpaper;
 //BA.debugLineNum = 37;BA.debugLine="End Sub";
return null;
}
public double  _getprintableheight() throws Exception{
 //BA.debugLineNum = 39;BA.debugLine="Public Sub GetPrintableHeight As Double";
 //BA.debugLineNum = 40;BA.debugLine="Return PLayout.RunMethod(\"getPrintableHeight\",Nul";
if (true) return (double)(BA.ObjectToNumber(_playout.RunMethod("getPrintableHeight",(Object[])(__c.Null))));
 //BA.debugLineNum = 41;BA.debugLine="End Sub";
return 0;
}
public double  _getprintablewidth() throws Exception{
 //BA.debugLineNum = 43;BA.debugLine="Public Sub GetPrintableWidth As Double";
 //BA.debugLineNum = 44;BA.debugLine="Return PLayout.RunMethod(\"getPrintableWidth\",Null";
if (true) return (double)(BA.ObjectToNumber(_playout.RunMethod("getPrintableWidth",(Object[])(__c.Null))));
 //BA.debugLineNum = 45;BA.debugLine="End Sub";
return 0;
}
public double  _getrightmargin() throws Exception{
 //BA.debugLineNum = 47;BA.debugLine="Public Sub GetRightMargin As Double";
 //BA.debugLineNum = 48;BA.debugLine="Return PLayout.RunMethod(\"getRightMargin\",Null)";
if (true) return (double)(BA.ObjectToNumber(_playout.RunMethod("getRightMargin",(Object[])(__c.Null))));
 //BA.debugLineNum = 49;BA.debugLine="End Sub";
return 0;
}
public double  _gettopmargin() throws Exception{
 //BA.debugLineNum = 51;BA.debugLine="Public Sub GetTopMargin As Double";
 //BA.debugLineNum = 52;BA.debugLine="Return PLayout.RunMethod(\"getTopMargin\",Null)";
if (true) return (double)(BA.ObjectToNumber(_playout.RunMethod("getTopMargin",(Object[])(__c.Null))));
 //BA.debugLineNum = 53;BA.debugLine="End Sub";
return 0;
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 9;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 11;BA.debugLine="PLayout.InitializeStatic(\"javafx.print.PageLayout";
_playout.InitializeStatic("javafx.print.PageLayout");
 //BA.debugLineNum = 12;BA.debugLine="End Sub";
return "";
}
public String  _setobject(anywheresoftware.b4j.object.JavaObject _pl) throws Exception{
 //BA.debugLineNum = 61;BA.debugLine="Public Sub SetObject (PL As JavaObject)";
 //BA.debugLineNum = 62;BA.debugLine="PLayout = PL";
_playout = _pl;
 //BA.debugLineNum = 63;BA.debugLine="End Sub";
return "";
}
public String  _tostring() throws Exception{
 //BA.debugLineNum = 55;BA.debugLine="Public Sub ToString As String";
 //BA.debugLineNum = 56;BA.debugLine="Return PLayout.RunMethod(\"toString\",Null)";
if (true) return BA.ObjectToString(_playout.RunMethod("toString",(Object[])(__c.Null)));
 //BA.debugLineNum = 57;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
