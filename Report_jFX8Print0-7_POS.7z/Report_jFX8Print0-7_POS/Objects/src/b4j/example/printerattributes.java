package b4j.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class printerattributes extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.printerattributes", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.example.printerattributes.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4j.object.JavaObject _pa = null;
public b4j.example.dateutils _dateutils = null;
public b4j.example.cssutils _cssutils = null;
public b4j.example.main _main = null;
public b4j.example.printerjob_static _printerjob_static = null;
public b4j.example.pageorientation_static _pageorientation_static = null;
public b4j.example.printer_static _printer_static = null;
public b4j.example.paper_static _paper_static = null;
public b4j.example.utils _utils = null;
public b4j.example.adhocwrappers _adhocwrappers = null;
public b4j.example.code39 _code39 = null;
public b4j.example.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 2;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Private PA As JavaObject";
_pa = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 6;BA.debugLine="End Sub";
return "";
}
public String  _getdefaultcollation() throws Exception{
 //BA.debugLineNum = 14;BA.debugLine="Public Sub GetDefaultCollation As String";
 //BA.debugLineNum = 16;BA.debugLine="Return PA.RunMethod(\"getDefaultCollation\",Null)";
if (true) return BA.ObjectToString(_pa.RunMethod("getDefaultCollation",(Object[])(__c.Null)));
 //BA.debugLineNum = 17;BA.debugLine="End Sub";
return "";
}
public int  _getdefaultcopies() throws Exception{
 //BA.debugLineNum = 19;BA.debugLine="Public Sub GetDefaultCopies As Int";
 //BA.debugLineNum = 20;BA.debugLine="Return PA.RunMethod(\"getDefaultCopies\",Null)";
if (true) return (int)(BA.ObjectToNumber(_pa.RunMethod("getDefaultCopies",(Object[])(__c.Null))));
 //BA.debugLineNum = 21;BA.debugLine="End Sub";
return 0;
}
public String  _getdefaultpageorientation() throws Exception{
 //BA.debugLineNum = 24;BA.debugLine="Public Sub GetDefaultPageOrientation As String";
 //BA.debugLineNum = 25;BA.debugLine="Return PA.RunMethod(\"getDefaultPageOrientation\",N";
if (true) return BA.ObjectToString(_pa.RunMethod("getDefaultPageOrientation",(Object[])(__c.Null)));
 //BA.debugLineNum = 26;BA.debugLine="End Sub";
return "";
}
public b4j.example.paper  _getdefaultpaper() throws Exception{
b4j.example.paper _p = null;
 //BA.debugLineNum = 28;BA.debugLine="Public Sub GetDefaultPaper As Paper";
 //BA.debugLineNum = 29;BA.debugLine="Dim P As Paper";
_p = new b4j.example.paper();
 //BA.debugLineNum = 30;BA.debugLine="P.Initialize";
_p._initialize /*String*/ (ba);
 //BA.debugLineNum = 31;BA.debugLine="P.SetObject(PA.RunMethod(\"getDefaultPaper\",Null))";
_p._setobject /*String*/ ((anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_pa.RunMethod("getDefaultPaper",(Object[])(__c.Null)))));
 //BA.debugLineNum = 32;BA.debugLine="Return P";
if (true) return _p;
 //BA.debugLineNum = 33;BA.debugLine="End Sub";
return null;
}
public String  _getdefaultpapersource() throws Exception{
 //BA.debugLineNum = 36;BA.debugLine="Public Sub GetDefaultPaperSource As String";
 //BA.debugLineNum = 37;BA.debugLine="Return PA.RunMethod(\"getDefaultPaperSource\",Null)";
if (true) return BA.ObjectToString(_pa.RunMethod("getDefaultPaperSource",(Object[])(__c.Null)));
 //BA.debugLineNum = 38;BA.debugLine="End Sub";
return "";
}
public String  _getdefaultprintcolor() throws Exception{
 //BA.debugLineNum = 41;BA.debugLine="Public Sub GetDefaultPrintColor As String";
 //BA.debugLineNum = 42;BA.debugLine="Return PA.RunMethod(\"getDefaultPrintColor\",Null)";
if (true) return BA.ObjectToString(_pa.RunMethod("getDefaultPrintColor",(Object[])(__c.Null)));
 //BA.debugLineNum = 43;BA.debugLine="End Sub";
return "";
}
public String  _getdefaultprintquality() throws Exception{
 //BA.debugLineNum = 46;BA.debugLine="Public Sub GetDefaultPrintQuality As String";
 //BA.debugLineNum = 47;BA.debugLine="Return PA.RunMethod(\"getDefaultPrintQuality\",Null";
if (true) return BA.ObjectToString(_pa.RunMethod("getDefaultPrintQuality",(Object[])(__c.Null)));
 //BA.debugLineNum = 48;BA.debugLine="End Sub";
return "";
}
public b4j.example.printerjob_static._printresolution  _getdefaultprintresolution() throws Exception{
b4j.example.printerjob_static._printresolution _pr = null;
anywheresoftware.b4j.object.JavaObject _jo = null;
 //BA.debugLineNum = 50;BA.debugLine="Public Sub GetDefaultPrintResolution As PrintResol";
 //BA.debugLineNum = 51;BA.debugLine="Dim PR As PrintResolution";
_pr = new b4j.example.printerjob_static._printresolution();
 //BA.debugLineNum = 52;BA.debugLine="PR.Initialize";
_pr.Initialize();
 //BA.debugLineNum = 53;BA.debugLine="Dim JO As JavaObject =PA.RunMethod(\"getDefaultPri";
_jo = new anywheresoftware.b4j.object.JavaObject();
_jo = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_pa.RunMethod("getDefaultPrintResolution",(Object[])(__c.Null))));
 //BA.debugLineNum = 54;BA.debugLine="PR.CrossFeedResolution = JO.RunMethod(\"getCrossFe";
_pr.CrossFeedResolution /*int*/  = (int)(BA.ObjectToNumber(_jo.RunMethod("getCrossFeedResolution",(Object[])(__c.Null))));
 //BA.debugLineNum = 55;BA.debugLine="PR.FeedResolution = JO.RunMethod(\"getFeedResoluti";
_pr.FeedResolution /*int*/  = (int)(BA.ObjectToNumber(_jo.RunMethod("getFeedResolution",(Object[])(__c.Null))));
 //BA.debugLineNum = 56;BA.debugLine="Return PR";
if (true) return _pr;
 //BA.debugLineNum = 57;BA.debugLine="End Sub";
return null;
}
public String  _getdefaultprintsides() throws Exception{
 //BA.debugLineNum = 60;BA.debugLine="Public Sub GetDefaultPrintSides As String";
 //BA.debugLineNum = 61;BA.debugLine="Return PA.RunMethod(\"getDefaultPrintSides\",Null)";
if (true) return BA.ObjectToString(_pa.RunMethod("getDefaultPrintSides",(Object[])(__c.Null)));
 //BA.debugLineNum = 62;BA.debugLine="End Sub";
return "";
}
public int  _getmaxcopies() throws Exception{
 //BA.debugLineNum = 64;BA.debugLine="Public Sub GetMaxCopies As Int";
 //BA.debugLineNum = 65;BA.debugLine="Return PA.RunMethod(\"getMaxCopies\",Null)";
if (true) return (int)(BA.ObjectToNumber(_pa.RunMethod("getMaxCopies",(Object[])(__c.Null))));
 //BA.debugLineNum = 66;BA.debugLine="End Sub";
return 0;
}
public Object  _getobject() throws Exception{
 //BA.debugLineNum = 176;BA.debugLine="Public Sub GetObject As Object";
 //BA.debugLineNum = 177;BA.debugLine="Return PA";
if (true) return (Object)(_pa.getObject());
 //BA.debugLineNum = 178;BA.debugLine="End Sub";
return null;
}
public anywheresoftware.b4a.objects.collections.List  _getsupportedcollations() throws Exception{
anywheresoftware.b4a.objects.collections.List _l = null;
anywheresoftware.b4j.object.JavaObject _co = null;
anywheresoftware.b4j.object.JavaObject _iterator = null;
 //BA.debugLineNum = 69;BA.debugLine="Public Sub GetSupportedCollations As List";
 //BA.debugLineNum = 70;BA.debugLine="Dim L As List";
_l = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 71;BA.debugLine="L.Initialize";
_l.Initialize();
 //BA.debugLineNum = 72;BA.debugLine="Dim CO As JavaObject = PA.RunMethod(\"getSupported";
_co = new anywheresoftware.b4j.object.JavaObject();
_co = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_pa.RunMethod("getSupportedCollations",(Object[])(__c.Null))));
 //BA.debugLineNum = 74;BA.debugLine="Dim Iterator As JavaObject = CO.RunMethod(\"ite";
_iterator = new anywheresoftware.b4j.object.JavaObject();
_iterator = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_co.RunMethod("iterator",(Object[])(__c.Null))));
 //BA.debugLineNum = 76;BA.debugLine="Do While Iterator.RunMethod(\"hasNext\",Null)";
while (BA.ObjectToBoolean(_iterator.RunMethod("hasNext",(Object[])(__c.Null)))) {
 //BA.debugLineNum = 77;BA.debugLine="L.Add(Iterator.RunMethod(\"next\",Null))";
_l.Add(_iterator.RunMethod("next",(Object[])(__c.Null)));
 }
;
 //BA.debugLineNum = 79;BA.debugLine="Return L";
if (true) return _l;
 //BA.debugLineNum = 80;BA.debugLine="End Sub";
return null;
}
public anywheresoftware.b4a.objects.collections.List  _getsupportedpageorientations() throws Exception{
anywheresoftware.b4a.objects.collections.List _l = null;
anywheresoftware.b4j.object.JavaObject _po = null;
anywheresoftware.b4j.object.JavaObject _iterator = null;
 //BA.debugLineNum = 82;BA.debugLine="Public Sub GetSupportedPageOrientations As List";
 //BA.debugLineNum = 83;BA.debugLine="Dim L As List";
_l = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 84;BA.debugLine="L.Initialize";
_l.Initialize();
 //BA.debugLineNum = 85;BA.debugLine="Dim PO As JavaObject = PA.RunMethod(\"getSupported";
_po = new anywheresoftware.b4j.object.JavaObject();
_po = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_pa.RunMethod("getSupportedPageOrientations",(Object[])(__c.Null))));
 //BA.debugLineNum = 87;BA.debugLine="Dim Iterator As JavaObject = PO.RunMethod(\"ite";
_iterator = new anywheresoftware.b4j.object.JavaObject();
_iterator = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_po.RunMethod("iterator",(Object[])(__c.Null))));
 //BA.debugLineNum = 89;BA.debugLine="Do While Iterator.RunMethod(\"hasNext\",Null)";
while (BA.ObjectToBoolean(_iterator.RunMethod("hasNext",(Object[])(__c.Null)))) {
 //BA.debugLineNum = 90;BA.debugLine="L.Add(Iterator.RunMethod(\"next\",Null))";
_l.Add(_iterator.RunMethod("next",(Object[])(__c.Null)));
 }
;
 //BA.debugLineNum = 92;BA.debugLine="Return L";
if (true) return _l;
 //BA.debugLineNum = 93;BA.debugLine="End Sub";
return null;
}
public anywheresoftware.b4a.objects.collections.List  _getsupportedpapers() throws Exception{
anywheresoftware.b4a.objects.collections.List _l = null;
anywheresoftware.b4j.object.JavaObject _sp = null;
anywheresoftware.b4j.object.JavaObject _iterator = null;
 //BA.debugLineNum = 95;BA.debugLine="Public Sub GetSupportedPapers As List";
 //BA.debugLineNum = 96;BA.debugLine="Dim L As List";
_l = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 97;BA.debugLine="L.Initialize";
_l.Initialize();
 //BA.debugLineNum = 98;BA.debugLine="Dim SP As JavaObject = PA.RunMethod(\"getSupported";
_sp = new anywheresoftware.b4j.object.JavaObject();
_sp = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_pa.RunMethod("getSupportedPapers",(Object[])(__c.Null))));
 //BA.debugLineNum = 100;BA.debugLine="Dim Iterator As JavaObject = SP.RunMethod(\"ite";
_iterator = new anywheresoftware.b4j.object.JavaObject();
_iterator = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_sp.RunMethod("iterator",(Object[])(__c.Null))));
 //BA.debugLineNum = 102;BA.debugLine="Do While Iterator.RunMethod(\"hasNext\",Null)";
while (BA.ObjectToBoolean(_iterator.RunMethod("hasNext",(Object[])(__c.Null)))) {
 //BA.debugLineNum = 103;BA.debugLine="L.Add(Iterator.RunMethod(\"next\",Null))";
_l.Add(_iterator.RunMethod("next",(Object[])(__c.Null)));
 }
;
 //BA.debugLineNum = 105;BA.debugLine="Return L";
if (true) return _l;
 //BA.debugLineNum = 106;BA.debugLine="End Sub";
return null;
}
public anywheresoftware.b4a.objects.collections.List  _getsupportedpapersources() throws Exception{
anywheresoftware.b4a.objects.collections.List _l = null;
anywheresoftware.b4j.object.JavaObject _ps = null;
anywheresoftware.b4j.object.JavaObject _iterator = null;
 //BA.debugLineNum = 108;BA.debugLine="Public Sub GetSupportedPaperSources As List";
 //BA.debugLineNum = 109;BA.debugLine="Dim L As List";
_l = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 110;BA.debugLine="L.Initialize";
_l.Initialize();
 //BA.debugLineNum = 111;BA.debugLine="Dim PS As JavaObject = PA.RunMethod(\"getSupported";
_ps = new anywheresoftware.b4j.object.JavaObject();
_ps = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_pa.RunMethod("getSupportedPaperSources",(Object[])(__c.Null))));
 //BA.debugLineNum = 113;BA.debugLine="Dim Iterator As JavaObject = PS.RunMethod(\"ite";
_iterator = new anywheresoftware.b4j.object.JavaObject();
_iterator = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_ps.RunMethod("iterator",(Object[])(__c.Null))));
 //BA.debugLineNum = 115;BA.debugLine="Do While Iterator.RunMethod(\"hasNext\",Null)";
while (BA.ObjectToBoolean(_iterator.RunMethod("hasNext",(Object[])(__c.Null)))) {
 //BA.debugLineNum = 116;BA.debugLine="L.Add(Iterator.RunMethod(\"next\",Null))";
_l.Add(_iterator.RunMethod("next",(Object[])(__c.Null)));
 }
;
 //BA.debugLineNum = 118;BA.debugLine="Return L";
if (true) return _l;
 //BA.debugLineNum = 119;BA.debugLine="End Sub";
return null;
}
public anywheresoftware.b4a.objects.collections.List  _getsupportedprintcolors() throws Exception{
anywheresoftware.b4a.objects.collections.List _l = null;
anywheresoftware.b4j.object.JavaObject _pc = null;
anywheresoftware.b4j.object.JavaObject _iterator = null;
 //BA.debugLineNum = 121;BA.debugLine="Public Sub GetSupportedPrintColors As List";
 //BA.debugLineNum = 122;BA.debugLine="Dim L As List";
_l = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 123;BA.debugLine="L.Initialize";
_l.Initialize();
 //BA.debugLineNum = 124;BA.debugLine="Dim PC As JavaObject = PA.RunMethod(\"getSupported";
_pc = new anywheresoftware.b4j.object.JavaObject();
_pc = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_pa.RunMethod("getSupportedPrintColors",(Object[])(__c.Null))));
 //BA.debugLineNum = 126;BA.debugLine="Dim Iterator As JavaObject = PC.RunMethod(\"ite";
_iterator = new anywheresoftware.b4j.object.JavaObject();
_iterator = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_pc.RunMethod("iterator",(Object[])(__c.Null))));
 //BA.debugLineNum = 128;BA.debugLine="Do While Iterator.RunMethod(\"hasNext\",Null)";
while (BA.ObjectToBoolean(_iterator.RunMethod("hasNext",(Object[])(__c.Null)))) {
 //BA.debugLineNum = 129;BA.debugLine="L.Add(Iterator.RunMethod(\"next\",Null))";
_l.Add(_iterator.RunMethod("next",(Object[])(__c.Null)));
 }
;
 //BA.debugLineNum = 131;BA.debugLine="Return L";
if (true) return _l;
 //BA.debugLineNum = 132;BA.debugLine="End Sub";
return null;
}
public anywheresoftware.b4a.objects.collections.List  _getsupportedprintquality() throws Exception{
anywheresoftware.b4a.objects.collections.List _l = null;
anywheresoftware.b4j.object.JavaObject _pq = null;
anywheresoftware.b4j.object.JavaObject _iterator = null;
 //BA.debugLineNum = 134;BA.debugLine="Public Sub GetSupportedPrintQuality As List";
 //BA.debugLineNum = 135;BA.debugLine="Dim L As List";
_l = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 136;BA.debugLine="L.Initialize";
_l.Initialize();
 //BA.debugLineNum = 137;BA.debugLine="Dim PQ As JavaObject = PA.RunMethod(\"getSupported";
_pq = new anywheresoftware.b4j.object.JavaObject();
_pq = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_pa.RunMethod("getSupportedPrintQuality",(Object[])(__c.Null))));
 //BA.debugLineNum = 139;BA.debugLine="Dim Iterator As JavaObject = PQ.RunMethod(\"ite";
_iterator = new anywheresoftware.b4j.object.JavaObject();
_iterator = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_pq.RunMethod("iterator",(Object[])(__c.Null))));
 //BA.debugLineNum = 141;BA.debugLine="Do While Iterator.RunMethod(\"hasNext\",Null)";
while (BA.ObjectToBoolean(_iterator.RunMethod("hasNext",(Object[])(__c.Null)))) {
 //BA.debugLineNum = 142;BA.debugLine="L.Add(Iterator.RunMethod(\"next\",Null))";
_l.Add(_iterator.RunMethod("next",(Object[])(__c.Null)));
 }
;
 //BA.debugLineNum = 144;BA.debugLine="Return L";
if (true) return _l;
 //BA.debugLineNum = 145;BA.debugLine="End Sub";
return null;
}
public anywheresoftware.b4a.objects.collections.List  _getsupportedprintresolutions() throws Exception{
anywheresoftware.b4a.objects.collections.List _l = null;
anywheresoftware.b4j.object.JavaObject _pr = null;
anywheresoftware.b4j.object.JavaObject _iterator = null;
 //BA.debugLineNum = 147;BA.debugLine="Public Sub GetSupportedPrintResolutions As List";
 //BA.debugLineNum = 148;BA.debugLine="Dim L As List";
_l = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 149;BA.debugLine="L.Initialize";
_l.Initialize();
 //BA.debugLineNum = 150;BA.debugLine="Dim PR As JavaObject = PA.RunMethod(\"getSupported";
_pr = new anywheresoftware.b4j.object.JavaObject();
_pr = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_pa.RunMethod("getSupportedPrintResolutions",(Object[])(__c.Null))));
 //BA.debugLineNum = 152;BA.debugLine="Dim Iterator As JavaObject = PR.RunMethod(\"ite";
_iterator = new anywheresoftware.b4j.object.JavaObject();
_iterator = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_pr.RunMethod("iterator",(Object[])(__c.Null))));
 //BA.debugLineNum = 154;BA.debugLine="Do While Iterator.RunMethod(\"hasNext\",Null)";
while (BA.ObjectToBoolean(_iterator.RunMethod("hasNext",(Object[])(__c.Null)))) {
 //BA.debugLineNum = 155;BA.debugLine="L.Add(Iterator.RunMethod(\"next\",Null))";
_l.Add(_iterator.RunMethod("next",(Object[])(__c.Null)));
 }
;
 //BA.debugLineNum = 157;BA.debugLine="Return L";
if (true) return _l;
 //BA.debugLineNum = 158;BA.debugLine="End Sub";
return null;
}
public anywheresoftware.b4a.objects.collections.List  _getsupportedprintsides() throws Exception{
anywheresoftware.b4a.objects.collections.List _l = null;
anywheresoftware.b4j.object.JavaObject _ps = null;
anywheresoftware.b4j.object.JavaObject _iterator = null;
 //BA.debugLineNum = 160;BA.debugLine="Public Sub GetSupportedPrintSides As List";
 //BA.debugLineNum = 161;BA.debugLine="Dim L As List";
_l = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 162;BA.debugLine="L.Initialize";
_l.Initialize();
 //BA.debugLineNum = 163;BA.debugLine="Dim PS As JavaObject = PA.RunMethod(\"getSupported";
_ps = new anywheresoftware.b4j.object.JavaObject();
_ps = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_pa.RunMethod("getSupportedPrintSides",(Object[])(__c.Null))));
 //BA.debugLineNum = 165;BA.debugLine="Dim Iterator As JavaObject = PS.RunMethod(\"ite";
_iterator = new anywheresoftware.b4j.object.JavaObject();
_iterator = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_ps.RunMethod("iterator",(Object[])(__c.Null))));
 //BA.debugLineNum = 167;BA.debugLine="Do While Iterator.RunMethod(\"hasNext\",Null)";
while (BA.ObjectToBoolean(_iterator.RunMethod("hasNext",(Object[])(__c.Null)))) {
 //BA.debugLineNum = 168;BA.debugLine="L.Add(Iterator.RunMethod(\"next\",Null))";
_l.Add(_iterator.RunMethod("next",(Object[])(__c.Null)));
 }
;
 //BA.debugLineNum = 170;BA.debugLine="Return L";
if (true) return _l;
 //BA.debugLineNum = 171;BA.debugLine="End Sub";
return null;
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 8;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 10;BA.debugLine="PA.InitializeStatic(\"javafx.print.PrinterAttribut";
_pa.InitializeStatic("javafx.print.PrinterAttributes");
 //BA.debugLineNum = 11;BA.debugLine="End Sub";
return "";
}
public String  _setobject(anywheresoftware.b4j.object.JavaObject _obj) throws Exception{
 //BA.debugLineNum = 179;BA.debugLine="Public Sub SetObject(Obj As JavaObject)";
 //BA.debugLineNum = 180;BA.debugLine="PA = Obj";
_pa = _obj;
 //BA.debugLineNum = 181;BA.debugLine="End Sub";
return "";
}
public boolean  _supportspageranges() throws Exception{
 //BA.debugLineNum = 173;BA.debugLine="Public Sub SupportsPageRanges As Boolean";
 //BA.debugLineNum = 174;BA.debugLine="Return PA.RunMethod(\"supportsPageRanges\",Null)";
if (true) return BA.ObjectToBoolean(_pa.RunMethod("supportsPageRanges",(Object[])(__c.Null)));
 //BA.debugLineNum = 175;BA.debugLine="End Sub";
return false;
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
