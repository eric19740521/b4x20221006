package b4j.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class paper extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.paper", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.example.paper.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4j.object.JavaObject _paperjo = null;
public b4j.example.dateutils _dateutils = null;
public b4j.example.cssutils _cssutils = null;
public b4j.example.main _main = null;
public b4j.example.printerjob_static _printerjob_static = null;
public b4j.example.pageorientation_static _pageorientation_static = null;
public b4j.example.printer_static _printer_static = null;
public b4j.example.paper_static _paper_static = null;
public b4j.example.utils _utils = null;
public b4j.example.adhocwrappers _adhocwrappers = null;
public b4j.example.code39 _code39 = null;
public b4j.example.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 2;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Private PaperJO As JavaObject";
_paperjo = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 6;BA.debugLine="End Sub";
return "";
}
public boolean  _equals(Object _o) throws Exception{
 //BA.debugLineNum = 15;BA.debugLine="Public Sub Equals(O As Object) As Boolean";
 //BA.debugLineNum = 16;BA.debugLine="Return PaperJO.RunMethod(\"equals\",Array As Object";
if (true) return BA.ObjectToBoolean(_paperjo.RunMethod("equals",new Object[]{_o}));
 //BA.debugLineNum = 17;BA.debugLine="End Sub";
return false;
}
public double  _getheight() throws Exception{
 //BA.debugLineNum = 19;BA.debugLine="Public Sub GetHeight As Double";
 //BA.debugLineNum = 20;BA.debugLine="Return PaperJO.RunMethod(\"getHeight\",Null)";
if (true) return (double)(BA.ObjectToNumber(_paperjo.RunMethod("getHeight",(Object[])(__c.Null))));
 //BA.debugLineNum = 21;BA.debugLine="End Sub";
return 0;
}
public String  _getname() throws Exception{
 //BA.debugLineNum = 23;BA.debugLine="Public Sub GetName As String";
 //BA.debugLineNum = 24;BA.debugLine="Return PaperJO.RunMethod(\"getName\",Null)";
if (true) return BA.ObjectToString(_paperjo.RunMethod("getName",(Object[])(__c.Null)));
 //BA.debugLineNum = 25;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4j.object.JavaObject  _getobject() throws Exception{
 //BA.debugLineNum = 34;BA.debugLine="Public Sub GetObject As JavaObject";
 //BA.debugLineNum = 35;BA.debugLine="Return PaperJO";
if (true) return _paperjo;
 //BA.debugLineNum = 36;BA.debugLine="End Sub";
return null;
}
public double  _getwidth() throws Exception{
 //BA.debugLineNum = 27;BA.debugLine="Public Sub GetWidth As Double";
 //BA.debugLineNum = 28;BA.debugLine="Return PaperJO.RunMethod(\"getWidth\",Null)";
if (true) return (double)(BA.ObjectToNumber(_paperjo.RunMethod("getWidth",(Object[])(__c.Null))));
 //BA.debugLineNum = 29;BA.debugLine="End Sub";
return 0;
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 8;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 10;BA.debugLine="PaperJO.InitializeStatic(\"javafx.print.Paper\")";
_paperjo.InitializeStatic("javafx.print.Paper");
 //BA.debugLineNum = 12;BA.debugLine="End Sub";
return "";
}
public String  _setobject(anywheresoftware.b4j.object.JavaObject _obj) throws Exception{
 //BA.debugLineNum = 37;BA.debugLine="Public Sub SetObject (Obj As JavaObject)";
 //BA.debugLineNum = 38;BA.debugLine="PaperJO = Obj";
_paperjo = _obj;
 //BA.debugLineNum = 39;BA.debugLine="End Sub";
return "";
}
public String  _tostring() throws Exception{
 //BA.debugLineNum = 31;BA.debugLine="Public Sub ToString As String";
 //BA.debugLineNum = 32;BA.debugLine="Return PaperJO.RunMethod(\"toString\",Null)";
if (true) return BA.ObjectToString(_paperjo.RunMethod("toString",(Object[])(__c.Null)));
 //BA.debugLineNum = 33;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
