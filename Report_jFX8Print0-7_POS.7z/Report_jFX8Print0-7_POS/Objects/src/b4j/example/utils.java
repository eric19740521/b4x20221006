package b4j.example;


import anywheresoftware.b4a.BA;

public class utils extends Object{
public static utils mostCurrent = new utils();

public static BA ba;
static {
		ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.utils", null);
		ba.loadHtSubs(utils.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.utils", ba);
		}
	}
    public static Class<?> getObject() {
		return utils.class;
	}

 public static anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4j.objects.JFX _fx = null;
public static b4j.example.dateutils _dateutils = null;
public static b4j.example.cssutils _cssutils = null;
public static b4j.example.main _main = null;
public static b4j.example.printerjob_static _printerjob_static = null;
public static b4j.example.pageorientation_static _pageorientation_static = null;
public static b4j.example.printer_static _printer_static = null;
public static b4j.example.paper_static _paper_static = null;
public static b4j.example.adhocwrappers _adhocwrappers = null;
public static b4j.example.code39 _code39 = null;
public static b4j.example.xuiviewsutils _xuiviewsutils = null;
public static anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper  _clonepane(anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper _p) throws Exception{
anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper _newp = null;
anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper _n = null;
anywheresoftware.b4j.objects.LabelWrapper _l = null;
anywheresoftware.b4j.objects.LabelWrapper _newl = null;
anywheresoftware.b4j.objects.ImageViewWrapper _iv = null;
anywheresoftware.b4j.objects.ImageViewWrapper _newiv = null;
 //BA.debugLineNum = 72;BA.debugLine="public Sub ClonePane(P As Pane) As Pane";
 //BA.debugLineNum = 73;BA.debugLine="Dim NewP As Pane";
_newp = new anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper();
 //BA.debugLineNum = 74;BA.debugLine="NewP.Initialize(\"\")";
_newp.Initialize(ba,"");
 //BA.debugLineNum = 75;BA.debugLine="NewP.Style = P.Style";
_newp.setStyle(_p.getStyle());
 //BA.debugLineNum = 76;BA.debugLine="NewP.Style = P.Style";
_newp.setStyle(_p.getStyle());
 //BA.debugLineNum = 77;BA.debugLine="NewP.StyleClasses.AddAll(P.StyleClasses)";
_newp.getStyleClasses().AddAll(_p.getStyleClasses());
 //BA.debugLineNum = 79;BA.debugLine="For Each N As Node In AdHocWrappers.Parent_GetChi";
_n = new anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper();
{
final anywheresoftware.b4a.BA.IterableList group6 = _adhocwrappers._parent_getchildren /*anywheresoftware.b4a.objects.collections.List*/ ((anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_p.getObject())));
final int groupLen6 = group6.getSize()
;int index6 = 0;
;
for (; index6 < groupLen6;index6++){
_n = (anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper(), (javafx.scene.Node)(group6.Get(index6)));
 //BA.debugLineNum = 80;BA.debugLine="If N Is Pane Then";
if (_n.getObjectOrNull() instanceof javafx.scene.layout.Pane) { 
 //BA.debugLineNum = 81;BA.debugLine="NewP.AddNode(ClonePane(N),N.Left,N.Top,N.PrefWi";
_newp.AddNode((javafx.scene.Node)(_clonepane((anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.PaneWrapper.ConcretePaneWrapper(), (javafx.scene.layout.Pane)(_n.getObject()))).getObject()),_n.getLeft(),_n.getTop(),_n.getPrefWidth(),_n.getPrefHeight());
 }else {
 //BA.debugLineNum = 83;BA.debugLine="If N Is Label Then";
if (_n.getObjectOrNull() instanceof javafx.scene.control.Label) { 
 //BA.debugLineNum = 84;BA.debugLine="Dim L As Label = N";
_l = new anywheresoftware.b4j.objects.LabelWrapper();
_l = (anywheresoftware.b4j.objects.LabelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.LabelWrapper(), (javafx.scene.control.Label)(_n.getObject()));
 //BA.debugLineNum = 85;BA.debugLine="Dim NewL As Label";
_newl = new anywheresoftware.b4j.objects.LabelWrapper();
 //BA.debugLineNum = 86;BA.debugLine="NewL.Initialize(\"\")";
_newl.Initialize(ba,"");
 //BA.debugLineNum = 87;BA.debugLine="NewL.Font = L.font";
_newl.setFont(_l.getFont());
 //BA.debugLineNum = 88;BA.debugLine="NewL.Tag = L.Tag";
_newl.setTag(_l.getTag());
 //BA.debugLineNum = 89;BA.debugLine="NewL.Style = L.Style";
_newl.setStyle(_l.getStyle());
 //BA.debugLineNum = 90;BA.debugLine="NewL.StyleClasses.AddAll(L.StyleClasses)";
_newl.getStyleClasses().AddAll(_l.getStyleClasses());
 //BA.debugLineNum = 91;BA.debugLine="NewL.Alignment = L.Alignment";
_newl.setAlignment(_l.getAlignment());
 //BA.debugLineNum = 92;BA.debugLine="NewL.TextColor = L.TextColor";
_newl.setTextColor(_l.getTextColor());
 //BA.debugLineNum = 93;BA.debugLine="NewL.TextSize = L.TextSize";
_newl.setTextSize(_l.getTextSize());
 //BA.debugLineNum = 94;BA.debugLine="NewL.WrapText = L.WrapText";
_newl.setWrapText(_l.getWrapText());
 //BA.debugLineNum = 95;BA.debugLine="NewL.Text = L.Text";
_newl.setText(_l.getText());
 //BA.debugLineNum = 96;BA.debugLine="NewL.Tag = L.Tag";
_newl.setTag(_l.getTag());
 //BA.debugLineNum = 97;BA.debugLine="NewP.AddNode(NewL,L.Left,L.Top,L.PrefWidth,L.P";
_newp.AddNode((javafx.scene.Node)(_newl.getObject()),_l.getLeft(),_l.getTop(),_l.getPrefWidth(),_l.getPrefHeight());
 }else {
 //BA.debugLineNum = 99;BA.debugLine="If N Is ImageView Then";
if (_n.getObjectOrNull() instanceof javafx.scene.image.ImageView) { 
 //BA.debugLineNum = 100;BA.debugLine="Dim IV As ImageView = N";
_iv = new anywheresoftware.b4j.objects.ImageViewWrapper();
_iv = (anywheresoftware.b4j.objects.ImageViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.ImageViewWrapper(), (javafx.scene.image.ImageView)(_n.getObject()));
 //BA.debugLineNum = 101;BA.debugLine="Dim NewIV As ImageView";
_newiv = new anywheresoftware.b4j.objects.ImageViewWrapper();
 //BA.debugLineNum = 102;BA.debugLine="NewIV.Initialize(\"\")";
_newiv.Initialize(ba,"");
 //BA.debugLineNum = 103;BA.debugLine="NewIV.PreserveRatio = IV.PreserveRatio";
_newiv.setPreserveRatio(_iv.getPreserveRatio());
 //BA.debugLineNum = 104;BA.debugLine="NewIV.SetImage(IV.GetImage)";
_newiv.SetImage((javafx.scene.image.Image)(_iv.GetImage().getObject()));
 //BA.debugLineNum = 105;BA.debugLine="NewIV.Alpha = IV.Alpha";
_newiv.setAlpha(_iv.getAlpha());
 //BA.debugLineNum = 106;BA.debugLine="NewIV.Style = IV.Style";
_newiv.setStyle(_iv.getStyle());
 //BA.debugLineNum = 107;BA.debugLine="NewIV.StyleClasses.AddAll(IV.StyleClasses)";
_newiv.getStyleClasses().AddAll(_iv.getStyleClasses());
 //BA.debugLineNum = 108;BA.debugLine="NewP.AddNode(NewIV,IV.Left,IV.Top,IV.PrefWidt";
_newp.AddNode((javafx.scene.Node)(_newiv.getObject()),_iv.getLeft(),_iv.getTop(),_iv.getPrefWidth(),_iv.getPrefHeight());
 };
 };
 };
 }
};
 //BA.debugLineNum = 113;BA.debugLine="Return NewP";
if (true) return _newp;
 //BA.debugLineNum = 114;BA.debugLine="End Sub";
return null;
}
public static b4j.example.paper  _createpaper(String _name,double _width,double _height) throws Exception{
anywheresoftware.b4j.object.JavaObject _tunits = null;
anywheresoftware.b4j.object.JavaObject _printh = null;
b4j.example.paper _p = null;
 //BA.debugLineNum = 121;BA.debugLine="Public Sub CreatePaper(Name As String, Width As Do";
 //BA.debugLineNum = 122;BA.debugLine="Dim tUnits As JavaObject";
_tunits = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 123;BA.debugLine="tUnits.InitializeStatic(\"com.sun.javafx.print.Uni";
_tunits.InitializeStatic("com.sun.javafx.print.Units");
 //BA.debugLineNum = 124;BA.debugLine="Dim PrintH As JavaObject";
_printh = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 125;BA.debugLine="PrintH.InitializeStatic(\"com.sun.javafx.print.Pri";
_printh.InitializeStatic("com.sun.javafx.print.PrintHelper");
 //BA.debugLineNum = 126;BA.debugLine="Dim P As Paper";
_p = new b4j.example.paper();
 //BA.debugLineNum = 127;BA.debugLine="P.Initialize";
_p._initialize /*String*/ (ba);
 //BA.debugLineNum = 131;BA.debugLine="P.SetObject(PrintH.RunMethod(\"createPaper\",Array(";
_p._setobject /*String*/ ((anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_printh.RunMethod("createPaper",new Object[]{(Object)(_name),(Object)(_width),(Object)(_height),_tunits.GetField("MM")}))));
 //BA.debugLineNum = 142;BA.debugLine="Return P";
if (true) return _p;
 //BA.debugLineNum = 143;BA.debugLine="End Sub";
return null;
}
public static b4j.example.printer  _getprinter(String _name) throws Exception{
anywheresoftware.b4a.objects.collections.List _printers = null;
b4j.example.printer _p = null;
 //BA.debugLineNum = 147;BA.debugLine="public Sub GetPrinter(Name As String) As Printer";
 //BA.debugLineNum = 148;BA.debugLine="Dim Printers As List = Printer_Static.GetAllPrint";
_printers = new anywheresoftware.b4a.objects.collections.List();
_printers = _printer_static._getallprinters /*anywheresoftware.b4a.objects.collections.List*/ ();
 //BA.debugLineNum = 149;BA.debugLine="For Each P As Printer In Printers";
{
final anywheresoftware.b4a.BA.IterableList group2 = _printers;
final int groupLen2 = group2.getSize()
;int index2 = 0;
;
for (; index2 < groupLen2;index2++){
_p = (b4j.example.printer)(group2.Get(index2));
 //BA.debugLineNum = 150;BA.debugLine="If P.GetName.StartsWith(Name) Then Return P";
if (_p._getname /*String*/ ().startsWith(_name)) { 
if (true) return _p;};
 }
};
 //BA.debugLineNum = 152;BA.debugLine="Return Null";
if (true) return (b4j.example.printer)(anywheresoftware.b4a.keywords.Common.Null);
 //BA.debugLineNum = 153;BA.debugLine="End Sub";
return null;
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 2;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 3;BA.debugLine="Private fx As JFX";
_fx = new anywheresoftware.b4j.objects.JFX();
 //BA.debugLineNum = 4;BA.debugLine="End Sub";
return "";
}
public static String  _scalen(anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper _n,double _dd) throws Exception{
anywheresoftware.b4j.object.JavaObject _njo = null;
double _scalex = 0;
double _scaley = 0;
anywheresoftware.b4j.object.JavaObject _sjo = null;
 //BA.debugLineNum = 157;BA.debugLine="Sub ScaleN(N As Node,dd As Double)";
 //BA.debugLineNum = 158;BA.debugLine="Log(\"ScaleDD= \"&dd)";
anywheresoftware.b4a.keywords.Common.LogImpl("67143425","ScaleDD= "+BA.NumberToString(_dd),0);
 //BA.debugLineNum = 161;BA.debugLine="Dim NJO As JavaObject = N";
_njo = new anywheresoftware.b4j.object.JavaObject();
_njo = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_n.getObject()));
 //BA.debugLineNum = 163;BA.debugLine="Dim ScaleX,ScaleY As Double";
_scalex = 0;
_scaley = 0;
 //BA.debugLineNum = 165;BA.debugLine="ScaleX=dd";
_scalex = _dd;
 //BA.debugLineNum = 166;BA.debugLine="ScaleY=dd";
_scaley = _dd;
 //BA.debugLineNum = 169;BA.debugLine="Dim SJO As JavaObject";
_sjo = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 170;BA.debugLine="SJO.InitializeNewInstance(\"javafx.scene.transform";
_sjo.InitializeNewInstance("javafx.scene.transform.Scale",new Object[]{(Object)(_scalex),(Object)(_scaley)});
 //BA.debugLineNum = 171;BA.debugLine="NJO.RunMethodJO(\"getTransforms\",Null).RunMethod(\"";
_njo.RunMethodJO("getTransforms",(Object[])(anywheresoftware.b4a.keywords.Common.Null)).RunMethod("add",new Object[]{(Object)(_sjo.getObject())});
 //BA.debugLineNum = 172;BA.debugLine="End Sub";
return "";
}
public static anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper  _scaleoutput(b4j.example.printer _p,anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper _n) throws Exception{
b4j.example.pagelayout _pl = null;
double _scalex = 0;
double _scaley = 0;
anywheresoftware.b4j.object.JavaObject _njo = null;
anywheresoftware.b4j.object.JavaObject _jo = null;
anywheresoftware.b4j.object.JavaObject _sjo = null;
 //BA.debugLineNum = 6;BA.debugLine="Sub ScaleOutput(P As Printer,N As Node) As Node 'I";
 //BA.debugLineNum = 7;BA.debugLine="Dim PL As PageLayout = P.GetDefaultPageLayout";
_pl = _p._getdefaultpagelayout /*b4j.example.pagelayout*/ ();
 //BA.debugLineNum = 8;BA.debugLine="Dim ScaleX,ScaleY As Double";
_scalex = 0;
_scaley = 0;
 //BA.debugLineNum = 9;BA.debugLine="Dim NJO As JavaObject = N";
_njo = new anywheresoftware.b4j.object.JavaObject();
_njo = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_n.getObject()));
 //BA.debugLineNum = 10;BA.debugLine="Dim JO As JavaObject = N";
_jo = new anywheresoftware.b4j.object.JavaObject();
_jo = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_n.getObject()));
 //BA.debugLineNum = 11;BA.debugLine="ScaleX = PL.GetPrintableWidth / JO.RunMethodJO(\"g";
_scalex = _pl._getprintablewidth /*double*/ ()/(double)(double)(BA.ObjectToNumber(_jo.RunMethodJO("getBoundsInParent",(Object[])(anywheresoftware.b4a.keywords.Common.Null)).RunMethod("getWidth",(Object[])(anywheresoftware.b4a.keywords.Common.Null))));
 //BA.debugLineNum = 12;BA.debugLine="ScaleY = PL.GetPrintableHeight / JO.RunMethodJO(\"";
_scaley = _pl._getprintableheight /*double*/ ()/(double)(double)(BA.ObjectToNumber(_jo.RunMethodJO("getBoundsInParent",(Object[])(anywheresoftware.b4a.keywords.Common.Null)).RunMethod("getHeight",(Object[])(anywheresoftware.b4a.keywords.Common.Null))));
 //BA.debugLineNum = 13;BA.debugLine="Dim SJO As JavaObject";
_sjo = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 14;BA.debugLine="SJO.InitializeNewInstance(\"javafx.scene.transform";
_sjo.InitializeNewInstance("javafx.scene.transform.Scale",new Object[]{(Object)(_scalex),(Object)(_scaley)});
 //BA.debugLineNum = 15;BA.debugLine="NJO.RunMethodJO(\"getTransforms\",Null).RunMethod(\"";
_njo.RunMethodJO("getTransforms",(Object[])(anywheresoftware.b4a.keywords.Common.Null)).RunMethod("add",new Object[]{(Object)(_sjo.getObject())});
 //BA.debugLineNum = 16;BA.debugLine="Return NJO";
if (true) return (anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper(), (javafx.scene.Node)(_njo.getObject()));
 //BA.debugLineNum = 17;BA.debugLine="End Sub";
return null;
}
public static anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper  _scaleoutput2(b4j.example.printer _p,anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper _n,double _zoomfactor) throws Exception{
b4j.example.pagelayout _pl = null;
double _scalex = 0;
double _scaley = 0;
anywheresoftware.b4j.object.JavaObject _njo = null;
anywheresoftware.b4j.object.JavaObject _jo = null;
anywheresoftware.b4j.object.JavaObject _sjo = null;
 //BA.debugLineNum = 20;BA.debugLine="Sub ScaleOutput2(P As Printer, N As Node, ZoomFact";
 //BA.debugLineNum = 21;BA.debugLine="Log(\"ScaleOutput2==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("66815745","ScaleOutput2==>",0);
 //BA.debugLineNum = 23;BA.debugLine="Dim PL As PageLayout = P.GetDefaultPageLayout";
_pl = _p._getdefaultpagelayout /*b4j.example.pagelayout*/ ();
 //BA.debugLineNum = 24;BA.debugLine="Dim ScaleX,ScaleY As Double";
_scalex = 0;
_scaley = 0;
 //BA.debugLineNum = 25;BA.debugLine="Dim NJO As JavaObject = N";
_njo = new anywheresoftware.b4j.object.JavaObject();
_njo = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_n.getObject()));
 //BA.debugLineNum = 26;BA.debugLine="Dim JO As JavaObject = N";
_jo = new anywheresoftware.b4j.object.JavaObject();
_jo = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_n.getObject()));
 //BA.debugLineNum = 27;BA.debugLine="ScaleX = ZoomFactor * PL.GetPrintableWidth / JO.R";
_scalex = _zoomfactor*_pl._getprintablewidth /*double*/ ()/(double)(double)(BA.ObjectToNumber(_jo.RunMethodJO("getBoundsInParent",(Object[])(anywheresoftware.b4a.keywords.Common.Null)).RunMethod("getWidth",(Object[])(anywheresoftware.b4a.keywords.Common.Null))));
 //BA.debugLineNum = 28;BA.debugLine="ScaleY = ZoomFactor * PL.GetPrintableHeight / JO.";
_scaley = _zoomfactor*_pl._getprintableheight /*double*/ ()/(double)(double)(BA.ObjectToNumber(_jo.RunMethodJO("getBoundsInParent",(Object[])(anywheresoftware.b4a.keywords.Common.Null)).RunMethod("getHeight",(Object[])(anywheresoftware.b4a.keywords.Common.Null))));
 //BA.debugLineNum = 30;BA.debugLine="Log(\"PL.GetPrintableHeight: \"&PL.GetPrintableHeig";
anywheresoftware.b4a.keywords.Common.LogImpl("66815754","PL.GetPrintableHeight: "+BA.NumberToString(_pl._getprintableheight /*double*/ ()),0);
 //BA.debugLineNum = 31;BA.debugLine="Log(\"ScaleX: \"&ScaleX)";
anywheresoftware.b4a.keywords.Common.LogImpl("66815755","ScaleX: "+BA.NumberToString(_scalex),0);
 //BA.debugLineNum = 32;BA.debugLine="Log(\"ScaleY: \"&ScaleY)";
anywheresoftware.b4a.keywords.Common.LogImpl("66815756","ScaleY: "+BA.NumberToString(_scaley),0);
 //BA.debugLineNum = 34;BA.debugLine="Dim SJO As JavaObject";
_sjo = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 35;BA.debugLine="SJO.InitializeNewInstance(\"javafx.scene.transform";
_sjo.InitializeNewInstance("javafx.scene.transform.Scale",new Object[]{(Object)(_scalex),(Object)(_scaley)});
 //BA.debugLineNum = 36;BA.debugLine="NJO.RunMethodJO(\"getTransforms\",Null).RunMethod(\"";
_njo.RunMethodJO("getTransforms",(Object[])(anywheresoftware.b4a.keywords.Common.Null)).RunMethod("add",new Object[]{(Object)(_sjo.getObject())});
 //BA.debugLineNum = 37;BA.debugLine="Return NJO";
if (true) return (anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper(), (javafx.scene.Node)(_njo.getObject()));
 //BA.debugLineNum = 38;BA.debugLine="End Sub";
return null;
}
public static anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper  _scaleoutput3(b4j.example.pagelayout _pl,anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper _n,double _zoomfactor) throws Exception{
double _scalex = 0;
double _scaley = 0;
anywheresoftware.b4j.object.JavaObject _njo = null;
anywheresoftware.b4j.object.JavaObject _jo = null;
anywheresoftware.b4j.object.JavaObject _sjo = null;
 //BA.debugLineNum = 42;BA.debugLine="Sub ScaleOutput3(PL As PageLayout, N As Node, Zoom";
 //BA.debugLineNum = 43;BA.debugLine="Log(\"ScaleOutput2==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("66881281","ScaleOutput2==>",0);
 //BA.debugLineNum = 46;BA.debugLine="Dim ScaleX,ScaleY As Double";
_scalex = 0;
_scaley = 0;
 //BA.debugLineNum = 47;BA.debugLine="Dim NJO As JavaObject = N";
_njo = new anywheresoftware.b4j.object.JavaObject();
_njo = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_n.getObject()));
 //BA.debugLineNum = 48;BA.debugLine="Dim JO As JavaObject = N";
_jo = new anywheresoftware.b4j.object.JavaObject();
_jo = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_n.getObject()));
 //BA.debugLineNum = 49;BA.debugLine="ScaleX = ZoomFactor * PL.GetPrintableWidth / JO.R";
_scalex = _zoomfactor*_pl._getprintablewidth /*double*/ ()/(double)(double)(BA.ObjectToNumber(_jo.RunMethodJO("getBoundsInParent",(Object[])(anywheresoftware.b4a.keywords.Common.Null)).RunMethod("getWidth",(Object[])(anywheresoftware.b4a.keywords.Common.Null))));
 //BA.debugLineNum = 50;BA.debugLine="ScaleY = ZoomFactor * PL.GetPrintableHeight / JO.";
_scaley = _zoomfactor*_pl._getprintableheight /*double*/ ()/(double)(double)(BA.ObjectToNumber(_jo.RunMethodJO("getBoundsInParent",(Object[])(anywheresoftware.b4a.keywords.Common.Null)).RunMethod("getHeight",(Object[])(anywheresoftware.b4a.keywords.Common.Null))));
 //BA.debugLineNum = 58;BA.debugLine="Log(\"Node.Width: \"&JO.RunMethodJO(\"getBoundsInPar";
anywheresoftware.b4a.keywords.Common.LogImpl("66881296","Node.Width: "+BA.ObjectToString(_jo.RunMethodJO("getBoundsInParent",(Object[])(anywheresoftware.b4a.keywords.Common.Null)).RunMethod("getWidth",(Object[])(anywheresoftware.b4a.keywords.Common.Null))),0);
 //BA.debugLineNum = 59;BA.debugLine="Log(\"Node.Height: \"&JO.RunMethodJO(\"getBoundsInPa";
anywheresoftware.b4a.keywords.Common.LogImpl("66881297","Node.Height: "+BA.ObjectToString(_jo.RunMethodJO("getBoundsInParent",(Object[])(anywheresoftware.b4a.keywords.Common.Null)).RunMethod("getHeight",(Object[])(anywheresoftware.b4a.keywords.Common.Null))),0);
 //BA.debugLineNum = 60;BA.debugLine="Log(\"PL.GetPrintableWidth: \"&PL.GetPrintableWidth";
anywheresoftware.b4a.keywords.Common.LogImpl("66881298","PL.GetPrintableWidth: "+BA.NumberToString(_pl._getprintablewidth /*double*/ ()),0);
 //BA.debugLineNum = 61;BA.debugLine="Log(\"PL.GetPrintableHeight: \"&PL.GetPrintableHeig";
anywheresoftware.b4a.keywords.Common.LogImpl("66881299","PL.GetPrintableHeight: "+BA.NumberToString(_pl._getprintableheight /*double*/ ()),0);
 //BA.debugLineNum = 62;BA.debugLine="Log(\"ScaleX: \"&ScaleX)";
anywheresoftware.b4a.keywords.Common.LogImpl("66881300","ScaleX: "+BA.NumberToString(_scalex),0);
 //BA.debugLineNum = 63;BA.debugLine="Log(\"ScaleY: \"&ScaleY)";
anywheresoftware.b4a.keywords.Common.LogImpl("66881301","ScaleY: "+BA.NumberToString(_scaley),0);
 //BA.debugLineNum = 65;BA.debugLine="Dim SJO As JavaObject";
_sjo = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 66;BA.debugLine="SJO.InitializeNewInstance(\"javafx.scene.transform";
_sjo.InitializeNewInstance("javafx.scene.transform.Scale",new Object[]{(Object)(_scalex),(Object)(_scaley)});
 //BA.debugLineNum = 67;BA.debugLine="NJO.RunMethodJO(\"getTransforms\",Null).RunMethod(\"";
_njo.RunMethodJO("getTransforms",(Object[])(anywheresoftware.b4a.keywords.Common.Null)).RunMethod("add",new Object[]{(Object)(_sjo.getObject())});
 //BA.debugLineNum = 68;BA.debugLine="Return NJO";
if (true) return (anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper(), (javafx.scene.Node)(_njo.getObject()));
 //BA.debugLineNum = 69;BA.debugLine="End Sub";
return null;
}
}
