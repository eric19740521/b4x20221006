package b4j.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class enumclass extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.enumclass", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.example.enumclass.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4j.object.JavaObject _enumjo = null;
public b4j.example.dateutils _dateutils = null;
public b4j.example.cssutils _cssutils = null;
public b4j.example.main _main = null;
public b4j.example.printerjob_static _printerjob_static = null;
public b4j.example.pageorientation_static _pageorientation_static = null;
public b4j.example.printer_static _printer_static = null;
public b4j.example.paper_static _paper_static = null;
public b4j.example.utils _utils = null;
public b4j.example.adhocwrappers _adhocwrappers = null;
public b4j.example.code39 _code39 = null;
public b4j.example.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 2;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 3;BA.debugLine="Private EnumJO As JavaObject";
_enumjo = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 4;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,String _classname) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 7;BA.debugLine="Public Sub Initialize(ClassName As String)";
 //BA.debugLineNum = 8;BA.debugLine="EnumJO.InitializeStatic(ClassName)";
_enumjo.InitializeStatic(_classname);
 //BA.debugLineNum = 9;BA.debugLine="End Sub";
return "";
}
public Object  _valueof(String _text) throws Exception{
 //BA.debugLineNum = 11;BA.debugLine="Sub ValueOf(Text As String) As Object 'Ignore";
 //BA.debugLineNum = 12;BA.debugLine="Return EnumJO.RunMethod(\"valueOf\",Array(Text))";
if (true) return _enumjo.RunMethod("valueOf",new Object[]{(Object)(_text)});
 //BA.debugLineNum = 13;BA.debugLine="End Sub";
return null;
}
public Object[]  _values() throws Exception{
 //BA.debugLineNum = 15;BA.debugLine="Sub Values As Object()";
 //BA.debugLineNum = 16;BA.debugLine="Return EnumJO.RunMethod(\"values\",Null)";
if (true) return (Object[])(_enumjo.RunMethod("values",(Object[])(__c.Null)));
 //BA.debugLineNum = 17;BA.debugLine="End Sub";
return null;
}
public String[]  _valuestrings() throws Exception{
Object[] _valueobjects = null;
anywheresoftware.b4j.object.JavaObject _jo = null;
String[] _returnstrings = null;
int _i = 0;
 //BA.debugLineNum = 19;BA.debugLine="Sub ValueStrings As String() 'Ignore";
 //BA.debugLineNum = 20;BA.debugLine="Dim ValueObjects() As Object = Values";
_valueobjects = _values();
 //BA.debugLineNum = 21;BA.debugLine="Dim JO As JavaObject";
_jo = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 22;BA.debugLine="Dim ReturnStrings(ValueObjects.Length) As String";
_returnstrings = new String[_valueobjects.length];
java.util.Arrays.fill(_returnstrings,"");
 //BA.debugLineNum = 23;BA.debugLine="For i = 0 To ValueObjects.Length - 1";
{
final int step4 = 1;
final int limit4 = (int) (_valueobjects.length-1);
_i = (int) (0) ;
for (;_i <= limit4 ;_i = _i + step4 ) {
 //BA.debugLineNum = 24;BA.debugLine="JO = ValueObjects(i)";
_jo = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_valueobjects[_i]));
 //BA.debugLineNum = 25;BA.debugLine="ReturnStrings(i) = JO.RunMethod(\"toString\",Null)";
_returnstrings[_i] = BA.ObjectToString(_jo.RunMethod("toString",(Object[])(__c.Null)));
 }
};
 //BA.debugLineNum = 27;BA.debugLine="Return ReturnStrings";
if (true) return _returnstrings;
 //BA.debugLineNum = 28;BA.debugLine="End Sub";
return null;
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
