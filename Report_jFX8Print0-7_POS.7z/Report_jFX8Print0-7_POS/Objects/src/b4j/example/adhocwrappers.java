package b4j.example;


import anywheresoftware.b4a.BA;

public class adhocwrappers extends Object{
public static adhocwrappers mostCurrent = new adhocwrappers();

public static BA ba;
static {
		ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.adhocwrappers", null);
		ba.loadHtSubs(adhocwrappers.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.adhocwrappers", ba);
		}
	}
    public static Class<?> getObject() {
		return adhocwrappers.class;
	}

 public static anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4j.objects.JFX _fx = null;
public static b4j.example.dateutils _dateutils = null;
public static b4j.example.cssutils _cssutils = null;
public static b4j.example.main _main = null;
public static b4j.example.printerjob_static _printerjob_static = null;
public static b4j.example.pageorientation_static _pageorientation_static = null;
public static b4j.example.printer_static _printer_static = null;
public static b4j.example.paper_static _paper_static = null;
public static b4j.example.utils _utils = null;
public static b4j.example.code39 _code39 = null;
public static b4j.example.xuiviewsutils _xuiviewsutils = null;
public static anywheresoftware.b4j.object.JavaObject  _parent_getchildat(anywheresoftware.b4j.object.JavaObject _parent,int _index) throws Exception{
anywheresoftware.b4a.objects.collections.List _l = null;
 //BA.debugLineNum = 12;BA.debugLine="Public Sub Parent_GetChildAt(Parent As JavaObject,";
 //BA.debugLineNum = 13;BA.debugLine="Dim L As List = Parent_GetChildren(Parent)";
_l = new anywheresoftware.b4a.objects.collections.List();
_l = _parent_getchildren(_parent);
 //BA.debugLineNum = 14;BA.debugLine="Return L.Get(Index)";
if (true) return (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_l.Get(_index)));
 //BA.debugLineNum = 15;BA.debugLine="End Sub";
return null;
}
public static anywheresoftware.b4a.objects.collections.List  _parent_getchildren(anywheresoftware.b4j.object.JavaObject _parent) throws Exception{
 //BA.debugLineNum = 8;BA.debugLine="Public Sub Parent_GetChildren(Parent As JavaObject";
 //BA.debugLineNum = 9;BA.debugLine="Return Parent.RunMethod(\"getChildrenUnmodifiable\"";
if (true) return (anywheresoftware.b4a.objects.collections.List) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.List(), (java.util.List)(_parent.RunMethod("getChildrenUnmodifiable",(Object[])(anywheresoftware.b4a.keywords.Common.Null))));
 //BA.debugLineNum = 10;BA.debugLine="End Sub";
return null;
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 2;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 3;BA.debugLine="Private fx As JFX";
_fx = new anywheresoftware.b4j.objects.JFX();
 //BA.debugLineNum = 4;BA.debugLine="End Sub";
return "";
}
}
