package b4j.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class printer extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.printer", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.example.printer.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4j.object.JavaObject _printr = null;
public b4j.example.dateutils _dateutils = null;
public b4j.example.cssutils _cssutils = null;
public b4j.example.main _main = null;
public b4j.example.printerjob_static _printerjob_static = null;
public b4j.example.pageorientation_static _pageorientation_static = null;
public b4j.example.printer_static _printer_static = null;
public b4j.example.paper_static _paper_static = null;
public b4j.example.utils _utils = null;
public b4j.example.adhocwrappers _adhocwrappers = null;
public b4j.example.code39 _code39 = null;
public b4j.example.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 2;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Private Printr As JavaObject";
_printr = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 6;BA.debugLine="End Sub";
return "";
}
public b4j.example.pagelayout  _createpagelayout(b4j.example.paper _tpaper,String _orient,double _lmargin,double _rmargin,double _tmargin,double _bmargin) throws Exception{
b4j.example.pagelayout _pl = null;
 //BA.debugLineNum = 19;BA.debugLine="Public Sub CreatePageLayout(TPaper As Paper, Orien";
 //BA.debugLineNum = 20;BA.debugLine="Dim PL As PageLayout";
_pl = new b4j.example.pagelayout();
 //BA.debugLineNum = 21;BA.debugLine="PL.Initialize";
_pl._initialize /*String*/ (ba);
 //BA.debugLineNum = 22;BA.debugLine="PL.SetObject(Printr.RunMethod(\"createPageLayout\",";
_pl._setobject /*String*/ ((anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_printr.RunMethod("createPageLayout",new Object[]{(Object)(_tpaper._getobject /*anywheresoftware.b4j.object.JavaObject*/ ().getObject()),(Object)(_orient),(Object)(_lmargin),(Object)(_rmargin),(Object)(_tmargin),(Object)(_bmargin)}))));
 //BA.debugLineNum = 23;BA.debugLine="Return PL";
if (true) return _pl;
 //BA.debugLineNum = 24;BA.debugLine="End Sub";
return null;
}
public b4j.example.pagelayout  _createpagelayout2(b4j.example.paper _tpaper,String _orient,String _margin_type) throws Exception{
b4j.example.pagelayout _pl = null;
 //BA.debugLineNum = 29;BA.debugLine="Public Sub CreatePageLayout2(TPaper As Paper, Orie";
 //BA.debugLineNum = 30;BA.debugLine="Dim PL As PageLayout";
_pl = new b4j.example.pagelayout();
 //BA.debugLineNum = 31;BA.debugLine="PL.Initialize";
_pl._initialize /*String*/ (ba);
 //BA.debugLineNum = 32;BA.debugLine="PL.SetObject(Printr.RunMethod(\"createPageLayout\",";
_pl._setobject /*String*/ ((anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_printr.RunMethod("createPageLayout",new Object[]{(Object)(_tpaper._getobject /*anywheresoftware.b4j.object.JavaObject*/ ().getObject()),(Object)(_orient),(Object)(_margin_type)}))));
 //BA.debugLineNum = 33;BA.debugLine="Return PL";
if (true) return _pl;
 //BA.debugLineNum = 34;BA.debugLine="End Sub";
return null;
}
public b4j.example.pagelayout  _getdefaultpagelayout() throws Exception{
b4j.example.pagelayout _pl = null;
 //BA.debugLineNum = 37;BA.debugLine="Public Sub GetDefaultPageLayout As PageLayout";
 //BA.debugLineNum = 38;BA.debugLine="Dim PL As PageLayout";
_pl = new b4j.example.pagelayout();
 //BA.debugLineNum = 39;BA.debugLine="PL.Initialize";
_pl._initialize /*String*/ (ba);
 //BA.debugLineNum = 40;BA.debugLine="PL.SetObject(Printr.RunMethod(\"getDefaultPageLayo";
_pl._setobject /*String*/ ((anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_printr.RunMethod("getDefaultPageLayout",(Object[])(__c.Null)))));
 //BA.debugLineNum = 41;BA.debugLine="Return PL";
if (true) return _pl;
 //BA.debugLineNum = 42;BA.debugLine="End Sub";
return null;
}
public String  _getname() throws Exception{
 //BA.debugLineNum = 45;BA.debugLine="Public Sub GetName As String";
 //BA.debugLineNum = 46;BA.debugLine="Return Printr.RunMethod(\"getName\",Null)";
if (true) return BA.ObjectToString(_printr.RunMethod("getName",(Object[])(__c.Null)));
 //BA.debugLineNum = 47;BA.debugLine="End Sub";
return "";
}
public Object  _getobject() throws Exception{
 //BA.debugLineNum = 59;BA.debugLine="Public Sub GetObject As Object";
 //BA.debugLineNum = 60;BA.debugLine="Return Printr";
if (true) return (Object)(_printr.getObject());
 //BA.debugLineNum = 61;BA.debugLine="End Sub";
return null;
}
public b4j.example.printerattributes  _getprinterattributes() throws Exception{
b4j.example.printerattributes _pa = null;
 //BA.debugLineNum = 49;BA.debugLine="Public Sub GetPrinterAttributes As PrinterAttribut";
 //BA.debugLineNum = 50;BA.debugLine="Dim PA As PrinterAttributes";
_pa = new b4j.example.printerattributes();
 //BA.debugLineNum = 51;BA.debugLine="PA.Initialize";
_pa._initialize /*String*/ (ba);
 //BA.debugLineNum = 52;BA.debugLine="PA.SetObject(Printr.RunMethod(\"getPrinterAttribut";
_pa._setobject /*String*/ ((anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_printr.RunMethod("getPrinterAttributes",(Object[])(__c.Null)))));
 //BA.debugLineNum = 53;BA.debugLine="Return PA";
if (true) return _pa;
 //BA.debugLineNum = 54;BA.debugLine="End Sub";
return null;
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 8;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 10;BA.debugLine="Printr.InitializeStatic(\"javafx.print.Printer\")";
_printr.InitializeStatic("javafx.print.Printer");
 //BA.debugLineNum = 11;BA.debugLine="If Not(Paper_static.IsInitialized) Then Paper_sta";
if (__c.Not(_paper_static._isinitialized /*boolean*/ ())) { 
_paper_static._initialize /*String*/ ();};
 //BA.debugLineNum = 12;BA.debugLine="End Sub";
return "";
}
public String  _setobject(Object _p) throws Exception{
 //BA.debugLineNum = 62;BA.debugLine="Public Sub SetObject (P As Object)";
 //BA.debugLineNum = 63;BA.debugLine="Printr = P";
_printr = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_p));
 //BA.debugLineNum = 64;BA.debugLine="End Sub";
return "";
}
public String  _tostring() throws Exception{
 //BA.debugLineNum = 56;BA.debugLine="Public Sub ToString As String";
 //BA.debugLineNum = 57;BA.debugLine="Return Printr.RunMethod(\"toString\",Null)";
if (true) return BA.ObjectToString(_printr.RunMethod("toString",(Object[])(__c.Null)));
 //BA.debugLineNum = 58;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
