package b4j.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class printerjob extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.printerjob", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.example.printerjob.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4j.object.JavaObject _pj = null;
public b4j.example.dateutils _dateutils = null;
public b4j.example.cssutils _cssutils = null;
public b4j.example.main _main = null;
public b4j.example.printerjob_static _printerjob_static = null;
public b4j.example.pageorientation_static _pageorientation_static = null;
public b4j.example.printer_static _printer_static = null;
public b4j.example.paper_static _paper_static = null;
public b4j.example.utils _utils = null;
public b4j.example.adhocwrappers _adhocwrappers = null;
public b4j.example.code39 _code39 = null;
public b4j.example.xuiviewsutils _xuiviewsutils = null;
public String  _canceljob() throws Exception{
 //BA.debugLineNum = 15;BA.debugLine="Public Sub CancelJob";
 //BA.debugLineNum = 16;BA.debugLine="PJ.RunMethod(\"cancelJob\",Null)";
_pj.RunMethod("cancelJob",(Object[])(__c.Null));
 //BA.debugLineNum = 17;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 4;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 6;BA.debugLine="Private PJ As JavaObject";
_pj = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 8;BA.debugLine="End Sub";
return "";
}
public boolean  _endjob() throws Exception{
 //BA.debugLineNum = 19;BA.debugLine="Public Sub EndJob As Boolean";
 //BA.debugLineNum = 20;BA.debugLine="Return PJ.RunMethod(\"endJob\",Null)";
if (true) return BA.ObjectToBoolean(_pj.RunMethod("endJob",(Object[])(__c.Null)));
 //BA.debugLineNum = 21;BA.debugLine="End Sub";
return false;
}
public b4j.example.jobsettings  _getjobsettings() throws Exception{
b4j.example.jobsettings _js = null;
 //BA.debugLineNum = 23;BA.debugLine="Public Sub GetJobSettings As JobSettings";
 //BA.debugLineNum = 24;BA.debugLine="Dim JS As JobSettings";
_js = new b4j.example.jobsettings();
 //BA.debugLineNum = 25;BA.debugLine="JS.Initialize";
_js._initialize /*String*/ (ba);
 //BA.debugLineNum = 26;BA.debugLine="JS.SetObject(PJ.RunMethod(\"getJobSettings\",Null))";
_js._setobject /*String*/ (_pj.RunMethod("getJobSettings",(Object[])(__c.Null)));
 //BA.debugLineNum = 27;BA.debugLine="Return JS";
if (true) return _js;
 //BA.debugLineNum = 28;BA.debugLine="End Sub";
return null;
}
public String  _getjobstatus() throws Exception{
 //BA.debugLineNum = 31;BA.debugLine="Public Sub GetJobStatus As String";
 //BA.debugLineNum = 32;BA.debugLine="Return PJ.RunMethod(\"getJobStatus\",Null)";
if (true) return BA.ObjectToString(_pj.RunMethod("getJobStatus",(Object[])(__c.Null)));
 //BA.debugLineNum = 33;BA.debugLine="End Sub";
return "";
}
public Object  _getobject() throws Exception{
 //BA.debugLineNum = 72;BA.debugLine="Public Sub GetObject As Object";
 //BA.debugLineNum = 73;BA.debugLine="Return PJ";
if (true) return (Object)(_pj.getObject());
 //BA.debugLineNum = 74;BA.debugLine="End Sub";
return null;
}
public b4j.example.printer  _getprinter() throws Exception{
 //BA.debugLineNum = 35;BA.debugLine="Public Sub GetPrinter As Printer";
 //BA.debugLineNum = 36;BA.debugLine="Return Printer_Static.MappedPrinter(PJ.RunMethod(";
if (true) return _printer_static._mappedprinter /*b4j.example.printer*/ (_pj.RunMethod("getPrinter",(Object[])(__c.Null)));
 //BA.debugLineNum = 38;BA.debugLine="End Sub";
return null;
}
public Object  _getwindow(anywheresoftware.b4j.objects.Form _form) throws Exception{
anywheresoftware.b4j.object.JavaObject _jo = null;
 //BA.debugLineNum = 78;BA.debugLine="Private Sub GetWindow(Form As Form) As Object";
 //BA.debugLineNum = 79;BA.debugLine="If Form = Null Then Return Form";
if (_form== null) { 
if (true) return (Object)(_form);};
 //BA.debugLineNum = 80;BA.debugLine="Dim Jo As JavaObject = Form.RootPane";
_jo = new anywheresoftware.b4j.object.JavaObject();
_jo = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_form.getRootPane().getObject()));
 //BA.debugLineNum = 81;BA.debugLine="Jo = Jo.RunMethodJO(\"getScene\",Null).RunMethod(\"g";
_jo = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_jo.RunMethodJO("getScene",(Object[])(__c.Null)).RunMethod("getWindow",(Object[])(__c.Null))));
 //BA.debugLineNum = 82;BA.debugLine="Return Jo";
if (true) return (Object)(_jo.getObject());
 //BA.debugLineNum = 84;BA.debugLine="End Sub";
return null;
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 10;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 12;BA.debugLine="End Sub";
return "";
}
public boolean  _printdialog() throws Exception{
 //BA.debugLineNum = 63;BA.debugLine="Public Sub printDialog( ) As Boolean";
 //BA.debugLineNum = 65;BA.debugLine="Return PJ.RunMethod(\"printDialog\",Null)";
if (true) return BA.ObjectToBoolean(_pj.RunMethod("printDialog",(Object[])(__c.Null)));
 //BA.debugLineNum = 66;BA.debugLine="End Sub";
return false;
}
public boolean  _printpage(anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper _node) throws Exception{
 //BA.debugLineNum = 40;BA.debugLine="Public Sub PrintPage(Node As Node) As Boolean";
 //BA.debugLineNum = 41;BA.debugLine="Return PJ.RunMethod(\"printPage\",Array As Object(N";
if (true) return BA.ObjectToBoolean(_pj.RunMethod("printPage",new Object[]{(Object)(_node.getObject())}));
 //BA.debugLineNum = 42;BA.debugLine="End Sub";
return false;
}
public boolean  _printpage2(b4j.example.pagelayout _playout,anywheresoftware.b4j.objects.NodeWrapper.ConcreteNodeWrapper _node) throws Exception{
 //BA.debugLineNum = 44;BA.debugLine="Public Sub PrintPage2(PLayout As PageLayout, Node";
 //BA.debugLineNum = 45;BA.debugLine="Return PJ.RunMethod(\"printPage\",Array As Object(P";
if (true) return BA.ObjectToBoolean(_pj.RunMethod("printPage",new Object[]{_playout._getobject /*Object*/ (),(Object)(_node.getObject())}));
 //BA.debugLineNum = 46;BA.debugLine="End Sub";
return false;
}
public String  _setobject(Object _obj) throws Exception{
 //BA.debugLineNum = 75;BA.debugLine="Public Sub SetObject(Obj As Object)";
 //BA.debugLineNum = 76;BA.debugLine="PJ = Obj";
_pj = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_obj));
 //BA.debugLineNum = 77;BA.debugLine="End Sub";
return "";
}
public String  _setprinter(b4j.example.printer _printer1) throws Exception{
 //BA.debugLineNum = 48;BA.debugLine="Public Sub SetPrinter(Printer1 As Printer)";
 //BA.debugLineNum = 49;BA.debugLine="PJ.RunMethod(\"setPrinter\",Array As Object(Printer";
_pj.RunMethod("setPrinter",new Object[]{_printer1._getobject /*Object*/ ()});
 //BA.debugLineNum = 50;BA.debugLine="End Sub";
return "";
}
public boolean  _showpagesetupdialog(anywheresoftware.b4j.objects.Form _form) throws Exception{
Object _window = null;
 //BA.debugLineNum = 52;BA.debugLine="Public Sub ShowPageSetupDialog(Form As Form) As Bo";
 //BA.debugLineNum = 53;BA.debugLine="Dim Window As Object = GetWindow(Form)";
_window = _getwindow(_form);
 //BA.debugLineNum = 54;BA.debugLine="Return PJ.RunMethod(\"showPageSetupDialog\",Array A";
if (true) return BA.ObjectToBoolean(_pj.RunMethod("showPageSetupDialog",new Object[]{_window}));
 //BA.debugLineNum = 55;BA.debugLine="End Sub";
return false;
}
public boolean  _showprintdialog(anywheresoftware.b4j.objects.Form _form) throws Exception{
Object _window = null;
 //BA.debugLineNum = 57;BA.debugLine="Public Sub ShowPrintDialog(Form As Form) As Boolea";
 //BA.debugLineNum = 58;BA.debugLine="Dim Window As Object = GetWindow(Form)";
_window = _getwindow(_form);
 //BA.debugLineNum = 59;BA.debugLine="Return PJ.RunMethod(\"showPrintDialog\",Array(Windo";
if (true) return BA.ObjectToBoolean(_pj.RunMethod("showPrintDialog",new Object[]{_window}));
 //BA.debugLineNum = 60;BA.debugLine="End Sub";
return false;
}
public String  _tostring() throws Exception{
 //BA.debugLineNum = 69;BA.debugLine="Public Sub ToString As String";
 //BA.debugLineNum = 70;BA.debugLine="Return PJ.RunMethod(\"toString\",Null)";
if (true) return BA.ObjectToString(_pj.RunMethod("toString",(Object[])(__c.Null)));
 //BA.debugLineNum = 71;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
